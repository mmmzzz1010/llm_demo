# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf


def get_metrics(label, score, name):
    # loss = tf.losses.sigmoid_cross_entropy(label, logit)
    accuracy = tf.reduce_mean(tf.cast(tf.equal(label, tf.round(score)), tf.float32))
    auc, auc_op = tf.metrics.auc(label, score, num_thresholds=2000)
    pcopc = tf.reduce_sum(score) / tf.maximum(tf.reduce_sum(label), 1)
    rate = tf.reduce_sum(label) / tf.maximum(tf.cast(tf.shape(label)[0], tf.float32), 1)

    # tf.summary.scalar('train/{}_loss'.format(name), loss)
    tf.summary.scalar('train/{}_auc'.format(name), auc_op)
    tf.summary.scalar('train/{}_accuracy'.format(name), accuracy)
    tf.summary.scalar('train/{}_rate'.format(name), rate)
    tf.summary.scalar('train/{}_pcopc'.format(name), pcopc)

    return auc, auc_op

def get_regression_metrics(label, logit, name):
    regression_abs_mean = tf.reduce_sum(tf.abs(label - logit)) / tf.maximum(tf.reduce_sum(label), 1)
    regression_actual_rate = tf.reduce_sum(label) / tf.maximum(tf.reduce_sum(label), 1)
    regression_pred_rate = tf.reduce_sum(logit) / tf.maximum(tf.reduce_sum(label), 1)
    # summary
    tf.summary.scalar('train/{}_regression_abs_mean'.format(name), regression_abs_mean)
    tf.summary.scalar('train/{}_regression_actual_rate'.format(name), regression_actual_rate)
    tf.summary.scalar('train/{}_regression_pred_rate'.format(name), regression_pred_rate)
    # metrics
    metrics = {'eval/{}_regression_abs_mean'.format(name): tf.metrics.mean(regression_abs_mean),
               'eval/{}_regression_actual_rate'.format(name): tf.metrics.mean(regression_actual_rate),
               'eval/{}_regression_pred_rate'.format(name): tf.metrics.mean(regression_pred_rate)
            }
    return metrics

def get_list_topns_metrics(label, score, topn=[], weights=None, name='wpo'):
    metrics = {}
    for i in topn:
        metrics_k = get_list_topk_metrics(label, score, topn=i, weights=weights, name=name)
        metrics = {**metrics, **metrics_k}

    return metrics

def get_list_topk_metrics(label, score, topn=None, weights=None, name='wpo'):
    from alps_biz.core.utils import wpo_metrics_util as wpo_metrics

    precision_metrics_k = wpo_metrics.precision(label, score, weights=weights, topn=topn)
    map_metrics_k = wpo_metrics.mean_average_precision(label, score, weights=weights, topn=topn)
    ndcg_metrics_k = wpo_metrics.normalized_discounted_cumulative_gain(label, score, weights=weights, topn=topn)
    mrr_meterics_k = wpo_metrics.mean_reciprocal_rank(label, score, weights=weights, topn=topn)

    tf.summary.scalar('train/{}_precision_{}'.format(name, topn), precision_metrics_k[1])
    tf.summary.scalar('train/{}_map_{}'.format(name, topn), map_metrics_k[1])
    tf.summary.scalar('train/{}_ndcg_{}'.format(name, topn), ndcg_metrics_k[1])
    tf.summary.scalar('train/{}_mrr_{}'.format(name, topn), mrr_meterics_k[1])

    metrics = {'eval/{}_precision_{}'.format(name, topn): precision_metrics_k,
               'eval/{}_map_{}'.format(name, topn): map_metrics_k,
               'eval/{}_ndcg_{}'.format(name, topn): ndcg_metrics_k,
               'eval/{}_mrr_{}'.format(name, topn): mrr_meterics_k
               }

    return metrics