# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
# Author: anbo
# Date: 2020-03-18

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf


def get_optimizer(params, loss=None):
  """
    inputs:
        params: param of optimizer, such as lr
    return: optimizer
    """
  import tfplus

  opt = params.get('opt', 'adam')
  tf.logging.info('use optimizer {}'.format(opt))

  learning_rate = params.get('learning_rate', 0.0001)

  if opt == 'adam':
    optimizer = tfplus.train.AdamOptimizer(learning_rate=learning_rate)

  elif opt == 'ftrl':
    optimizer = tfplus.train.FtrlOptimizer(learning_rate=learning_rate)

  elif opt == 'gadam':
    l21 = params.get('l21', 0)
    l2 = params.get('l2', 0.00025)
    l1 = params.get('l1', 0.001)
    optimizer = tfplus.train.GroupAdamOptimizer(
        learning_rate=learning_rate,
        l1_regularization_strength=l1,
        l21_regularization_strength=l21,
        l2_regularization_strength=l2)

  elif opt == 'gftrl':
    l2 = params.get('l2', 0.00025)
    l1 = params.get('l1', 0.001)
    optimizer = tfplus.train.GroupFtrlOptimizer(learning_rate=learning_rate,
                                                l1_regularization_strength=l1,
                                                l2_regularization_strength=l2)

  elif opt == 'amsgrad':
    l21 = params.get('l21', 0)
    l2 = params.get('l2', 0.00025)
    l1 = params.get('l1', 0.001)
    # lr=0.0001, l1=0.001, l2=1.e-5, l21=0.00025
    optimizer = tfplus.train.GroupAMSGradOptimizer(
        learning_rate=learning_rate,
        l1_regularization_strength=l1,
        l2_regularization_strength=l2,
        l21_regularization_strength=l21)

  elif opt == 'radam':
    warmup_ratio = params.get('warmup_ratio', 0.1)
    min_lr = params.get('min_lr', 0.)
    amsgrad_tag = params.get('amsgrad_tag', False)
    sma_threshold = params.get('sma_threshold', 5.0)
    total_steps = params.get('total_steps', 0)
    optimizer = tfplus.train.RectifiedAdamOptimizer(
        learning_rate=learning_rate,
        amsgrad=amsgrad_tag,
        sma_threshold=sma_threshold,
        total_steps=total_steps,
        warmup_proportion=warmup_ratio,
        min_lr=min_lr)

  elif opt == 'lookahead':
    warmup_ratio = params.get('warmup_ratio', 0.1)
    min_lr = params.get('min_lr', 0.)
    amsgrad_tag = params.get('amsgrad_tag', False)
    sma_threshold = params.get('sma_threshold', 5.0)
    total_steps = params.get('total_steps', 0)
    sync_period = params.get('sync_period', 5)
    slow_step_size = params.get('slow_step_size', 0.5)
    radam = tfplus.train.RectifiedAdamOptimizer(learning_rate=learning_rate,
                                                amsgrad=amsgrad_tag,
                                                sma_threshold=sma_threshold,
                                                total_steps=total_steps,
                                                warmup_proportion=warmup_ratio,
                                                min_lr=min_lr)
    optimizer = tfplus.train.LookaheadOptimizer(radam,
                                                sync_period=sync_period,
                                                slow_step_size=slow_step_size)

  elif opt == 'dc_asgd':
    lambda2 = params.get('lambda2', 0.0001)
    lambda1 = params.get('lambda1', 0.0001)
    sgd = tfplus.train.GradientDescentOptimizer(learning_rate=learning_rate)
    optimizer = tfplus.train.DCAsgdOptimizer(sgd,
                                             lambda1=lambda1,
                                             lambda2=lambda2)

  elif opt == "group_adahessian":
    tf.logging.info('use group_adahessian optimizer')
    assert (loss is not None), ('Must specify loss')
    lr1 = params.get("lr1", 0.001)
    lr2 = params.get("lr2", 0.001)
    epsilon1 = params.get("epsilon1", 1e-5)
    epsilon2 = params.get("epsilon2", 1e-5)
    l1 = params.get("l1", 0.0001)
    l21 = params.get("l21", 0.0001)
    l2 = params.get("l2", 1e-5)
    emb_opt = params.get('emb_opt', 'ams')
    variables1 = []
    variables2 = []
    for v in tf.trainable_variables():
      tf.logging.info("variable:{}".format(v.name))
      if "embedding" in v.name:
        variables1.append(v)
      else:
        variables2.append(v)
    if emb_opt == 'ams':
      optimizer1 = tfplus.train.GroupAMSGradOptimizer(
          learning_rate=lr1,
          l1_regularization_strength=l1,
          l2_regularization_strength=l2,
          l21_regularization_strength=l21,
      )
    else:
      optimizer1 = tfplus.train.GroupAdaHessianOptimizer(
          learning_rate=lr1,
          initial_accumulator_value=0.0,
          epsilon=epsilon1,
          l1_regularization_strength=l1,
          l21_regularization_strength=l21,
          l2_regularization_strength=l2,
      )
    optimizer2 = tfplus.train.GroupAdaHessianOptimizer(
        learning_rate=lr2,
        initial_accumulator_value=0.0,
        epsilon=epsilon2,
        l1_regularization_strength=l1,
        l21_regularization_strength=l21,
        l2_regularization_strength=l2,
    )
    tf.logging.info("lr1: {}, lr2: {}, epsilon1: {}, epsilon2: {}".format(
        lr1, lr2, epsilon1, epsilon2))
    grad_and_vars = optimizer1.compute_gradients(loss, var_list=variables1)
    grad_var_hes = optimizer2.compute_gradients(loss, var_list=variables2)
    train_op1 = optimizer1.apply_gradients(
        grad_and_vars, global_step=tf.train.get_global_step())
    train_op2 = optimizer2.apply_gradients(grad_var_hes)
    optimizer = tf.group(train_op1, train_op2)

  else:
    raise NotImplementedError("This kind of optimizer is not implemented!")

  return optimizer
