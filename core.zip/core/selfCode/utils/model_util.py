## coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
# Author: anbo
# Date: 2020-03-18

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from alps_biz import get_default_global_id
from alps_biz.core.model.wnd import WndModel
from alps_biz.core.model.dcn import DCNModel
from alps_biz.core.model.deepfm import DeepFMModel
from alps_biz.core.model.nfm import NFMModel
from alps_biz.core.model.xdeepfm import xDeepFMModel
from alps_biz.core.model.autoint import AutoIntModel
from alps_biz.core.model.din import DINModel
from alps_biz.core.model.bert4rec import Bert4RecModel
from alps_biz.core.model.multicnn import MultiCNNModel
from alps_biz.core.model.tower import TowerModel
from alps_biz.core.model.esmm import ESMMModel
from alps_biz.core.model.dnn import DNNModel
from alps_biz.core.model.seqcross import SeqCrossModel
from alps_biz.core.model.hard_sharing_mtl import HardSharingModel
from alps_biz.core.model.cross_stitch import CrossStitchModel
from alps_biz.core.model.cross_sharing_mtl import CrossSharingModel
from alps_biz.core.model.general_mmoe import GeneralMMoEModel
from alps_biz.core.model.general_multihead_attn import GeneralMultiHeadAttnModel
from alps_biz.core.model.dsin import DSINModel
from alps_biz.core.model.caser import CaserModel
from alps_biz.core.model.gru4rec import GRU4RecModel
from alps_biz.core.model.flen import FLENModel
from alps_biz.core.model.domain_mmoe import DomainMMoEModel
from alps_biz.core.model.dlcm import DLCMModel
from alps_biz.core.model.prm import PRMModel
from alps_biz.core.model.srga import SRGAModel
from alps_biz.core.model.hpcoattn import HierarchyParallelCoAttnModel
from alps_biz.core.model.rmdan import RMDANModel
from alps_biz.core.model.smem import SMemModel
from alps_biz.core.model.gatenet import GateNetModel
from alps_biz.core.model.ple import PLEModel
from alps_biz.core.model.fibinet import FiBiNetModel
from alps_biz.core.model.gmv_esmm import GMVESMMModel
from alps_biz.core.model.lstm_dcn import LSTMDCNModel
from alps_biz.core.model.bagging_mmoe import BaggingMSLMMoEModel
from alps_biz.core.model.dcnm import DCNMModel
from alps_biz.core.model.mose import MoSEModel
from alps_biz.core.model.hgme import HGMEModel
from alps_biz.core.model.interHAt import InterHAtModel
from alps_biz.core.model.can import CANModel
from alps_biz.core.model.masknet import MaskNetModel
from alps_biz.core.model.dfn import DFNModel
from alps_biz.core.model.stan import STANModel
from alps_biz.core.model.hgn import HGNModel
from alps_biz.core.model.tien import TIENModel
from alps_biz.core.model.xpa import XPAModel
from alps_biz.core.model.aitm import AITMModel
from alps_biz.core.model.contextnet import ContextNetModel
from alps_biz.core.model.star import STARModel
from alps_biz.core.model.fbas import FBASModel
from alps_biz.core.model.edcn import EDCNModel
from alps_biz.core.model.mian import MIANModel
from alps_biz.core.model.sar_net import SARNetModel
from alps_biz.core.model.dcap import DCAPModel

from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.utils.reshape_util import ListToTensor, shrink_tensor

import tensorflow as tf
from tensorflow.python.keras.layers import Dense, Dropout, Lambda, Concatenate, Multiply, Flatten, Activation, BatchNormalization
from tensorflow.python.keras import backend as K


def get_model(inputs, extra_input=None, training=None, params={}, mask=None):
  """
    :param inputs: tensor, or list of tensor
    :param extra_input: deep features
    :param params:
    :return:
    """
  model_tag = params.get('model_tag', 'wnd')
  get_default_global_id().add_global_id_info({"BIZ_MODEL_TAG": model_tag})
  tf.logging.info(
      '======> Start to build Alps_biz model_tag {}'.format(model_tag))

  field_size = params.get('field_size', 12)
  emb_dim = params.get('emb_dim', 8)

  if model_tag == 'wnd':
    # 1, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    apply_final_act = params.get('apply_final_act', False)

    model = WndModel(hidden_units=hidden_units,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     apply_final_act=apply_final_act)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'dnn':
    # 2, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    apply_final_act = params.get('apply_final_act', False)

    model = DNNModel(hidden_units=hidden_units,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     apply_final_act=apply_final_act)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'dcn':
    # 3, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    n_cross_layers = params.get('n_cross_layers', 4)

    inputs = Concatenate(axis=-1, name='concat')(
        [inputs, extra_input]) if extra_input is not None else inputs

    model = DCNModel(hidden_units=hidden_units,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     n_cross_layers=n_cross_layers)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'deepfm':
    # 4, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)

    inputs = ListToTensor(inputs,
                          extra_input,
                          field_size=field_size,
                          emb_dim=emb_dim)

    model = DeepFMModel(hidden_units=hidden_units,
                        act_fn=act_fn,
                        l2_reg=l2_reg,
                        dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'xdeepfm':
    # 5, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)

    ## cin part
    cin_hidden_units = params.get('cin_hidden_units', [10, 10])
    cin_act_fn = params.get('cin_act_fn', 'relu')
    cin_l2_reg = params.get('cin_l2_reg', 0.001)

    inputs = ListToTensor(inputs,
                          extra_input,
                          field_size=field_size,
                          emb_dim=emb_dim)

    model = xDeepFMModel(hidden_units=hidden_units,
                         act_fn=act_fn,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate,
                         use_bn=False,
                         seed=1024,
                         cin_hidden_units=cin_hidden_units,
                         cin_act_fn=cin_act_fn,
                         cin_l2_reg=cin_l2_reg)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'nfm':
    # 6, inputs: tensor
    hidden_units = params.get('hidden_units', [8, 4])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    apply_final_act = params.get('apply_final_act', False)

    inputs = ListToTensor(inputs,
                          extra_input,
                          field_size=field_size,
                          emb_dim=emb_dim)

    model = NFMModel(hidden_units=hidden_units,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     apply_final_act=apply_final_act)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'autoint':
    # 7, inputs: tensor
    hidden_units = params.get('hidden_size', 8)
    heads = params.get('heads', 4)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim)
    # inputs: 3d tensor, extra_input: 2d tensor
    model = AutoIntModel(hidden_units=hidden_units,
                         heads=heads,
                         projection_hidden_units=projection_hidden_units,
                         apply_final_act=apply_final_act,
                         act_fn=act_fn,
                         dropout_rate=dropout_rate,
                         l2_reg=l2_reg,
                         use_bn=use_bn,
                         min_timescale=min_timescale,
                         max_timescale=max_timescale,
                         pos_type=pos_type)
    output = model(inputs, extra_input=extra_input, training=training)
    output = shrink_tensor(output)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'bert':
    # 8, inputs: tensor
    hidden_units = params.get('hidden_size', 8)
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 16)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    lego = params.get('lego', 'standard')
    mha_type = params.get('mha_type', 'origin')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    inf = params.get('inf', 1.e9)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim)
    # inputs: 3d tensor, extra_input: 2d tensor
    model = Bert4RecModel(hidden_units=hidden_units,
                          heads=heads,
                          intermediate_size=intermediate_size,
                          n_transform_layers=n_transform_layers,
                          act_fn=act_fn,
                          dropout_rate=dropout_rate,
                          l2_reg=l2_reg,
                          return_all_layers=return_all_layers,
                          projection_hidden_units=projection_hidden_units,
                          apply_final_act=apply_final_act,
                          use_bn=use_bn,
                          min_timescale=min_timescale,
                          max_timescale=max_timescale,
                          pos_type=pos_type,
                          mha_type=mha_type,
                          dim_e=dim_e,
                          synthesizer_type=synthesizer_type,
                          inf=inf)
    output = model(inputs,
                   extra_input=extra_input,
                   training=training,
                   lego=lego)
    output = shrink_tensor(output)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'general_multi_head_attn':
    # 9, inputs: tensor
    hidden_units = params.get('hidden_size', 8)
    heads = params.get('heads', 4)
    list_tag = params.get('list_tag', True)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    mha_type = params.get('mha_type', 'vanilla')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    inf = params.get('inf', 1.e9)
    operation_type = params.get('operation_type', 'concat')

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim)
    # inputs: list of 3 3d tensor, extra_input: 2d tensor
    model = GeneralMultiHeadAttnModel(
        hidden_units=hidden_units,
        heads=heads,
        l2_reg=l2_reg,
        dropout_rate=dropout_rate,
        act_fn=act_fn,
        list_tag=list_tag,
        projection_hidden_units=projection_hidden_units,
        apply_final_act=apply_final_act,
        use_bn=use_bn,
        mha_type=mha_type,
        dim_e=dim_e,
        synthesizer_type=synthesizer_type,
        inf=inf,
        operation_type=operation_type)
    output = model(inputs, extra_input=extra_input, training=training)
    output = shrink_tensor(output)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'din':
    # 10, inputs: tensor
    input_length = params.get('input_length', 12)
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)
    weight_norm = params.get('weight_norm', False)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: list of 2 3d tensor, extra_input: 2d tensor
    input_a, input_b = inputs
    input_a_dim = input_a.get_shape().as_list()[-1]
    input_b_dim = input_b.get_shape().as_list()[-1]
    tf.logging.info(
        'DINModel: input_a {}, input_a_dim {},\n, input_b {}, input_b_dim {}'.
        format(input_a, input_a_dim, input_b, input_b_dim))
    input_b_shrink = tf.keras.layers.Dense(
        input_a_dim, activation='relu',
        kernel_initializer='he_normal')(input_b)

    model = DINModel(input_length=input_length,
                     hidden_units=hidden_units,
                     projection_hidden_units=projection_hidden_units,
                     apply_final_act=apply_final_act,
                     act_fn=act_fn,
                     dropout_rate=dropout_rate,
                     l2_reg=l2_reg,
                     use_bn=use_bn,
                     weight_norm=weight_norm)
    output = model([input_a, input_b_shrink],
                   extra_input=extra_input,
                   training=training)
    output = shrink_tensor(output)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'multicnn':
    # 11, inputs: tensor
    filters = params.get('filters', [4, 4, 4])
    kernel_size = params.get('kernel_size', [1, 3, 6])
    input_length = params.get('input_length', 12)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: list of 3d and 2d tensor, extra_input: 2d tensor
    model = MultiCNNModel(filters=filters,
                          kernel_size=kernel_size,
                          input_length=input_length,
                          l2_reg=l2_reg,
                          act_fn=act_fn,
                          dropout_rate=dropout_rate,
                          projection_hidden_units=projection_hidden_units,
                          apply_final_act=apply_final_act,
                          use_bn=use_bn)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'caser':
    # 12, inputs: tensor
    h_filters = params.get('h_filters', [4, 6, 8])
    h_kernel = params.get('h_kernel', [2, 4, 5])
    v_filters = params.get('h_filters', [1, 2, 4])
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: 3d tensor, extra_input: 2d tensor
    model = CaserModel(h_filters=h_filters,
                       h_kernel=h_kernel,
                       v_filters=v_filters,
                       l2_reg=l2_reg,
                       act_fn=act_fn,
                       dropout_rate=dropout_rate,
                       projection_hidden_units=projection_hidden_units,
                       apply_final_act=apply_final_act,
                       use_bn=use_bn)
    output = model(inputs, extra_input=extra_input, training=training)
    model.summary(print_fn=tf.logging.info)

  elif model_tag == 'gru4rec':
    # 13, inputs: tensor
    rnn_unit = params.get('rnn_unit', 32)
    rnn_act_fn = params.get('rnn_act_fn', 'tanh')
    return_sequences = params.get('return_sequences', False)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: 3d tensor, extra_input: 2d tensor
    model = GRU4RecModel(rnn_unit=rnn_unit,
                         projection_hidden_units=projection_hidden_units,
                         rnn_act_fn=rnn_act_fn,
                         act_fn=act_fn,
                         return_sequences=return_sequences,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate,
                         apply_final_act=apply_final_act,
                         use_bn=use_bn)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'dsin':
    # 14, inputs: tensor
    hidden_units = params.get('hidden_size', 8)
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 16)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    rnn_unit = params.get('rnn_unit', 32)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    lego = params.get('lego', 'standard')

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim)
    # inputs: list of 4d tensor and 2d tensor, extra_input: 2d tensor
    model = DSINModel(hidden_units=hidden_units,
                      heads=heads,
                      intermediate_size=intermediate_size,
                      n_transform_layers=n_transform_layers,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate,
                      l2_reg=l2_reg,
                      return_all_layers=return_all_layers,
                      rnn_unit=rnn_unit,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      min_timescale=min_timescale,
                      max_timescale=max_timescale,
                      pos_type=pos_type)
    output = model(inputs,
                   extra_input=extra_input,
                   training=training,
                   lego=lego)
    output = shrink_tensor(output)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'seqcross':
    # 15, inputs: tensor
    n_layers = params.get('n_layers', 2)
    remove_attention = params.get('remove_attention', False)
    keep_attention_value = params.get('keep_attention_value', False)
    flatten_output_seq = params.get('flatten_output_seq', True)
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: list of 3d and 2d tensor, extra_input: 2d tensor
    model = SeqCrossModel(n_layers=n_layers,
                          l2_reg=l2_reg,
                          remove_attention=remove_attention,
                          keep_attention_value=keep_attention_value,
                          flatten_output_seq=flatten_output_seq,
                          hidden_units=hidden_units,
                          act_fn=act_fn,
                          dropout_rate=dropout_rate,
                          use_bn=use_bn,
                          seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'flen':
    # 16, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)
    use_bias = params.get('use_bias', True)
    seed = params.get('seed', 1024)

    #inputs = ListToTensor(inputs, extra_input, field_size=field_size, emb_dim=emb_dim, concat_out=False)
    # inputs: 3d tensor, extra_input: 2d tensor
    model = FLENModel(hidden_units=hidden_units,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      use_bn=use_bn,
                      use_bias=use_bias,
                      seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)
    # output: (batch, dim)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'tower':
    # 17, inputs: tensor
    user_hidden_units = params.get('user_hidden_units', [64, 16])
    item_hidden_units = params.get('item_hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)

    # input_list = [inputs, extra_input]
    # inputs list of 2 2d tensors
    # output: (batch_size, 1)
    model = TowerModel(user_hidden_units=user_hidden_units,
                       item_hidden_units=item_hidden_units,
                       act_fn=act_fn,
                       l2_reg=l2_reg,
                       dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    # output: (batch_size, 1)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'esmm':
    # 18, inputs: tensor
    task_hidden_units = params.get('task_hidden_units',
                                   [[32, 8, 1], [32, 8, 1]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)

    model = ESMMModel(task_hidden_units=task_hidden_units,
                      task_apply_final_act=task_apply_final_act,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    # output = [ctr_output, cvr_output]
    # ctr_output: (batch_size, 1)
    # cvr_output: (batch_size, 1)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'gmv_esmm':
    # 19, inputs: tensor
    ctr_hidden_units = params.get('ctr_hidden_units', 80)
    gmv_hidden_units = params.get('gmv_hidden_units', 80)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.2)

    model = GMVESMMModel(ctr_hidden_units=ctr_hidden_units,
                         gmv_hidden_units=gmv_hidden_units,
                         act_fn=act_fn,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate)
    ctr_output, cvr_output = model(inputs,
                                   extra_input=extra_input,
                                   training=training)
    print('ctr_output, cvr_output', ctr_output, cvr_output)
    output = [ctr_output, cvr_output]
    # ctr_output: (batch_size, 1)
    # cvr_output: (batch_size, 1)

  elif model_tag == 'lstm_dcn':
    # 20, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    n_cross_layers = params.get('n_cross_layers', 4)
    rnn_unit = params.get('rnn_unit', 32)
    rnn_act_fn = params.get('rnn_act_fn', 'tanh')
    return_sequences = params.get('return_sequences', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = LSTMDCNModel(hidden_units=hidden_units,
                         rnn_unit=rnn_unit,
                         rnn_act_fn=rnn_act_fn,
                         return_sequences=return_sequences,
                         act_fn=act_fn,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate,
                         use_bn=use_bn,
                         seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'hard_sharing':
    # 21, inputs: tensor
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = HardSharingModel(sharing_hidden_units=sharing_hidden_units,
                             task_hidden_units=task_hidden_units,
                             task_apply_final_act=task_apply_final_act,
                             act_fn=act_fn,
                             l2_reg=l2_reg,
                             dropout_rate=dropout_rate,
                             use_bn=use_bn,
                             seed=seed)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'cross_sharing':
    # 22, inputs: tensor
    dcn_hidden_units = params.get('dcn_hidden_units', [64, 16])
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    n_cross_layers = params.get('n_cross_layers', 2)
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = CrossSharingModel(dcn_hidden_units=dcn_hidden_units,
                              sharing_hidden_units=sharing_hidden_units,
                              task_hidden_units=task_hidden_units,
                              n_cross_layers=n_cross_layers,
                              task_apply_final_act=task_apply_final_act,
                              act_fn=act_fn,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              seed=seed)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'cross_stitch':
    # 23, inputs: tensor
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    #cross_stitch_layers_list = params.get('cross_stitch_layers_list', 1)
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = CrossStitchModel(sharing_hidden_units=sharing_hidden_units,
                             task_hidden_units=task_hidden_units,
                             task_apply_final_act=task_apply_final_act,
                             act_fn=act_fn,
                             l2_reg=l2_reg,
                             dropout_rate=dropout_rate,
                             use_bn=use_bn,
                             seed=seed)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'general_mmoe':
    # 24, inputs: tensor
    experts_hidden_units = params.get('experts_hidden_units', [[16], [16]])
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[8], [8]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = GeneralMMoEModel(experts_hidden_units=experts_hidden_units,
                             sharing_hidden_units=sharing_hidden_units,
                             task_hidden_units=task_hidden_units,
                             task_apply_final_act=task_apply_final_act,
                             act_fn=act_fn,
                             l2_reg=l2_reg,
                             dropout_rate=dropout_rate,
                             use_bn=use_bn,
                             seed=seed)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'domain_mmoe':
    # 25, inputs: tensor
    experts_hidden_units = params.get('experts_hidden_units',
                                      [[64, 16], [64, 16]])
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    bias_init = params.get('bias_init', [[0.6, 0.3], [0.3, 0.6]])
    is_bias_net = params.get('is_bias_net', False)
    experts_bias_hidden_units = params.get('experts_bias_hidden_units',
                                           [[4], [4]])
    bias_sharing_hidden_units = params.get('bias_sharing_hidden_units', [4])

    model = DomainMMoEModel(
        experts_hidden_units=experts_hidden_units,
        sharing_hidden_units=sharing_hidden_units,
        task_hidden_units=task_hidden_units,
        task_apply_final_act=task_apply_final_act,
        act_fn=act_fn,
        l2_reg=l2_reg,
        dropout_rate=dropout_rate,
        use_bn=use_bn,
        seed=seed,
        bias_init=bias_init,
        is_bias_net=is_bias_net,
        experts_bias_hidden_units=experts_bias_hidden_units,
        bias_sharing_hidden_units=bias_sharing_hidden_units)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'bagging_mmoe':
    # 26, inputs: tensor
    num_input = params.get('num_input', 8)
    scenes_hidden_units = params.get('scenes_hidden_units',
                                     [[64, 16], [64, 16]])
    sharing_hidden_units = params.get('sharing_hidden_units', [64, 16])
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    num_experts = params.get('num_experts', 2)
    is_random = params.get('is_random', False)
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    bias_init = params.get('bias_init', [])
    is_bias_net = params.get('is_bias_net', False)
    bias_hidden_units = params.get('bias_hidden_units', [16, 8])
    expert_hidden_units = params.get('expert_hidden_units', [16, 8])

    model = BaggingMSLMMoEModel(num_input,
                                scenes_hidden_units,
                                sharing_hidden_units,
                                task_hidden_units,
                                num_experts,
                                is_random=is_random,
                                task_apply_final_act=task_apply_final_act,
                                act_fn=act_fn,
                                l2_reg=l2_reg,
                                dropout_rate=dropout_rate,
                                use_bn=use_bn,
                                expert_hidden_units=expert_hidden_units,
                                bias_init=bias_init,
                                is_bias_net=is_bias_net,
                                bias_hidden_units=bias_hidden_units)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'dlcm':
    # 27, inputs: tensor
    rnn_unit = params.get('rnn_unit', 32)
    input_length = params.get('input_length', 6)
    intermediate_unit = params.get('intermediate_unit', 4)
    hidden_units = params.get('hidden_units', [16])
    rnn_act_fn = params.get('rnn_act_fn', 'tanh')
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    apply_final_act = params.get('apply_final_act', True)
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)
    shared_pv = params.get('shared_pv', False)

    model = DLCMModel(rnn_unit=rnn_unit,
                      intermediate_unit=intermediate_unit,
                      input_length=input_length,
                      hidden_units=hidden_units,
                      rnn_act_fn=rnn_act_fn,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      shared_pv=shared_pv)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'prm':
    # 28, inputs: tensor
    hidden_units = params.get('hidden_units', [16])
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 16)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.0)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', True)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    lego = params.get('lego', 'standard')
    input_length = params.get('input_length', 6)
    shared_pv = params.get('shared_pv', False)

    # inputs: 3d tensor, extra_input: 2d tensor
    model = PRMModel(hidden_units=hidden_units,
                     heads=heads,
                     intermediate_size=intermediate_size,
                     input_length=input_length,
                     n_transform_layers=n_transform_layers,
                     act_fn=act_fn,
                     dropout_rate=dropout_rate,
                     l2_reg=l2_reg,
                     return_all_layers=return_all_layers,
                     projection_hidden_units=projection_hidden_units,
                     apply_final_act=apply_final_act,
                     use_bn=use_bn,
                     min_timescale=min_timescale,
                     max_timescale=max_timescale,
                     pos_type=pos_type,
                     shared_pv=shared_pv)
    output = model(inputs,
                   extra_input=extra_input,
                   mask=mask,
                   training=training,
                   lego=lego)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'srga':
    # 29, inputs: tensor
    hidden_units = params.get('hidden_units', [16])
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 16)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    apply_final_act = params.get('apply_final_act', True)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    lego = params.get('lego', 'standard')
    mha_type = params.get('mha_type', 'standard')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    inf = params.get('inf', 1.e9)
    input_length = params.get('input_length', 6)
    window = params.get('window', 1)
    shared_pv = params.get('shared_pv', False)

    # inputs: 3d tensor, extra_input: 2d tensor
    model = SRGAModel(hidden_units=hidden_units,
                      heads=heads,
                      intermediate_size=intermediate_size,
                      input_length=input_length,
                      n_transform_layers=n_transform_layers,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate,
                      l2_reg=l2_reg,
                      return_all_layers=return_all_layers,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      min_timescale=min_timescale,
                      max_timescale=max_timescale,
                      pos_type=pos_type,
                      mha_type=mha_type,
                      dim_e=dim_e,
                      synthesizer_type=synthesizer_type,
                      inf=inf,
                      window=window,
                      shared_pv=shared_pv)
    output = model(inputs,
                   extra_input=extra_input,
                   mask=mask,
                   training=training,
                   lego=lego)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'hpcoattn':
    # 30, inputs: tensor
    hidden_units = params.get('hidden_units', 16)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = HierarchyParallelCoAttnModel(
        hidden_units=hidden_units,
        l2_reg=l2_reg,
        seed=seed,
        projection_hidden_units=projection_hidden_units,
        apply_final_act=apply_final_act,
        use_bn=use_bn,
        act_fn=act_fn,
        dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'rmdan':
    # 31, inputs: tensor
    hidden_units = params.get('hidden_units', 16)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    n_dan_layers = params.get('n_dan_layers', 2)
    text_attention = params.get('text_attention', True)
    vis_attention = params.get('vis_attention', True)
    shared_agg_attention = params.get('shared_agg_attention', True)

    model = RMDANModel(hidden_units=hidden_units,
                       l2_reg=l2_reg,
                       seed=seed,
                       n_dan_layers=n_dan_layers,
                       text_attention=text_attention,
                       vis_attention=vis_attention,
                       shared_agg_attention=shared_agg_attention,
                       projection_hidden_units=projection_hidden_units,
                       apply_final_act=apply_final_act,
                       use_bn=use_bn,
                       act_fn=act_fn,
                       dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'smem':
    # 32, inputs: tensor
    hidden_units = params.get('hidden_units', 16)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = SMemModel(hidden_units=hidden_units,
                      l2_reg=l2_reg,
                      seed=seed,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'gatenet':
    # 33, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    embedding_gate = params.get('embedding_gate', False)
    hidden_gate = params.get('hidden_gate', True)

    model = GateNetModel(hidden_units=hidden_units,
                         l2_reg=l2_reg,
                         seed=seed,
                         embedding_gate=embedding_gate,
                         hidden_gate=hidden_gate)
    output = model(inputs, extra_input=extra_input, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'ple':
    # 34, inputs: 2d tensor
    expert_units = params.get('expert_units', [64, 16])
    n_task_experts = params.get('n_task_experts', [[3, 3], [2, 2]])
    n_shared_experts = params.get('n_shared_experts', [2, 2])
    task_hidden_units = params.get('task_hidden_units', [[8], [8]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    use_bn = params.get('use_bn', False)
    dropout_rate = params.get('dropout_rate', 0.0)

    model = PLEModel(expert_units=expert_units,
                     n_task_experts=n_task_experts,
                     n_shared_experts=n_shared_experts,
                     task_hidden_units=task_hidden_units,
                     task_apply_final_act=task_apply_final_act,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     use_bn=use_bn,
                     seed=seed)
    output = model(inputs, training=training)
    #model.summary(print_fn=tf.logging.info)

  elif model_tag == 'fibinet':
    # 35, inputs: 3d tensor
    reduction_ratio = params.get('reduction_ratio', 2)
    bilinear_type = params.get('bilinear_type', 'field_all')
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    use_bn = params.get('use_bn', False)
    dropout_rate = params.get('dropout_rate', 0.0)
    apply_final_act = params.get('apply_final_act', False)

    model = FiBiNetModel(reduction_ratio=reduction_ratio,
                         bilinear_type=bilinear_type,
                         projection_hidden_units=projection_hidden_units,
                         act_fn=act_fn,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate,
                         use_bn=use_bn,
                         apply_final_act=apply_final_act,
                         seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)
    # model.summary(print_fn=tf.logging.info)

  elif model_tag == 'dcnm':
    # 36, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    n_cross_layers = params.get('n_cross_layers', 4)
    lego = params.get('lego', 'parallel')
    projection_hidden_units = params.get('projection_hidden_units', [1])
    apply_final_act = params.get('apply_final_act', False)

    inputs = Concatenate(axis=-1, name='concat')(
        [inputs, extra_input]) if extra_input is not None else inputs

    model = DCNMModel(hidden_units=hidden_units,
                      projection_hidden_units=projection_hidden_units,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      n_cross_layers=n_cross_layers,
                      apply_final_act=apply_final_act)
    output = model(inputs, lego=lego, training=training)
    # model.summary(print_fn=tf.logging.info)

  elif model_tag == 'mose':
    # 37, inputs: 3d tensor
    hidden_units = params.get('hidden_units', 16)
    experts_rnn_units = params.get('experts_rnn_units', [32, 32])
    task_rnn_units = params.get('task_rnn_units', [16, 16])
    l2_reg = params.get('l2_reg', 0.001)
    sharing_rnn_units = params.get('sharing_rnn_units', 32)
    seed = params.get('seed', 1024)
    projection_hidden_units = params.get('projection_hidden_units', 1)
    # input_dim = params.get('input_dim', 32)

    input_dim = inputs.get_shape()[-1].value
    if extra_input is not None:
      input_dim += extra_input.get_shape()[-1].value

    # inputs: 3d tensor, extra_input: 2d tensor
    model = MoSEModel(hidden_units=hidden_units,
                      input_dim=input_dim,
                      experts_rnn_units=experts_rnn_units,
                      sharing_rnn_units=sharing_rnn_units,
                      task_rnn_units=task_rnn_units,
                      projection_hidden_units=projection_hidden_units,
                      l2_reg=l2_reg,
                      seed=seed)
    output = model(inputs,
                   extra_input=extra_input,
                   mask=mask,
                   training=training)
    # model.summary(print_fn=tf.logging.info)

  elif model_tag == 'hgme':
    # 38, inputs: tensor
    hidden_units = params.get('hidden_units', 32)
    heads = params.get('heads', 4)
    num_tasks = params.get('num_tasks', 2)
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    seed = params.get('seed', 1024)
    list_tag = params.get('list_tag', False)
    mha_type = params.get('mha_type', 'vanilla')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    inf = params.get('inf', 1.e9)
    window = params.get('window', 1)
    pos_type = params.get('pos_type', 'learnable')
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 100.)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    act_fn = params.get('act_fn', 'relu')

    # inputs: 3d tensor, extra_input: 2d tensor
    model = HGMEModel(hidden_units=hidden_units,
                      heads=heads,
                      num_tasks=num_tasks,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      seed=seed,
                      list_tag=list_tag,
                      mha_type=mha_type,
                      dim_e=dim_e,
                      synthesizer_type=synthesizer_type,
                      inf=inf,
                      window=window,
                      pos_type=pos_type,
                      min_timescale=min_timescale,
                      max_timescale=max_timescale,
                      projection_hidden_units=projection_hidden_units,
                      act_fn=act_fn)
    output = model(inputs,
                   extra_input=extra_input,
                   mask=mask,
                   training=training)

  elif model_tag == 'interhat':
    # 39, inputs: tensor
    n_layers = params.get('n_layers', 4)
    hidden_size = params.get('hidden_size', 16)
    hidden_units = params.get('hidden_units', 16)
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 64)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    apply_final_act = params.get('apply_final_act', True)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    mha_type = params.get('mha_type', 'vanilla')
    projection_hidden_units = params.get('projection_hidden_units', [1])

    # inputs: 3d tensor, extra_input: 2d tensor
    model = InterHAtModel(n_layers=n_layers,
                          hidden_size=hidden_size,
                          hidden_units=hidden_units,
                          heads=heads,
                          intermediate_size=intermediate_size,
                          n_transform_layers=n_transform_layers,
                          act_fn=act_fn,
                          dropout_rate=dropout_rate,
                          l2_reg=l2_reg,
                          return_all_layers=return_all_layers,
                          projection_hidden_units=projection_hidden_units,
                          apply_final_act=apply_final_act,
                          use_bn=use_bn,
                          seed=seed,
                          mha_type=mha_type)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'can':
    # 40, inputs: tensor
    hidden_units = params.get('hidden_units', [1])
    use_bias = params.get('use_bias', False)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    apply_final_act = params.get('apply_final_act', False)

    model = CANModel(hidden_units=hidden_units,
                     use_bias=use_bias,
                     projection_hidden_units=projection_hidden_units,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     use_bn=use_bn,
                     seed=seed,
                     apply_final_act=apply_final_act)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'masknet':
    # 41, inputs: tensor
    n_mask_blocks = params.get('n_mask_blocks', 1)
    lego = params.get('lego', 'parallel')
    hidden_size = params.get('hidden_size', 16)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    apply_final_act = params.get('apply_final_act', False)

    model = MaskNetModel(n_mask_blocks=n_mask_blocks,
                         lego=lego,
                         hidden_size=hidden_size,
                         projection_hidden_units=projection_hidden_units,
                         act_fn=act_fn,
                         l2_reg=l2_reg,
                         dropout_rate=dropout_rate,
                         use_bn=use_bn,
                         seed=seed,
                         apply_final_act=apply_final_act)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'dfn':
    # 42, inputs: tensor
    hidden_units = params.get('hidden_units', [64, 16])
    mlp_units = params.get('mlp_units', [16, 1])
    hidden_size = params.get('hidden_size', 16)
    heads = params.get('heads', 4)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    no_explicit_pos_hist = params.get('no_explicit_pos_hist', True)

    model = DFNModel(hidden_units=hidden_units,
                     mlp_units=mlp_units,
                     hidden_size=hidden_size,
                     heads=heads,
                     act_fn=act_fn,
                     dropout_rate=dropout_rate,
                     l2_reg=l2_reg,
                     projection_hidden_units=projection_hidden_units,
                     apply_final_act=apply_final_act,
                     use_bn=use_bn,
                     seed=seed,
                     no_explicit_pos_hist=no_explicit_pos_hist)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'stan':
    # 43, inputs: tensor
    hidden_size = params.get('hidden_size', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)

    model = STANModel(hidden_size=hidden_size,
                      l2_reg=l2_reg,
                      seed=seed,
                      projection_hidden_units=projection_hidden_units,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'tien':
    # 44, inputs: tensor
    rnn_unit = params.get('rnn_unit', 32)
    rnn_act_fn = params.get('rnn_act_fn', 'tanh')
    hidden_size = params.get('hidden_size', 16)
    hidden_units = params.get('hidden_units', [64, 16])
    heads = params.get('heads', 4)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    l2_reg = params.get('l2_reg', 0.001)
    projection_hidden_units = params.get('projection_hidden_units', [1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = TIENModel(rnn_unit=rnn_unit,
                      rnn_act_fn=rnn_act_fn,
                      hidden_size=hidden_size,
                      hidden_units=hidden_units,
                      heads=heads,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate,
                      l2_reg=l2_reg,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'xpa':
    # 45, inputs: tensor
    input_length = params.get('input_length', 6)
    hidden_units = params.get('hidden_units', [64, 16])
    relevance_hidden_units = params.get('relevance_hidden_units', [8, 1])
    examination_hidden_units = params.get('examination_hidden_units', [8, 1])
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    seed = params.get('seed', 1024)
    shared_pv = params.get('shared_pv', True)

    seq_input, pos_input = inputs

    model = XPAModel(input_length=input_length,
                     hidden_units=hidden_units,
                     relevance_hidden_units=relevance_hidden_units,
                     examination_hidden_units=examination_hidden_units,
                     min_timescale=min_timescale,
                     max_timescale=max_timescale,
                     pos_type=pos_type,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     seed=seed,
                     shared_pv=shared_pv)
    output = model(seq_input,
                   pos_input=pos_input,
                   extra_input=extra_input,
                   mask=mask,
                   training=training)

  elif model_tag == 'hgn':
    # 46, inputs: tensor
    user_hidden_units = params.get('user_hidden_units', [64, 16])
    project_user_tag = params.get('project_user_tag', True)
    item_hidden_units = params.get('item_hidden_units', [64, 16])
    project_item_tag = params.get('project_item_tag', True)
    hidden_units = params.get('hidden_units', [16])
    input_length = params.get('input_length', 6)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    l2_reg = params.get('l2_reg', 0.001)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = HGNModel(user_hidden_units=user_hidden_units,
                     project_user_tag=project_user_tag,
                     item_hidden_units=item_hidden_units,
                     project_item_tag=project_item_tag,
                     hidden_units=hidden_units,
                     input_length=input_length,
                     act_fn=act_fn,
                     l2_reg=l2_reg,
                     dropout_rate=dropout_rate,
                     use_bn=use_bn,
                     seed=seed)
    output = model(inputs, training=training)

  elif model_tag == 'aitm':
    # 47, inputs: tensor
    task_hidden_units = params.get('task_hidden_units', [[32, 8], [32, 8]])
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = AITMModel(task_hidden_units=task_hidden_units,
                      task_apply_final_act=task_apply_final_act,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      use_bn=use_bn,
                      seed=seed)
    output = model(inputs, training=training)
    # output = [ctr_output, cvr_output]

  elif model_tag == 'contextnet':
    # 48, inputs: tensor
    hidden_size = params.get('hidden_size', 32)
    share_aggregation_tag = params.get('share_aggregation_tag', True)
    point_fnn_tag = params.get('point_fnn_tag', False)
    contextnet_block_layers = params.get('contextnet_block_layers', 1)
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    l2_reg = params.get('l2_reg', 0.001)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    apply_final_act = params.get('apply_final_act', False)

    model = ContextNetModel(hidden_size=hidden_size,
                            share_aggregation_tag=share_aggregation_tag,
                            point_fnn_tag=point_fnn_tag,
                            contextnet_block_layers=contextnet_block_layers,
                            projection_hidden_units=projection_hidden_units,
                            act_fn=act_fn,
                            l2_reg=l2_reg,
                            dropout_rate=dropout_rate,
                            use_bn=use_bn,
                            apply_final_act=apply_final_act,
                            seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'star':
    # 49, inputs: tensor
    hidden_units = params.get('hidden_units', [16, 8, 1])
    aux_hidden_units = params.get('aux_hidden_units', [4, 1])
    num_domains = params.get('num_domains', 2)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    l2_reg = params.get('l2_reg', 0.001)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    apply_final_act = params.get('apply_final_act', False)

    model = STARModel(hidden_units=hidden_units,
                      aux_hidden_units=aux_hidden_units,
                      num_domains=num_domains,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      use_bn=use_bn,
                      apply_final_act=apply_final_act,
                      seed=seed)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'fbas':
    # 50, inputs: tensor
    hidden_size = params.get('hidden_size', 32)
    n_layers = params.get('n_layers', 2)
    n_mask_blocks = params.get('n_mask_blocks', 1)
    lego = params.get('lego', 'parallel')
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    drop_prob = params.get('drop_prob', 0)
    l2_reg = params.get('l2_reg', 0.001)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)

    model = FBASModel(hidden_size=hidden_size,
                      projection_hidden_units=projection_hidden_units,
                      l2_reg=l2_reg,
                      use_bn=use_bn,
                      seed=seed,
                      drop_prob=drop_prob,
                      n_layers=n_layers,
                      n_mask_blocks=n_mask_blocks,
                      lego=lego)
    output = model(inputs, extra_input=extra_input, training=training)

  elif model_tag == 'edcn':
    # 51, inputs: tensor
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    dropout_rate = params.get('dropout_rate', 0)
    n_cross_layers = params.get('n_cross_layers', 2)

    model = EDCNModel(projection_hidden_units=projection_hidden_units,
                      act_fn=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      use_bn=use_bn,
                      n_cross_layers=n_cross_layers,
                      seed=seed)
    output = model(inputs, training=training)

  elif model_tag == 'dcap':
    # 52, inputs: tensor
    hidden_units = params.get('hidden_size', 16)
    heads = params.get('heads', 4)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    projection_hidden_units = params.get('projection_hidden_units', [64, 16])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    lego = params.get('lego', 'standard')
    mha_type = params.get('mha_type', 'origin')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    seed = params.get('seed', 1024)
    list_tag = params.get('list_tag', False)
    window = params.get('window', 1)
    concat_heads = params.get('concat_heads', True)
    pool_size = params.get('pool_size', 2)
    strides = params.get('strides', 1)
    product_type = params.get('product_type', 'inner')
    n_layers = params.get('n_layers', 2)

    model = DCAPModel(hidden_units=hidden_units,
                      heads=heads,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate,
                      seed=seed,
                      list_tag=list_tag,
                      mha_type=mha_type,
                      dim_e=dim_e,
                      synthesizer_type=synthesizer_type,
                      window=window,
                      concat_heads=concat_heads,
                      pool_size=pool_size,
                      strides=strides,
                      product_type=product_type,
                      n_layers=n_layers,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      act_fn=act_fn)
    output = model(inputs,
                   mask=mask,
                   extra_input=extra_input,
                   training=training)

  elif model_tag == 'sar_net':
    # 53, inputs: tensor
    experts_hidden_units = params.get('experts_hidden_units', [[64, 16]] * 3)
    sharing_hidden_units = params.get('sharing_hidden_units', [128])
    task_hidden_units = params.get('task_hidden_units', [[1]] * 3)
    fuse_hidden_units = params.get('fuse_hidden_units', 256)
    task_apply_final_act = params.get('task_apply_final_act', False)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    seed = params.get('seed', 1024)
    input_length = params.get('input_length', 10)

    model = SARNetModel(experts_hidden_units=experts_hidden_units,
                        sharing_hidden_units=sharing_hidden_units,
                        task_hidden_units=task_hidden_units,
                        fuse_hidden_units=fuse_hidden_units,
                        task_apply_final_act=task_apply_final_act,
                        act_fn=act_fn,
                        l2_reg=l2_reg,
                        dropout_rate=dropout_rate,
                        use_bn=use_bn,
                        seed=seed,
                        input_length=input_length)
    output = model(inputs, training=training)

  elif model_tag == 'mian':
    # 54, inputs: tensor
    user_fields = params.get('user_fields', 8)
    item_fields = params.get('item_fields', 8)
    context_fields = params.get('context_fields', 8)
    hidden_units = params.get('hidden_size', 16)
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 64)
    n_transform_layers = params.get('n_transform_layers', 1)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)
    projection_hidden_units = params.get('projection_hidden_units', [4, 1])
    apply_final_act = params.get('apply_final_act', False)
    use_bn = params.get('use_bn', False)
    min_timescale = params.get('min_timescale', 1.0)
    max_timescale = params.get('max_timescale', 1.0e4)
    pos_type = params.get('pos_type', 'fixed')
    seed = params.get('seed', 1024)
    mha_type = params.get('mha_type', 'origin')
    lego = params.get('lego', 'preln')

    model = MIANModel(user_fields=user_fields,
                      item_fields=item_fields,
                      context_fields=context_fields,
                      hidden_units=hidden_units,
                      heads=heads,
                      intermediate_size=intermediate_size,
                      n_transform_layers=n_transform_layers,
                      act_fn=act_fn,
                      dropout_rate=dropout_rate,
                      l2_reg=l2_reg,
                      return_all_layers=return_all_layers,
                      projection_hidden_units=projection_hidden_units,
                      apply_final_act=apply_final_act,
                      use_bn=use_bn,
                      seed=seed,
                      min_timescale=min_timescale,
                      max_timescale=max_timescale,
                      pos_type=pos_type,
                      mha_type=mha_type)
    output = model(inputs,
                   extra_input=extra_input,
                   training=training,
                   lego=lego)

  else:
    raise ValueError(
        'specified model_tag {} is not supported'.format(model_tag))

  tf.logging.info('{}, output {}'.format(model_tag, output))
  tf.logging.info(
      '<====== Finish building Alps_biz model_tag {}'.format(model_tag))
  return output
