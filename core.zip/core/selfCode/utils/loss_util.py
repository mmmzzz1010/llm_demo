# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

"""
Paper: Multi-Task Learning Using Uncertainty to Weigh Losses for Scene Geometry and Semantics

Link: http://openaccess.thecvf.com/content_cvpr_2018/papers/Kendall_Multi-Task_Learning_Using_CVPR_2018_paper.pdf

Author: Alex Kendall, Yarin Gal, Roberto Cipolla

Developer: anbo

Date: 2020-05-22

"""

def log10(x, eps=1.e-8):
  numerator = tf.log(x + eps)
  denominator = tf.log(tf.constant(10, dtype=numerator.dtype))
  return numerator / denominator

def gaussian_dist(x, mean, var, eps=1.e-8):
    exp_val = -(x - mean) * (x - mean) / (2 * var * var + eps)
    numerator = tf.exp(exp_val)
    denominator = var * tf.sqrt(2*3.1415926)
    return numerator / (denominator + eps)

def build_classification_loss(labels, logits, clf_var, eps=1.e-8):
    """
    unicertainty for classification loss
    :param labels:
    :param logits:
    :return:
    """
    # with tf.variable_scope("clf_uncertainty", reuse=tf.AUTO_REUSE):
    #     clf_var = tf.get_variable(name='clf_var', shape=[], dtype=tf.float32, initializer=tf.initializers.ones)

    clf_loss = tf.losses.sigmoid_cross_entropy(labels, logits)
    tf.logging.info('uncertainty clf_loss: {}'.format(clf_loss))
    # loss = clf_loss / (clf_var * clf_var + eps) + log10(clf_var, eps)
    factor = tf.div(1.0, tf.multiply(clf_var, clf_var))
    loss = tf.add(tf.multiply(factor, clf_loss), tf.log(clf_var))
    tf.logging.info('uncertainty ce loss: {}'.format(loss))

    return loss

def get_classification_score(logits, name='clf_var', eps=1.e-8):
    with tf.variable_scope("clf_uncertainty", reuse=tf.AUTO_REUSE):
        clf_var = tf.get_variable(name=name, shape=[], dtype=tf.float32,initializer=tf.initializers.random_uniform(minval=0.2, maxval=1))
        #initializer=tf.initializers.ones)
        tf.logging.info('uncertainty clf_uncertainty {}: {}'.format(name, clf_var))
        tf.summary.scalar('train/{}'.format(name), clf_var)

        logit_normed = tf.div(logits, tf.multiply(clf_var, clf_var))

    #return logits/(clf_var * clf_var + eps), clf_var
    return logit_normed, clf_var

def build_regression_loss(labels, logits, reg_var, eps=1.e-8):
    """
    unicertainty for regression loss
    :param labels:
    :param logits:
    :return:
    """
    # with tf.variable_scope("clf_uncertainty", reuse=tf.AUTO_REUSE):
    #     reg_var = tf.get_variable(name='reg_var', shape=[], dtype=tf.float32, initializer=tf.initializers.ones)

    reg_loss = tf.losses.mean_squared_error(labels, logits)
    loss = reg_loss / (2*reg_var * reg_var + eps) + log10(reg_var, eps)
    tf.logging.info('uncertainty mse loss: {}'.format(loss))

    return loss

def get_regression_score(logits, name='reg_var', eps=1.e-8):
    with tf.variable_scope("clf_uncertainty", reuse=tf.AUTO_REUSE):
        reg_var = tf.get_variable(name=name, shape=[], dtype=tf.float32, initializer=tf.initializers.ones)
        tf.logging.info('uncertainty clf_uncertainty reg_var : {}'.format(reg_var))

    return gaussian_dist(logits, reg_var, eps), reg_var


def ssb_fixed_loss(pctr, pcvr, clk_labels, pay_labels):
    with tf.name_scope('Loss'):
        """ Adjusted ssb loss:
                   |  log( P_ctr * P_cvr )        if clk=1 and pay=1
            Loss = |  log( P_ctr * (1-P_cvr) )    if clk=1 and pay=0
                   |  esmm                        if clk=0 and pay=0
        """
    eps = 1e-8

    def safety_log(v):
        return tf.log(tf.clip_by_value(v, eps, 1.0))

    # 1, 1
    pt0 = safety_log(pctr * pcvr) * (clk_labels * pay_labels) / (tf.reduce_sum(clk_labels * pay_labels) + eps)
    # 1, 0
    pt1 = safety_log(pctr * (1 - pcvr)) * (clk_labels * (1 - pay_labels)) / (
                tf.reduce_sum(clk_labels * (1 - pay_labels)) + eps)
    # 0, 0
    pt2 = (safety_log(1 - pctr) + safety_log(1 - pcvr * pctr)) * ((1 - clk_labels) * (1 - pay_labels)) / (
                tf.reduce_sum((1 - clk_labels) * (1 - pay_labels)) + eps)

    loss = -tf.reduce_sum(pt0 + pt1 + pt2)
    return loss


def mutli_task_learning_loss_with_uncertainty(loss_list={}):
    assert len(loss_list) > 0
    loss_weighted = {}
    losses = []
    for name, loss in loss_list.items():
        sigma = tf.get_variable(
            name='loss_weight_%s' % name,
            dtype=tf.float32,
            shape=[],
            initializer=tf.initializers.random_uniform(minval=0.2, maxval=1))
        loss_weighted[name] = sigma
        factor = tf.div(1.0, tf.multiply(2.0, sigma))
        losses.append(tf.add(tf.multiply(factor, loss), tf.log(sigma)))
        tf.summary.scalar('train/loss_weight_%s' % name, sigma)
        tf.summary.scalar('train/loss_val_%s' % name, loss)

    return tf.reduce_sum(losses), loss_weighted


def get_rerank_listwise_loss(label, logits, weights=None, name='rerank', loss_type='listnet'):
    from alps_biz.core.utils import wpo_loss_util as wpo_loss
    approx_ndcg_loss = wpo_loss._approx_ndcg_loss(label, logits,  weights=weights)
    mle_loss = wpo_loss._list_mle_loss(label, logits, weights=weights)
    attrank_loss = wpo_loss._attrank_loss(label, logits)
    listnet_loss = wpo_loss._listnet_loss(label, logits)
    mrr_loss = wpo_loss._approx_mrr_loss(label, logits,  weights=weights)

    tf.summary.scalar('train/{}_approx_ndcg_loss'.format(name), approx_ndcg_loss)
    tf.summary.scalar('train/{}_mle_loss'.format(name), mle_loss)
    tf.summary.scalar('train/{}_attrank_loss'.format(name), attrank_loss)
    tf.summary.scalar('train/{}_listnet_loss'.format(name), listnet_loss)
    tf.summary.scalar('train/{}_mrr_loss'.format(name), mrr_loss)

    metrics = {'eval/{}_approx_ndcg_loss'.format(name): tf.metrics.mean(approx_ndcg_loss),
               'eval/{}_mle_loss'.format(name): tf.metrics.mean(mle_loss),
               'eval/{}_attrank_loss'.format(name): tf.metrics.mean(attrank_loss),
               'eval/{}_listnet_loss'.format(name): tf.metrics.mean(listnet_loss),
               'eval/{}_mrr_loss'.format(name): tf.metrics.mean(mrr_loss)
               }

    if loss_type == 'listnet':
        return listnet_loss, metrics
    elif loss_type == 'ndcg':
        return approx_ndcg_loss, metrics
    elif loss_type == None:
        return metrics
