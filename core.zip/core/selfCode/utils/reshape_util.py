# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
# Author: anbo
# Date: 2020-03-18

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.keras.layers import Dense, Dropout, Lambda, Concatenate, Multiply, Flatten, Activation, BatchNormalization
from tensorflow.python.keras import backend as K


def ListToTensor(inputs,
                 extra_input=None,
                 field_size=12,
                 emb_dim=8,
                 concat_out=True):
  if K.ndim(inputs) == 3:
    return inputs

  inputs_3d = K.reshape(inputs, shape=(-1, field_size, emb_dim))
  if extra_input is None:
    return inputs_3d

  extra_input_3d = extra_input
  if extra_input is not None:
    extra_input_3d = Lambda(lambda x: K.expand_dims(x, axis=1))(extra_input)

  if concat_out:
    return Concatenate(axis=1)([inputs_3d, extra_input_3d])
  else:
    return [inputs_3d, extra_input_3d]


def shrink_tensor(inputs):
  """
    Args:
      inputs: 3d tensor or list of 3d tensor
      fixed_dim: int
    """
  if inputs is None:
    return inputs

  if not isinstance(inputs, (list, tuple)):
    # inputs is a tensor
    inputs = [inputs]

  # hereby, inputs is 3d tensor
  input_lists = []
  for input1 in inputs:
    if K.ndim(input1) == 2:
      input_lists.append(input1)
    else:
      input_lists.append(Flatten()(input1))

  return Concatenate(
      axis=-1)(input_lists) if len(input_lists) > 1 else input_lists[0]
