# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
# Author: anbo
# Date: 2020-03-18

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from alps_biz import get_default_global_id
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.interaction import FMLayer, CrossLayer, CINLayer, CrossMLayer
from alps_biz.core.layer.sequence import MultiHeadAttentionLayer, SelfAttentionLayer, LayerNorm, PositionWiseFeedForwardLayer, TransformerLayer, TransformerEncoder, AutoIntLayer, FuseLayer, SimpleAttnLayer, MultiCNNLayer
from alps_biz.core.layer.attention import ResnetLayer, HighWayLayer, NextItemAttnLayer, SENETLayer, CaserLayer, DSTNLayer, GeneralMultiHeadAttnLayer, WeightedAttentionLayer
from alps_biz.core.layer.attention import SelfRNNAttentionLayer, AttentionOverAttentionLayer, InterestActLayer, DrAttnLayer, SelfAlignLayer, BahdanauAttnLayer, HierarchicalAttnAggLayer
from alps_biz.core.layer.attention import GeneralMMoELayer, CrossStitchLayer, FieldWiseBiInterationLayer, SynthesizerLayer, LinFormerAttnLayer, LocalGlobalLayer, GeneralSelfAttnLayer
from alps_biz.core.layer.multimodality import GatedTanhLayer, DANLayer, RMDANLayer, ParallelCoAttentionLayer, SpatialMemLayer, AttentivePoolingLayer, GatedDNNLayer, CGCGatingNetworkLayer, ParallelDNNLayer, BiLinearInteractionLayer, PRADOAttentionLayer
from alps_biz.core.layer.spatial import AttnAggregationLayer, AttnMatchLayer, CoActionLayer, MaskBlockLayer, ExternalAttentionLayer, gMLPLayer, SGULayer, AITLayer, FATLayer, SequenceAggLayer, WeightedSeqAggLayer, PermuteMLPLayer, PermutatorBlockLayer, DropPathLayer, ContextNetBlockLayer
from alps_biz.core.layer.search import FineSeqLayer, StarTopologyFCNLayer, PartitionedNorm, CapsuleLayer, BridgeLayer, DCAPLayer

import tensorflow as tf
from tensorflow.python.keras.layers import Dense, Dropout, Lambda, Concatenate, Multiply, Flatten, Activation, BatchNormalization
from tensorflow.python.keras import backend as K
from alps_biz.core.utils.reshape_util import ListToTensor, shrink_tensor


def get_layer(inputs, extra_input=None, training=None, params={}):
  """
    Args:
        inputs: 2d tensor or list of 2d tensors
        layer_tag: str
        params: dict, params for each layer

    """
  layer_tag = params.get('layer_tag', 'lr_layer')
  get_default_global_id().add_global_id_info({"BIZ_LAYER_TAG": layer_tag})
  tf.logging.info('-----> Start to build Alps_biz layer {}'.format(layer_tag))
  field_size = params.get('field_size', 12)
  emb_dim = params.get('emb_dim', 8)

  if layer_tag == 'lr_layer':
    # 1, inputs: tensor
    hidden_units = params.get('hidden_units', [1])
    l2_reg = params.get('l2_reg', 0.001)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)

    output = DNNLayer(hidden_units=hidden_units,
                      activation=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate)(inputs, training=training)
    # output: (batch, 1)

  elif layer_tag == 'dnn_layer':
    # 2, inputs: tensor
    hidden_units = params.get('hidden_units', [32, 8])
    l2_reg = params.get('l2_reg', 0.001)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0)

    output = DNNLayer(hidden_units=hidden_units,
                      activation=act_fn,
                      l2_reg=l2_reg,
                      dropout_rate=dropout_rate)(inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'cross_layer':
    # 3, inputs: tensor
    l2_reg = params.get('l2_reg', 0.001)
    n_layers = params.get('n_layers', 4)

    output = CrossLayer(n_layers=n_layers, l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'fm_layer':
    # 4, inputs: list of tensors
    fixed_dim = params.get('fixed_dim', 8)

    fm_input = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # fm_input: (batch, field_size, dim)

    output = FMLayer()(fm_input)
    # output: (batch, k)

  elif layer_tag == 'cin_layer':
    # 5, inputs: list of tensors
    hidden_units = params.get('hidden_units', [10, 10])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)

    cin_input = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # cin_input: (batch, field_size, dim)

    output = CINLayer(hidden_units=hidden_units, act_fn=act_fn,
                      l2_reg=l2_reg)(cin_input)
    # output: (batch, k)

  elif layer_tag == 'resnet_layer':
    # 6, inputs: list of 2d tensor, or 2d tensor
    n_blocks = params.get('n_blocks', 2)
    l2_reg = params.get('l2_reg', 0.001)

    output = ResnetLayer(n_blocks=n_blocks, l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'highway_layer':
    # 7, inputs: list of 2d tensor, or 2d tensor
    act_fn = params.get('act_fn', 'tanh')
    l2_reg = params.get('l2_reg', 0.001)

    output = HighWayLayer(act_fn=act_fn, l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'multiheadattention_layer':
    # 8, inputs: 3d tensor
    hidden_units = params.get('hidden_units', 32)
    heads = params.get('heads', 8)
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    fixed_dim = hidden_units

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # inputs: (batch, n_fields, dim)

    output = MultiHeadAttentionLayer(hidden_units=hidden_units,
                                     heads=heads,
                                     l2_reg=l2_reg,
                                     dropout_rate=dropout_rate)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'transformer_layer':
    # 9,  inputs: 3d tensor
    n_layers = params.get('n_layers', 1)
    hidden_units = params.get('hidden_units', 8)
    heads = params.get('heads', 4)
    intermediate_size = params.get('intermediate_size', 32)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)
    return_all_layers = params.get('return_all_layers', False)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # inputs (batch, fields, dim)

    output = TransformerEncoder(n_layers=n_layers,
                                hidden_units=hidden_units,
                                heads=heads,
                                intermediate_size=intermediate_size,
                                act_fn=act_fn,
                                dropout_rate=dropout_rate,
                                l2_reg=l2_reg,
                                return_all_layers=return_all_layers)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'autoint_layer':
    # 10, inputs: list of 2d tensors, or 3d tensor
    hidden_units = params.get('hidden_units', 8)
    heads = params.get('heads', 4)
    act_fn = params.get('act_fn', 'relu')
    dropout_rate = params.get('dropout_rate', 0.1)
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # inputs (batch, fields, dim)

    output = AutoIntLayer(hidden_units=hidden_units,
                          heads=heads,
                          act_fn=act_fn,
                          dropout_rate=dropout_rate,
                          l2_reg=l2_reg)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'fuse_layer':
    # 11, inputs: list of 2d tensors, or 3d tensor
    input_length = params.get('input_length', 12)
    hidden_units = params.get('hidden_units', [64, 16])
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    use_bn = params.get('use_bn', False)
    weight_norm = params.get('weight_norm', False)

    inputs = ListToTensor(inputs,
                          extra_input,
                          field_size=field_size,
                          emb_dim=emb_dim,
                          concat_out=False)

    output = FuseLayer(input_length=input_length,
                       hidden_units=hidden_units,
                       act_fn=act_fn,
                       l2_reg=l2_reg,
                       dropout_rate=dropout_rate,
                       use_bn=use_bn,
                       weight_norm=weight_norm)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'next_item_attn_layer':
    # 12, inputs: list of 2d tensors, or 3d tensor
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = NextItemAttnLayer(l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'senet_layer':
    # 13, inputs: list of 2d tensors, or 3d tensor
    reduction_ratio = params.get('reduction_ratio', 2)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = SENETLayer(reduction_ratio=reduction_ratio,
                        act_fn=act_fn,
                        l2_reg=l2_reg)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'caser_layer':
    # 14, inputs: list of 2d tensors, or 3d tensor
    h_filters = params.get('h_filters', [4, 6, 8])
    h_kernel = params.get('h_kernel', [2, 4, 5])
    v_filters = params.get('v_filters', [1, 2, 4])

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = CaserLayer(h_filters=h_filters,
                        h_kernel=h_kernel,
                        v_filters=v_filters)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'dstn_layer':
    # 15, inputs: list of 2d tensors, or 3d tensor
    input_dim = params.get('input_dim', 8)
    hidden_units = params.get('hidden_units', [32, 8])
    l2_reg = params.get('l2_reg', 0.001)
    act_fn = params.get('act_fn', 'relu')

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = DSTNLayer(input_dim=input_dim,
                       hidden_units=hidden_units,
                       l2_reg=l2_reg,
                       act_fn=act_fn)(inputs)
    # output: (batch, k)

  elif layer_tag == 'general_multi_head_attn_layer':
    # 16, inputs: 3d tensor
    hidden_units = params.get('hidden_units', 32)
    heads = params.get('heads', 8)
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    list_tag = params.get('list_tag', True)

    #inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)
    # inputs: (batch, n_fields, dim)

    output = GeneralMultiHeadAttnLayer(hidden_units=hidden_units,
                                       heads=heads,
                                       l2_reg=l2_reg,
                                       dropout_rate=dropout_rate,
                                       list_tag=list_tag)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'weighted_attn_layer':
    # 17, inputs: list of 2d tensors, or 3d tensor
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = WeightedAttentionLayer(l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'selfrnn_attn_layer':
    # 18, inputs: list of 2d tensors, or 3d tensor
    s1_unit = params.get('s1_unit', 32)
    s2_unit = params.get('s2_unit', 8)
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = SelfRNNAttentionLayer(s1_unit=s1_unit,
                                   s2_unit=s2_unit,
                                   l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'attn_over_attn_layer':
    # 19, inputs: list of 2d tensors, or 3d tensor
    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = AttentionOverAttentionLayer()(inputs)
    # output: (batch, k)

  elif layer_tag == 'interest_act_layer':
    # 20, inputs: list of 2d tensors, or 3d tensor
    l2_reg = params.get('l2_reg', 0.001)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = InterestActLayer(l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'drattn_layer':
    # 21, inputs: list of 2d tensors, or 3d tensor
    l2_reg = params.get('l2_reg', 0.001)
    return_scaled_a = params.get('return_scaled_a', False)
    return_scaled_b = params.get('return_scaled_b', False)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = DrAttnLayer(l2_reg=l2_reg,
                         return_scaled_a=return_scaled_a,
                         return_scaled_b=return_scaled_b)(inputs)
    # output: (batch, len ,k)

  elif layer_tag == 'self_align_layer':
    # 22, inputs: list of 2d tensors, or 3d tensor
    l2_reg = params.get('l2_reg', 0.001)
    return_scaled_a = params.get('return_scaled_a', False)
    return_scaled_b = params.get('return_scaled_b', False)

    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = SelfAlignLayer(l2_reg=l2_reg,
                            return_scaled_a=return_scaled_a,
                            return_scaled_b=return_scaled_b)(inputs)
    #  output: (batch, len ,k)

  elif layer_tag == 'flen_layer':
    # 23, inputs: 3d tensor
    l2_reg = params.get('l2_reg', 0.001)
    use_bias = params.get('use_bias', True)
    seed = params.get('seed', 1024)

    output = FieldWiseBiInterationLayer(l2_reg=l2_reg,
                                        use_bias=use_bias,
                                        seed=seed)(inputs, training=training)
    #  output: (batch, k)

  elif layer_tag == 'ba_attn_layer':
    # 24, inputs: list of 2d tensors, or 3d tensor
    inputs = ListToTensor(inputs, field_size=field_size, emb_dim=emb_dim)

    output = BahdanauAttnLayer()(inputs)
    # output: (batch, k)

  elif layer_tag == 'cross_stitch_layer':
    # 25, inputs : list
    output = CrossStitchLayer()(inputs)
    # output: list

  elif layer_tag == 'general_mmoe_layer':
    # 26, inputs : list
    num_experts = params.get('num_experts', 4)
    num_tasks = params.get('num_tasks', 2)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = GeneralMMoELayer(num_experts=num_experts,
                              num_tasks=num_tasks,
                              l2_reg=l2_reg,
                              seed=seed)(inputs)
    # output: list

  elif layer_tag == 'synthesizer_layer':
    # 27, inputs : 4d tensor
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = SynthesizerLayer(dim_e=dim_e,
                              synthesizer_type=synthesizer_type,
                              l2_reg=l2_reg,
                              seed=seed)(inputs)
    # output: 3d tensor

  elif layer_tag == 'local_global_layer':
    # 28, inputs : list of 3 4d tensors
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    dropout_rate = params.get('dropout_rate', 0.1)
    inf = params.get('inf', 1e9)
    window = params.get('window', 1)

    output = LocalGlobalLayer(l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              inf=inf,
                              seed=seed,
                              window=window)(inputs, training=training)
    # output: 3d tensor

  elif layer_tag == 'linformer_layer':
    # 29, inputs : list of 3 4d tensor
    dim_e = params.get('dim_e', 3)
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    seed = params.get('seed', 1024)

    output = LinFormerAttnLayer(dim_e=dim_e,
                                l2_reg=l2_reg,
                                dropout_rate=dropout_rate,
                                seed=seed)(inputs, training=training)
    # output: 3d tensor

  elif layer_tag == 'general_selfattn_layer':
    # 30, inputs : 4d tensor
    mha_type = params.get('mha_type', 'vanilla')
    dim_e = params.get('dim_e', 3)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    dropout_rate = params.get('dropout_rate', 0.1)
    inf = params.get('inf', 1e9)
    window = params.get('window', 1)

    output = GeneralSelfAttnLayer(mha_type=mha_type,
                                  dim_e=dim_e,
                                  synthesizer_type=synthesizer_type,
                                  l2_reg=l2_reg,
                                  dropout_rate=dropout_rate,
                                  seed=seed,
                                  inf=inf,
                                  window=window)(inputs, training=training)
    # output: 3d tensor

  elif layer_tag == 'gated_tanh_layer':
    # 31, inputs: tensor
    hidden_units = params.get('hidden_units', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = GatedTanhLayer(hidden_units=hidden_units,
                            l2_reg=l2_reg,
                            seed=seed)(inputs, training=training)
    # output: tensor

  elif layer_tag == 'gated_dnn_layer':
    # 32, inputs: tensor
    hidden_units = params.get('hidden_units', [16, 8])
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = GatedDNNLayer(hidden_units=hidden_units, l2_reg=l2_reg,
                           seed=seed)(inputs, training=training)
    # output: tensor

  elif layer_tag == 'dan_layer':
    # 33, inputs: list of 3d tensors or list of 3d tensor and 2d tensor
    hidden_units = params.get('hidden_units', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    text_attention = params.get('text_attention', False)

    output = DANLayer(hidden_units=hidden_units,
                      l2_reg=l2_reg,
                      seed=seed,
                      text_attention=text_attention)(inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'rm_dan_layer':
    # 34, inputs: list of 3d tensors or list of 3d tensor and 2d tensor
    hidden_units = params.get('hidden_units', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    n_dan_layers = params.get('n_dan_layers', 2)
    text_attention = params.get('text_attention', True)
    vis_attention = params.get('vis_attention', True)
    shared_agg_attention = params.get('shared_agg_attention', True)

    output = RMDANLayer(hidden_units=hidden_units,
                        l2_reg=l2_reg,
                        seed=seed,
                        n_dan_layers=n_dan_layers,
                        text_attention=text_attention,
                        vis_attention=vis_attention,
                        shared_agg_attention=shared_agg_attention)(
                            inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'parallel_coattention_layer':
    # 35, inputs: list of 3d tensors
    hidden_units = params.get('hidden_units', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = ParallelCoAttentionLayer(hidden_units=hidden_units,
                                      l2_reg=l2_reg,
                                      seed=seed)(inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'spatial_mem_layer':
    # 36, inputs: list of 3d tensors
    hidden_units = params.get('hidden_units', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = SpatialMemLayer(hidden_units=hidden_units,
                             l2_reg=l2_reg,
                             seed=seed)(inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'attentive_pooling_layer':
    # 37, inputs: list of 3d tensors or list of 3d tensor and 2d tensor
    hidden_units = params.get('hidden_units', [8, 1])
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    activation = params.get('activation', 'relu')
    dropout_rate = params.get('dropout_rate', 0)

    output = AttentivePoolingLayer(hidden_units=hidden_units,
                                   activation=activation,
                                   dropout_rate=dropout_rate,
                                   l2_reg=l2_reg,
                                   seed=seed)(inputs, training=training)
    # output: (batch, k)

  elif layer_tag == 'cgc_gating_network_layer':
    # 38, inputs: list of 2 3d tensors and 1 2d tensor
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = CGCGatingNetworkLayer(l2_reg=l2_reg, seed=seed)(inputs,
                                                             training=training)
    # output: (batch, k)

  elif layer_tag == 'parallel_dnn_layer':
    # 39, inputs: 3d tensor
    hidden_units = params.get('hidden_units', [8, 1])
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    activation = params.get('activation', 'relu')
    dropout_rate = params.get('dropout_rate', 0)
    use_bn = params.get('use_bn', False)
    apply_final_act = params.get('apply_final_act', False)
    n_experts = params.get('n_experts', 2)

    output = ParallelDNNLayer(hidden_units=hidden_units,
                              activation=activation,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              apply_final_act=apply_final_act,
                              seed=seed,
                              n_experts=n_experts)(inputs, training=training)
    # output: (batch, len, k)

  elif layer_tag == 'bilinear_interaction_layer':
    # 40, inputs: 3d tensor
    bilinear_type = params.get('bilinear_type', 'field_all')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = BiLinearInteractionLayer(bilinear_type=bilinear_type,
                                      l2_reg=l2_reg,
                                      seed=seed)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'multicnn_layer':
    # 41, inputs: 3d tensor
    filters = params.get('filters', [4, 4, 4])
    kernel_size = params.get('kernel_size', [1, 3, 6])

    output = MultiCNNLayer(filters=filters, kernel_size=kernel_size)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'prado_layer':
    # 42, inputs: 3d tensor
    projection_filters = params.get('projection_filters', [4, 4, 4])
    projection_kernels = params.get('projection_kernels', [1, 3, 6])
    attn_filters = params.get('attn_filters', [4, 4, 4])
    attn_kernels = params.get('attn_kernels', [1, 3, 6])

    output = PRADOAttentionLayer(projection_filters=projection_filters,
                                 projection_kernels=projection_kernels,
                                 attn_filters=attn_filters,
                                 attn_kernels=attn_kernels)(inputs)
    # output: (batch, len, k)

  elif layer_tag == 'crossm_layer':
    # 43, inputs: tensor
    l2_reg = params.get('l2_reg', 0.001)
    n_layers = params.get('n_layers', 4)
    output = CrossMLayer(n_layers=n_layers, l2_reg=l2_reg)(inputs)
    # output: (batch, k)

  elif layer_tag == 'hierarchical_attn_layer':
    # 44, inputs: tensor
    n_layers = params.get('n_layers', 4)
    hidden_size = params.get('hidden_size', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = HierarchicalAttnAggLayer(n_layers=n_layers,
                                      hidden_size=hidden_size,
                                      l2_reg=l2_reg,
                                      seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'attn_aggregation_layer':
    # 45, inputs: tensor
    hidden_size = params.get('hidden_size', 16)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = AttnAggregationLayer(hidden_size=hidden_size,
                                  l2_reg=l2_reg,
                                  seed=seed)(inputs)
    # output: (batch, len, hidden_size)

  elif layer_tag == 'attn_match_layer':
    # 46, inputs: tensor
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = AttnMatchLayer(l2_reg=l2_reg, seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'co_action_layer':
    # 47, inputs: tensor
    hidden_units = params.get('hidden_units', [8, 4])
    apply_final_act = params.get('apply_final_act', False)
    use_bias = params.get('use_bias', True)

    output = CoActionLayer(hidden_units=hidden_units,
                           apply_final_act=apply_final_act,
                           use_bias=use_bias)(inputs)
    # output: (batch, k)

  elif layer_tag == 'mask_block_layer':
    # 48, inputs: tensor
    apply_ln_emb = params.get('apply_ln_emb', True)
    hidden_size = params.get('hidden_size', 32)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = MaskBlockLayer(apply_ln_emb=apply_ln_emb,
                            hidden_size=hidden_size,
                            l2_reg=l2_reg,
                            seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'external_attention_layer':
    # 49, inputs: tensor
    hidden_size = params.get('hidden_size', 32)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = ExternalAttentionLayer(hidden_size=hidden_size,
                                    l2_reg=l2_reg,
                                    seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'gmlp_layer':
    # 50, inputs: tensor
    n_layers = params.get('n_layers', 1)
    ff_mult = params.get('ff_mult', 4)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = gMLPLayer(n_layers=n_layers,
                       ff_mult=ff_mult,
                       l2_reg=l2_reg,
                       seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'sgu_layer':
    # 51, inputs: tensor
    output = SGULayer()(inputs)
    # output: (batch, k)

  elif layer_tag == 'ait_layer':
    # 52, inputs: tensor
    hidden_size = params.get('hidden_size', 32)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = AITLayer(hidden_size=hidden_size, l2_reg=l2_reg,
                      seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'fat_layer':
    # 53, inputs: tensor
    output = FATLayer()(inputs)

  elif layer_tag == 'sequence_agg_layer':
    # 54, inputs: tensor
    agg_tag = params.get('agg_tag', 'mean_pooling')
    num_inputs = params.get('num_inputs', 1)

    output = SequenceAggLayer(agg_tag=agg_tag, num_inputs=num_inputs)(inputs)
    # output: (batch, k)

  elif layer_tag == 'weighted_seq_agg_layer':
    # 55, inputs: tensor
    n_inputs = params.get('n_inputs', 2)
    temperature = params.get('temperature', 1)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = WeightedSeqAggLayer(n_inputs=n_inputs,
                                 temperature=temperature,
                                 ff_mult=ff_mult,
                                 l2_reg=l2_reg,
                                 seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'permute_mlp_layer':
    # 56, inputs: tensor
    segment_dim = params.get('segment_dim', 4)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = PermuteMLPLayer(segment_dim=segment_dim, l2_reg=l2_reg,
                             seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'permutator_block_layer':
    # 57, inputs: tensor
    intermediate_size = params.get('intermediate_size', 32)
    segment_dim = params.get('segment_dim', 4)
    skip_lam = params.get('skip_lam', 1.0)
    drop_prob = params.get('drop_prob', 0.0)
    act_fn = params.get('act_fn', 'relu')
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = PermutatorBlockLayer(intermediate_size=intermediate_size,
                                  segment_dim=segment_dim,
                                  skip_lam=skip_lam,
                                  drop_prob=drop_prob,
                                  act_fn=act_fn,
                                  l2_reg=l2_reg,
                                  seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'drop_path_layer':
    # 58, inputs: tensor
    drop_prob = params.get('drop_prob', 0.0)
    seed = params.get('seed', 1024)

    output = DropPathLayer(drop_prob=drop_prob, seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'contextnet_block_layer':
    # 59, inputs: tensor
    hidden_size = params.get('hidden_size', 32)
    share_aggregation_tag = params.get('share_aggregation_tag', True)
    point_fnn_tag = params.get('point_fnn_tag', False)
    contextnet_block_layers = params.get('contextnet_block_layers', 1)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = ContextNetBlockLayer(
        hidden_size=hidden_size,
        share_aggregation_tag=share_aggregation_tag,
        point_fnn_tag=point_fnn_tag,
        contextnet_block_layers=contextnet_block_layers,
        l2_reg=l2_reg,
        seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'FwSeq_block_layer':
    # 60, inputs: tensor
    n_layers = params.get('n_layers', 1)
    drop_prob = params.get('drop_prob', 0.0)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = FineSeqLayer(n_layers=n_layers,
                          drop_prob=drop_prob,
                          l2_reg=l2_reg,
                          seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'star_fcn_layer':
    # 61, inputs: tensor
    hidden_units = params.get('hidden_units', [16, 8])
    num_domains = params.get('num_domains', 2)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)
    apply_final_act = params.get('apply_final_act', False)

    output = StarTopologyFCNLayer(hidden_units=hidden_units,
                                  num_domains=num_domains,
                                  l2_reg=l2_reg,
                                  seed=seed,
                                  apply_final_act=apply_final_act)(inputs)
    # output: (batch, k)

  elif layer_tag == 'partitioned_norm_layer':
    # 62, inputs: tensor
    num_domains = params.get('num_domains', 2)
    momentum = params.get('momentum', 0.99)
    l2_reg = params.get('l2_reg', 0.001)
    eps = params.get('eps', 1024)

    output = PartitionedNorm(num_domains=num_domains,
                             momentum=momentum,
                             l2_reg=l2_reg,
                             eps=eps)(inputs)
    # output: (batch, k)

  elif layer_tag == 'capsule_layer':
    # 63, inputs: tensor
    num_capsules = params.get('num_capsules', 2)
    hidden_units = params.get('hidden_units', 16)
    routings = params.get('routings', 3)
    eps = params.get('eps', 1024)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = CapsuleLayer(num_capsules=num_capsules,
                          hidden_units=hidden_units,
                          routings=routings,
                          l2_reg=l2_reg,
                          eps=eps,
                          seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'capsulenet_layer':
    # 64, inputs: tensor
    num_capsules = params.get('num_capsules', 2)
    hidden_units = params.get('hidden_units', 16)
    routings = params.get('routings', 3)
    eps = params.get('eps', 1024)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = CapsuleNetLayer(num_capsules=num_capsules,
                             hidden_units=hidden_units,
                             routings=routings,
                             l2_reg=l2_reg,
                             eps=eps,
                             seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'bridge_layer':
    # 65, inputs: tensor
    n_layers = params.get('n_layers', 1)
    l2_reg = params.get('l2_reg', 0.001)
    seed = params.get('seed', 1024)

    output = BridgeLayer(n_layers=n_layers, l2_reg=l2_reg, seed=seed)(inputs)
    # output: (batch, k)

  elif layer_tag == 'dcap_layer':
    # 66, inputs: tensor
    hidden_units = params.get('hidden_units', 8)
    heads = params.get('heads', 4)
    l2_reg = params.get('l2_reg', 0.001)
    dropout_rate = params.get('dropout_rate', 0.1)
    seed = params.get('seed', 1024)
    n_layers = params.get('n_layers', 2)
    list_tag = params.get('list_tag', False)
    act_fn = params.get('act_fn', 'relu')
    mha_type = params.get('mha_type', 'origin')
    dim_e = params.get('dim_e', None)
    synthesizer_type = params.get('synthesizer_type', 'dense')
    window = params.get('window', 1)
    concat_heads = params.get('concat_heads', True)
    pool_size = params.get('pool_size', 2)
    strides = params.get('strides', 1)
    product_type = params.get('product_type', 'inner')

    output = DCAPLayer(hidden_units=hidden_units,
                       heads=heads,
                       l2_reg=l2_reg,
                       dropout_rate=dropout_rate,
                       seed=seed,
                       list_tag=list_tag,
                       mha_type=mha_type,
                       dim_e=dim_e,
                       synthesizer_type=synthesizer_type,
                       window=window,
                       concat_heads=concat_heads,
                       pool_size=pool_size,
                       strides=strides,
                       product_type=product_type,
                       n_layers=n_layers)(inputs)
    # output: (batch, k)

  else:
    raise ValueError(
        'specified layer_tag {} is not supported'.format(layer_tag))

  tf.logging.info('----> Finish building Alps_biz layer {}: output {}'.format(
      layer_tag, output))
  return output
