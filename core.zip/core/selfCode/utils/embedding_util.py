# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
# Author: anbo
# Date: 2020-03-18

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

def tfplus_fc_util(key, num_shards, columns, dimension, group_flag,
                   initializer=tf.keras.initializers.glorot_normal(),
                   combiner='sum', trainable=True, sparse_suffix_flag=False):
    import tfplus.feature_column as fc_ext

    if not group_flag:
        assert isinstance(dimension, int)
        columns.append(
            fc_ext.kv_embedding_column(
                fc_ext.categorical_column_with_identity(
                    "{}".format(key) if not sparse_suffix_flag else "{}_0".format(key)),
                dimension=dimension,
                num_shards=num_shards,
                initializer=initializer,
                combiner=combiner,
                trainable=trainable
            )
        )
    else:
        assert isinstance(dimension, list)
        for pos, val in enumerate(dimension):
            columns.append(
                fc_ext.kv_embedding_column(
                    fc_ext.categorical_column_with_identity("{}_{}".format(key, pos)),
                    dimension=val,
                    num_shards=num_shards,
                    initializer=initializer,
                    combiner=combiner,
                    trainable=trainable
                )
            )


def tfplus_fc_embedding_util(key, num_shards, features, dimension, group_flag,
                             initializer=tf.keras.initializers.glorot_normal(),
                             combiner='mean', trainable=True, name="kv_features",
                             sparse_suffix_flag=False):
    from tensorflow.python.feature_column import feature_column_v2 as fc

    columns = []
    tfplus_fc_util(key, num_shards, columns, dimension, group_flag, initializer, combiner, trainable,
                   sparse_suffix_flag)
    feature_layer = fc.DenseFeatures(columns, trainable=trainable, name=name)
    return feature_layer(features)