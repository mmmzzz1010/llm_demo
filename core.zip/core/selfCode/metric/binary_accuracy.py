# coding:utf-8
# @Author: yunjian
# @Date: 2019-12-10
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf


class BinaryAccuracy(tf.keras.metrics.BinaryAccuracy):
    """Wraps tf.keras.metrics.BinaryAccuracy."""
    def __init__(self, logits_key, **kwargs):
        """
        Args:
            logits_key: The key of corresponding tensor in model output dict.

        """
        self._logits_key = logits_key
        super(BinaryAccuracy, self).__init__(**kwargs)

    def update_state(self, labels, model_output_dict, sample_weights=None):
        """
        Args:
            labels: Label tensor
            model_output_dict: A dict model output tensors
            weights: Sample weights when calculating binary
                accuracy. See tf.keras.metrics.BinaryAccuracy
                for more details.

        """
        logits = model_output_dict[self._logits_key]
        return super(BinaryAccuracy, self).update_state(labels, logits, sample_weights)

