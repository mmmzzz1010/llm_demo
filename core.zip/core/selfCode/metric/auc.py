# coding:utf-8
# @Author: yunjian
# @Date: 2019-11-26
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf


class AUC(object):
    """Wraps tf.metrics.auc to calculate auc in alps-biz."""
    def __init__(self, pred_key):
        """
        Args:
            pred_key: the key of corresponding tensor in model output dict.

        """
        self._pred_key = pred_key

    def __call__(self, labels, model_output_dict):
        """
        Args:
            labels: label tensor
            model_output_dict: a dict model output tensors
            weights: sample weights when calculating loss. See
                tf.losses.compute_weighted_loss for more details.

        """
        preds = model_output_dict[self._pred_key]
        return tf.metrics.auc(labels, preds)
