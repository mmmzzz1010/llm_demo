# coding: utf-8
# @Author: anbo
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.spatial import AITLayer


class AITMModel(tf.keras.Model):
  """
    Model: AITM Model

    Paper: Modeling the Sequential Dependence among Audience Multi-step Conversions with Multi-task Learning in Targeted Display Advertising

    Link: https://arxiv.org/abs/2105.08489

    Author: Dongbo Xi, Zhen Chen, Peng Yan, Yinger Zhang, Yongchun Zhu, Fuzhen Zhuang, Yu Chen

    Developer: anbo

    Date: 2021-06-01

    inputs: 2d tensor (batch_size, n_dim)

    outputs: list of 2d tensor [input_a, input_b]
             input_a: (batch_size, 1)
             input_b: (batch_size, 1)

    """
  def __init__(self,
               task_hidden_units=[[16, 8], [16, 8]],
               task_apply_final_act=False,
               act_fn='relu',
               l2_reg=0.001,
               dropout_rate=0,
               use_bn=False,
               seed=1024,
               name='AITMModel'):
    """
    Args:
        task_hidden_units: list of list, task_hidden_units[i] is list of hidden units in each task hidden layers
        task_apply_final_act, boolean, whether apply activation at the last layer of each task
        act_fn: string, activation function
        l2_reg: float, regularization value
        dropout_rate: float, fraction of the units to dropout.
        use_bn: boolean, if True, apply BatchNormalization in each hidden layer
        seed: int, random value for initialization

    """
    super(AITMModel, self).__init__(name='AITMModel')

    assert (task_hidden_units is not None and len(task_hidden_units) > 1), (
        'Must specify task_hidden_units with at least one unit')

    self.num_tasks = len(task_hidden_units)
    tf.logging.info('AITMModel with {} tasks'.format(self.num_tasks))

    self.task_adaptive_info_layers = []
    self.ait_layers = []
    for i in range(self.num_tasks - 1):
      task_projection_unit = task_hidden_units[i + 1][-1]
      self.task_adaptive_info_layers.append(
          tf.keras.layers.Dense(
              task_projection_unit,
              activation=None,
              kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
              name='{}_task_adaptive_info_layer'.format(i)))

      self.ait_layers.append(
          AITLayer(hidden_size=task_projection_unit,
                   l2_reg=l2_reg,
                   seed=seed,
                   name='{}_ait_layer'.format(i)))

    self.task_layers = []
    self.task_projection_layers = []
    for i, units in enumerate(task_hidden_units):
      self.task_layers.append(
          DNNLayer(hidden_units=units,
                   activation=act_fn,
                   l2_reg=l2_reg,
                   dropout_rate=dropout_rate,
                   use_bn=use_bn,
                   apply_final_act=task_apply_final_act,
                   seed=seed,
                   name="{}_task_{}_dnn_layer".format(name, i)))
      self.task_projection_layers.append(
          tf.keras.layers.Dense(
              1,
              activation=None,
              kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
              name='{}_task_projection_layer'.format(i)))

  def call(self, inputs, training=None):
    """
    Args:
        inputs: 2d tensor (batch_size, n_dim)

    Returns:
        list of 2d tensor [ctr_output, cvr_output]
            ctr_output: (batch_size, 1)
            cvr_output: (batch_size, 1)

    """
    task_outputs = []
    for i in range(self.num_tasks):
      task_outputs.append(self.task_layers[i](inputs, training=training))
      tf.logging.info('AITMModel: {}th task, task_output {}'.format(
          i, task_outputs[-1]))

    task_ait_outputs = []
    task_ait_outputs.append(task_outputs[0])
    for i in range(self.num_tasks - 1):
      task_adaptive_info_input = self.task_adaptive_info_layers[i](
          task_outputs[i])
      task_ait_outputs.append(
          self.ait_layers[i]([task_adaptive_info_input, task_outputs[i + 1]]))
      tf.logging.info('AITMModel: {}th task, task_ait_output {}'.format(
          i, task_ait_outputs[-1]))

    for i in range(self.num_tasks):
      task_ait_outputs[i] = self.task_projection_layers[i](task_ait_outputs[i])

    return task_ait_outputs

  def constraint_loss(self, y_pred_prev, y_pred_curr):
    pred_constraint = tf.maximum(y_pred_curr - y_pred_prev,
                                 tf.zeros_like(y_pred_prev))
    return tf.reduce_mean(pred_constraint)
