# coding: utf-8
# @Author: anbo
# @Date: 2020-10-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.multimodality import GatedDNNLayer, GatedTanhLayer
from alps_biz.core.layer.core import DNNLayer

class GateNetModel(tf.keras.Model):
    """
    Model: Gate Net model

    Paper: GateNet:Gating-Enhanced Deep Network for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/2007.03519

    Author: Tongwen Huang, Qingyun She, Zhiqiang Wang, Junlin Zhang

    Developer: anbo

    Date: 2020-10-09

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, l2_reg=0.001, seed=1024,
                 embedding_gate=False, hidden_gate=True
                 ,name='GateNetModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(GateNetModel, self).__init__(name='GateNetModel')
        self.embedding_gate = embedding_gate
        self.hidden_gate = hidden_gate

        if self.embedding_gate:
            self.gatedtanh_layer = GatedTanhLayer(hidden_units=None, l2_reg=l2_reg, seed=seed, name="{}_gated_feature_embedding_layer".format(name))

        if self.hidden_gate:
            self.gateddnn_layer = GatedDNNLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, name="{}_gateddnn_layer".format(name))
        else:
            self.gateddnn_layer = DNNLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features
            wide_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        if self.embedding_gate:
            gated_embedding_output = self.gatedtanh_layer(inputs, training=training)
        else:
            gated_embedding_output = inputs
        tf.logging.info('GateNetModel: gated_embedding_output {}'.format(gated_embedding_output))

        dnn_output = self.gateddnn_layer(gated_embedding_output, training=training)
        tf.logging.info('GateNetModel: dnn_output {}'.format(dnn_output))

        if extra_input is None:
            combined_output = dnn_output
        else:
            combined_output = tf.keras.layers.Concatenate()([dnn_output, extra_input])
        tf.logging.info('GateNetModel: combined_output {}'.format(combined_output))

        return combined_output

