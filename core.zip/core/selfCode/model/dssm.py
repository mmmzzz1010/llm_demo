# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.
import tensorflow as tf
from tensorflow.python.keras.layers import Dot


class DssmModel(tf.keras.Model):
    """DssmModel.

    `alps_biz.core.model.DssmModel` as its base model structure. See
    https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/cikm2013_DSSM_fullversion.pdf
    for more details.

    Author: liyang

    Developer: liyang

    """
    def __init__(self, mode, base_hidden_units, dropout_rate, output_embedding_dim):
        """
        Args:
            mode: estimator mode
            base_hidden_units: int array, for user_feature and item_feature
            dropout_rate: int
            output_embedding_dim: int,for user_feature and item_feature

        """
        super(DssmModel, self).__init__(name='DssmModel')
        self.base_hidden_units = base_hidden_units
        self.dropout_rate = dropout_rate
        self.mode = mode
        self.output_embedding_dim = output_embedding_dim

    def call(self, user_feature, item_feature):
        """Build DssmModel

        Args:
            user_feature : tensor.
            item_feature : tensor.

        Returns:
            user_output_embedding: tensor
            item_output_embedding: tensor
            logits: tensor, dot of user_output_embedding and item_output_embedding

        """
        user_output_embedding = self.base_model(user_feature)
        item_output_embedding = self.base_model(item_feature)
        logits = Dot(axes=1)([user_output_embedding, item_output_embedding])
        return user_output_embedding, item_output_embedding, logits

    def base_model(self, features):
        """
        Args:
            features: tensor, the input_embedding of item or user

        Returns:
            output_embedding: tensor,

        """
        net = features
        for units in self.base_hidden_units:
            net = tf.layers.dense(net, units=units, activation=tf.nn.relu)
            if self.dropout_rate > 0.0:
                net = tf.layers.dropout(net, self.dropout_rate, training=(self.mode == tf.estimator.ModeKeys.TRAIN))
        output_embedding = tf.layers.dense(net, self.output_embedding_dim, activation=None)
        return output_embedding

