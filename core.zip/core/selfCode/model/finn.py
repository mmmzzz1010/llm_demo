# coding: utf-8
# @Author: anbo
# @Date: 2021-06-02
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.spatial import FATLayer

class FINNModel(tf.keras.Model):
    """
    Model: GRU4Rec Model

    Paper: FINN: Feedback Interactive Neural Network for Intent Recommendation

    Link: https://www.atatech.org/paper/1472

    Author: Yatao Yang, Biyu Ma, Jun Tan, Hongbo Deng, Haikuan Huang, Zibin Zheng

    Developer: anbo

    Date: 2021-06-02

    inputs: list of 3d tensors, [seq_1, seq_2,...]
            seq_i: (batch, seq_len, hidden_units)

    output: (batch, hidden_units)

    """
    def __init__(self, hidden_units=[16, 8], projection_hidden_units=[8, 1],
                 act_fn='relu', l2_reg=0.001, dropout_rate=0,
                 apply_final_act=False, use_bn=False, seed=1024, name='FINNModel'):
        """
        Args:
            apply_final_act: whether to apply act in final layer
            projection_hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(FINNModel, self).__init__(name='FINNModel')
        self.fat_layer = FATLayer(name="{}_fat_layer".format(name))
        self.pos_sequence_projection_layer = DNNLayer(hidden_units=hidden_units, activation='tanh', l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=True, seed=seed, name="{}_pos_sequence_projection_layer".format(name))

        self.neg_sequence_projection_layer = DNNLayer(hidden_units=hidden_units, activation='tanh', l2_reg=l2_reg,
                                                      dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=True,
                                                      seed=seed, name="{}_neg_sequence_projection_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, mask=None, extra_input=None, training=None):
        """
        Args:
            there could be multiple types of sequence input, by default the last one is the negative sequence
            inputs: list of 3d tensors, sequence features, [seq_1, seq_2,...]
                    seq_i: (batch, seq_len, hidden_units)
            extra_input: 2d tensor (batch_size, dim_2), wide features
            mask: list of mask of sequence pairs,

        Returns:
            2d tensor (batch_size, out_dim)

        """
        pos_sequence_outputs = []
        mask_0 = None
        # by default, last sequence in inputs is the negative one
        for i in range(len(inputs) - 1):
            if mask is not None and i+1 >= len(mask):
                mask_i = mask[i]
            else:
                mask_i = None

            if i==0:
                mask_0 = 1.0 - mask_i if mask_i is not None else None

            feedback_output_i = self.fat_layer([inputs[i], inputs[-1]], mask=mask_i)
            tf.logging.info('FINNModel: feedback_output_i {}'.format(feedback_output_i))
            pos_sequence_outputs.append(feedback_output_i)

        neg_sequence_output = self.fat_layer([inputs[-1], inputs[0]], mask=mask_0)

        pos_feedback_output = tf.keras.layers.Concatenate(axis=-1)(pos_sequence_outputs) if len(pos_sequence_outputs)>1 else pos_sequence_outputs[0]
        pos_projection_output = self.pos_sequence_projection_layer(pos_feedback_output)
        tf.logging.info('FINNModel: pos_projection_output {}'.format(pos_projection_output))

        neg_projection_output = self.neg_sequence_projection_layer(neg_sequence_output)
        tf.logging.info('FINNModel: neg_projection_output {}'.format(neg_projection_output))

        combined_input = tf.keras.layers.Concatenate(axis=-1)([pos_projection_output, neg_projection_output])
        tf.logging.info('FINNModel: combined_input {}'.format(combined_input))

        if extra_input is not None:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([combined_input, extra_input])
            tf.logging.info('FINNModel: combined_input {}'.format(combined_input))

        output = self.dnn_layer(combined_input, training=training)
        tf.logging.info('FINNModel: output: {}'.format(output))
        return output
