# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import FuseLayer
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.activation_layer import Dice

class DINModel(tf.keras.Model):
    """
    Model: DIN Model

    Paper: Deep Interest Network for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1706.06978

    Author: Guorui Zhou, Chengru Song, Xiaoqiang Zhu, Ying Fan, Han Zhu, Xiao Ma, Yanghui Yan, Junqi Jin, Han Li, Kun Gai

    Developer: anbo

    Date: 2019-12-09

    inputs: list with length of 2, [input_a, input_b]
        input_a and input_b must have the same shape, (batch, a_len, dim)

    outputs: (batch, a_len, output_size)

    """
    def __init__(self, input_length, hidden_units=[16,4], projection_hidden_units=[4, 1], apply_final_act=False, act_fn='relu',
                 dropout_rate=0, l2_reg=0.001, use_bn=False, weight_norm=False, seed=1024, name='DINModel'):
        """
        Args:
            input_length: int, sequence length of behaviour features
            hidden_units: list, units for the MLP layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, dropout rate
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
            weight_norm: boolean, if True scale the attention score
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
        """
        super(DINModel, self).__init__(name='DINModel')
        self.input_length = input_length
        self.din_layer = FuseLayer(input_length=input_length, hidden_units=hidden_units, act_fn=act_fn,
                                  l2_reg=l2_reg, dropout_rate=dropout_rate, use_bn=use_bn,
                                  seed=seed, weight_norm=weight_norm, name="{}_fuse_layer".format(name))

        # self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
        #                           dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed)
        self.dnn_layer, self.act_fn_layer = [], []
        for i, unit in enumerate(projection_hidden_units):
            self.dnn_layer.append(tf.keras.layers.Dense(unit, activation=None, use_bias=True,
                                                   kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
                                                   kernel_regularizer=tf.keras.regularizers.L1L2(0, l2_reg), name="{}_dense_{}_layer".format(name, i)))
            self.act_fn_layer.append(Dice(name="{}_dice_{}_layer".format(name, i)))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of 3d tensor (batch, seq_len, hidden_units)
            extra_input: 2d tensor, (batch, dim), user, item and context features
        Returns:
            2d tensor (batch_size, out_dim)

        """
        n_len = tf.keras.backend.int_shape(inputs[0])[1]
        tf.logging.info('n_len {}, input_length {}'.format(n_len, self.input_length))
        if n_len is not None:
            assert (n_len == self.input_length), ("length of inputs must equal to the parameter input_length")

        din_output = self.din_layer(inputs, training=training)

        if extra_input is not None:
            if tf.keras.backend.ndim(din_output) > 2:
                din_output = tf.keras.layers.Flatten()(din_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([din_output, extra_input])
            tf.logging.info('DINModel: combined_input {}'.format(combined_input))

            #din_output = self.dnn_layer(combined_input, training=training)
            din_output = combined_input
            for i in range(len(self.dnn_layer)):
                din_output = self.dnn_layer[i](din_output)
                din_output = self.act_fn_layer[i](din_output, training=training)
                tf.logging.info('DINModel: layer {}, din_output {}'.format(i, din_output))

        tf.logging.info('DINModel: din_output {}'.format(din_output))
        return din_output

