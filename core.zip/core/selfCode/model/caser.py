# coding: utf-8
# @Author: anbo
# @Date: 2020-02-10
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import CaserLayer

class CaserModel(tf.keras.Model):
    """
    Model: Caser Model

    Paper: Personalized Top-N Sequential Recommendation via Convolutional Sequence Embedding

    Link: http://www.sfu.ca/~jiaxit/resources/wsdm18caser.pdf

    Author: Jiaxi Tang, Ke Wang

    Developer: anbo

    Date: 2020-03-25

    inputs: (batch, a_len, dim)

    returns: (batch, dim)

    """
    def __init__(self, h_filters=[4, 6, 8], h_kernel=[2, 4, 5], v_filters=[1, 2, 4], l2_reg=0.001, act_fn='relu', dropout_rate=0,
                 projection_hidden_units=[4, 1], apply_final_act=False, use_bn=False, seed=1024, name='CaserModel'):
        """
        Args:
            h_filters: list, number of filters in each 1d conv channel
            h_kernel: list, kernel size in each 1d conv channel
            v_filters: list, number of filters in each 1d conv channel
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
            dropout_rate: float, dropout rate
            act_fn: string, activation function
        """
        super(CaserModel, self).__init__(name='CaserModel')

        self.caser_layer = CaserLayer(h_filters=h_filters, h_kernel=h_kernel, v_filters=v_filters, seed=seed, name="{}_caser_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: (batch, a_len, dim)

        Returns:
            (batch, dim)

        """
        caser_output = self.caser_layer(inputs)
        tf.logging.info('CaserModel: caser_output {}'.format(caser_output))

        if extra_input is not None:
            if tf.keras.backend.ndim(caser_output) > 2:
                caser_output = tf.keras.layers.Flatten()(caser_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([caser_output, extra_input])
            tf.logging.info('CaserModel: combined_input {}'.format(combined_input))

            caser_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('CaserModel: caser_output: {}'.format(caser_output))
        return caser_output
