from alps_biz.core.layer.monomf import MonoMFLayer
from alps_biz.core.common.constants import Constants
from alps_biz.core.layer.multitask_meta_layers import ESMMMetaLayer
from tensorflow import keras
from tensorflow.keras.layers import Activation


class MonoMFModel(keras.Model):
    """MonoMFModel is a pricing model which takes user info and price, and calculates the probability
    that the user will respond to this price.

    Please refer to
    https://yuque.antfin-inc.com/docs/share/e2b38683-d005-4e5f-a02f-bb31d281c058?#91966b24

    """
    def __init__(self,
                 task_name_to_label_name,
                 feature_shapes,
                 cost_vocabulary_list,
                 deep_embed_dims,
                 cost_embedding_dim,
                 monotonic_embed_alpha=0.0001,
                 essm_task_dependencies=None):
        """
        Args:
            task_name_to_label_name: A dict maps task name to label name.
            feature_shapes: A dict maps feature name to feature shape.
            cost_vocabulary_list: A list of cost levels.
            deep_embed_dims: An integer or a dictionary.
            cost_embedding_dim: The embedding dimension of cost.
            monotonic_embed_alpha: The leaky relu alpha of monotonic embedding layer.
            essm_task_dependencies: A list of task dependencies, See `ESMMMetaLayer` for details.

        """
        super(MonoMFModel, self).__init__('MonoMFModel')
        self.feature_shapes = feature_shapes
        self.deep_embed_dims = deep_embed_dims
        layer_factory = lambda: MonoMFLayer(cost_vocabulary_list, cost_embedding_dim, monotonic_embed_alpha)
        self.multitask_meta_layer = ESMMMetaLayer(
            task_name_to_label_name,
            essm_task_dependencies,
            layer_factory=layer_factory,
        )
        self.activation = Activation('sigmoid')

    def call(self, deep_inputs, dense_inputs, before_level_tensor):
        from alps.core.layer.sparse_embedding import SparseEmbeddingLayer2D

        deep_embeddings = []
        for name, sp_tensor in sorted(deep_inputs.items(), key=lambda x: x[0]):
            embed_dim = self.deep_embed_dims
            if isinstance(embed_dim, dict):
                embed_dim = embed_dim[name]
            embed_layer = SparseEmbeddingLayer2D(self.feature_shapes[name],
                                                 embed_dim,
                                                 name="deep_embedding_layer_" + name)
            embedding = embed_layer(sp_tensor)
            embedding.set_shape((None, embed_dim))
            embedding._keras_shape = (None, embed_dim)
            deep_embeddings.append(embedding)

        user_tensor_list = deep_embeddings + [
            dense_inputs[key] for key in sorted(dense_inputs.keys())
        ]
        user_embedding = keras.layers.Concatenate(axis=1, name="concat_all_user_tensors")(user_tensor_list)

        task_output = self.multitask_meta_layer([user_embedding, before_level_tensor])
        task_output_new = {}
        for task_name, logits in task_output.items():
            logistic = self.activation(logits)
            task_output_new[task_name] = {Constants.LOGITS: logits, Constants.LOGISTIC: logistic}
        return task_output_new
