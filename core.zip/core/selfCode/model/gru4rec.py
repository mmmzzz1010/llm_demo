# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer


class GRU4RecModel(tf.keras.Model):
    """
    Model: GRU4Rec Model

    Paper: Session-based Recommendations with Recurrent Neural Networks

    Link: https://arxiv.org/abs/1511.06939

    Author: Balázs Hidasi, Alexandros Karatzoglou, Linas Baltrunas, Domonkos Tikk

    Developer: anbo

    Date: 2020-04-08

    inputs: (batch, seq_len, hidden_units)

    output: (batch, hidden_units)

    """
    def __init__(self, rnn_unit, projection_hidden_units=[8, 1], rnn_act_fn='tanh', act_fn='relu', return_sequences=False, l2_reg=0.001, dropout_rate=0,
                 apply_final_act=False, use_bn=False, seed=1024, name='GRU4RecModel'):
        """
        Args:
            rnn_unit: int, rnn hidden units
            rnn_act_fn: string, activation function in rnn
            return_sequences: bool, whether return hidden states of rnn
            apply_final_act: whether to apply act in final layer
            projection_hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(GRU4RecModel, self).__init__(name='GRU4RecModel')
        self.rnn_layer = tf.keras.layers.GRU(units=rnn_unit, activation=rnn_act_fn, return_sequences=return_sequences, return_state=False, name="{}_gru_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 3d tensor (batch_size, len, dim_1), sequence features
            extra_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        rnn_output = self.rnn_layer(inputs)
        tf.logging.info('GRU4RecModel: rnn_output {}'.format(rnn_output))

        if extra_input is not None:
            if tf.keras.backend.ndim(rnn_output) > 2:
                rnn_output = tf.keras.layers.Flatten()(rnn_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([rnn_output, extra_input])
            tf.logging.info('GRU4RecModel: combined_input {}'.format(combined_input))

            rnn_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('GRU4RecModel: rnn_output: {}'.format(rnn_output))
        return rnn_output
