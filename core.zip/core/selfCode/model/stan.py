# coding: utf-8
# @Author: anbo
# @Date: 2021-04-08
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.spatial import AttnAggregationLayer,AttnMatchLayer
from alps_biz.core.layer.core import DNNLayer

class STANModel(tf.keras.Model):
    """
    Model: STAN model

    paper: STAN: Spatio-Temporal Attention Network for Next Location Recommendation

    Link: https://arxiv.org/abs/2102.04095

    Author: Yingtao Luo, Qiang Liu, Zhaocheng Liu

    Developer: anbo

    Date: 2021-04-08

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_size, l2_reg=0.001, seed=1024, projection_hidden_units=[8, 1], act_fn='relu', dropout_rate=0,
                 apply_final_act=False, use_bn=False, name='STANModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(STANModel, self).__init__(name='STANModel')

        self.attn_agg_layer = AttnAggregationLayer(hidden_size=hidden_size, l2_reg=l2_reg, seed=seed, name="{}_attention_aggregation_layer".format(name))
        self.attn_match_layer = AttnMatchLayer(l2_reg=l2_reg, seed=seed, name="{}_attention_match_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed,
                                  name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features
            wide_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        user_hist_input, candidate_items, spatial_temporal_delta, spatial_temporal_matrix = inputs

        trajectory_hidden = self.attn_agg_layer([user_hist_input, spatial_temporal_delta])
        agg_output = self.attn_match_layer([candidate_items, trajectory_hidden, spatial_temporal_matrix])

        if extra_input is not None:
            if tf.keras.backend.ndim(agg_output) > 2:
                agg_output = tf.keras.layers.Flatten()(agg_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([agg_output, extra_input])
            tf.logging.info('STANModel: combined_input {}'.format(combined_input))
        else:
            combined_input = agg_output

        output = self.dnn_layer(combined_input, training=training)
        tf.logging.info('STANModel: output {}'.format(output))
        return output

