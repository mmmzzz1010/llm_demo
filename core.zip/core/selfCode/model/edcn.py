# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.search import BridgeLayer


class EDCNModel(tf.keras.Model):
  """
    Model: EDCN Model

    Paper: Enhancing Explicit and Implicit Feature Interactions via Information Sharing for Parallel Deep CTR Models

    Link: https://dl.acm.org/doi/abs/10.1145/3459637.3481915

    Author: Chen, Bo and Wang, Yichao and Liu, Zhirong and Tang, Ruiming and Guo, Wei and Zheng, Hongkun and Yao, Weiwei and Zhang, Muyu and He, Xiuqiang

    Developer: anbo

    Date: 2021-11-16

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, out_dim)

  """
  def __init__(self,
               projection_hidden_units=[4, 1],
               act_fn='relu',
               l2_reg=0.001,
               dropout_rate=0,
               use_bn=False,
               n_cross_layers=2,
               seed=1024,
               name='EDCNModel'):
    """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            n_cross_layers: int, num of cross layers
            seed: int, random value for initialization

        """
    super(EDCNModel, self).__init__(name='EDCNModel')
    self.bridge_layer = BridgeLayer(n_layers=n_cross_layers,
                                    l2_reg=l2_reg,
                                    name="{}_bridge_layer".format(name))
    self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units,
                              activation=act_fn,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              seed=seed,
                              apply_final_act=False,
                              name="{}_dnn_layer".format(name))

  def call(self, inputs, training=None):
    """
        Args:
            inputs: 2d tensor (batch_size, n_dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
    cross_output = self.bridge_layer(inputs)
    output = self.dnn_layer(cross_output, training=training)
    tf.logging.info('EDCNModel: output {}'.format(output))
    return output
