# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer

class XPAModel(tf.keras.Model):
    """
    Model: XPA Model

    Paper: Cross-Positional Attention for Debiasing Clicks

    Link: https://research.google/pubs/pub50099/

    Author: Honglei Zhuang, Zhen Qin, Xuanhui Wang, Mike Bendersky, Xinyu Qian, Po Hu, Chary Chen

    Developer: anbo

    Date: 2021-04-16

    note: it is recommended to reverse the order of item context and label list

    inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)

    returns:
            2d tensor (batch_size, seq_len)

    """
    def __init__(self, input_length=6, hidden_units=[16], relevance_hidden_units=[8,1], examination_hidden_units=[8,1],
                    min_timescale=1.0, max_timescale=1.0e4, pos_type='learnable',
                    act_fn='relu', l2_reg=0.001, dropout_rate=0,
                    seed=1024, shared_pv=False, name='XPAModel'):
        """
        Args:
            hidden_units: int, the last dim of the inputs
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
        """
        super(XPAModel, self).__init__(name='XPAModel')
        self.hidden_size = hidden_units[-1] if isinstance(hidden_units, list) else hidden_units
        self.hidden_units = hidden_units
        self.shared_pv = shared_pv

        self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale,
                                                      pos_type=pos_type, add_pos=False, name="{}_pos_enco_layer".format(name))

        if self.shared_pv:
            self.dnn_layer = tf.keras.layers.TimeDistributed(DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                         dropout_rate=dropout_rate, use_bn=False, apply_final_act=True,
                         seed=seed, name="{}_shared_u2i_interact_layer".format(name)))
        else:
            self.dnn_layer_list = []
            for i in range(input_length):
                self.dnn_layer_list.append(DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=False, apply_final_act=True,
                                                    seed=seed, name="{}_separate_u2i_interact_layer_{}".format(name, i)))

        self.relevance_scorer_layer = tf.keras.layers.TimeDistributed(DNNLayer(hidden_units=relevance_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=False, apply_final_act=False,
                                                    seed=seed, name="{}_relevance_scorer_layer".format(name)))

        self.examination_scorer_layer = tf.keras.layers.TimeDistributed(
            DNNLayer(hidden_units=examination_hidden_units, activation=act_fn, l2_reg=l2_reg,
                     dropout_rate=dropout_rate, use_bn=False, apply_final_act=False,
                     seed=seed, name="{}_examination_scorer_layer".format(name)))

        self.lambda_w = tf.get_variable(name='lambda_w', shape=[], dtype=tf.float32, initializer=tf.initializers.ones())
        self.weight_e = tf.get_variable(name='weight_e', shape=[], dtype=tf.float32, initializer=tf.initializers.ones())
        self.weight_r = tf.get_variable(name='weight_r', shape=[], dtype=tf.float32, initializer=tf.initializers.ones())

    def call(self, inputs, pos_input=None, extra_input=None, mask=None, training=None):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)
            pos_input: (batch, seq_len, hidden_units)
            mask: (batch, seq_len), padded position with mask=1
        Returns:
            2d tensor (batch_size, seq_len)

        """
        seq_len = inputs.get_shape()[1].value
        context_input = inputs
        if extra_input is not None:
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(extra_input)
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.tile(x, [1, seq_len, 1]))(extra_input_3d)
            tf.logging.info('XPAModel: extra_input_3d {}'.format(extra_input_3d))
            context_input = tf.keras.layers.Concatenate(axis=-1)([inputs, extra_input_3d])
        tf.logging.info('XPAModel: context_input {}'.format(context_input))

        if self.shared_pv:
            context_seq_input = self.dnn_layer(context_input)
            tf.logging.info('XPAModel: shared pv context_seq_input {}'.format(context_seq_input))
        else:
            context_seq_input_list = []
            for i in range(seq_len):
                user_item_input_i = self.dnn_layer_list[i](context_input[:, i, :])
                user_item_input_i = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(
                    user_item_input_i)
                context_seq_input_list.append(user_item_input_i)
            context_seq_input = tf.keras.layers.Concatenate(axis=1)(context_seq_input_list) if len(
                context_seq_input_list) > 1 else context_seq_input_list[0]
            tf.logging.info('XPAModel: separate pv context_seq_input {}'.format(context_seq_input))

        if pos_input is None:
            pos_input = self.position_layer(context_seq_input)
        # else:
        # pos_input = self.position_layer(pos_input)

        # cross-positional attention
        pos_input_transposed = tf.keras.backend.permute_dimensions(pos_input, (0, 2, 1))
        pos_attn_weight = tf.matmul(pos_input, pos_input_transposed)
        # pos_attn_weight: (batch, seq_len, seq_len)
        pos_attn_weight = pos_attn_weight*self.lambda_w
        if mask is not None:
            tf.logging.info('XPAModel: apply mask')
            mask_3d = mask[:, tf.newaxis, :]
            pos_attn_weight += -1e9 * tf.cast(mask_3d, tf.float32)
        pos_attn_score = tf.nn.softmax(pos_attn_weight, axis=-1)

        context_seq_pos_input = tf.matmul(pos_attn_score, context_seq_input)
        pos_attn_input = tf.matmul(pos_attn_score, pos_input)

        # relevance_scorer
        context_relevance_output = self.relevance_scorer_layer(context_seq_input)
        context_pos_relevance_output = self.relevance_scorer_layer(context_seq_pos_input)

        # examination scorer
        exam_pos_output = self.examination_scorer_layer(pos_input)
        exam_attn_pos_output = self.examination_scorer_layer(pos_attn_input)

        if mask is not None:
            mask_3d1 = mask[:, :, tf.newaxis]
            mask_3d1 = 1.0 - tf.cast(mask_3d1, tf.float32)
            exam_pos_output *= mask_3d1
            exam_attn_pos_output *= mask_3d1

        cross_pos_output = exam_pos_output + self.weight_e * exam_attn_pos_output + self.weight_r * context_pos_relevance_output
        tf.logging.info('XPAModel: cross_pos_output {}'.format(cross_pos_output))

        # attention_weight = tf.add(tf.tensordot(rnn_last_state, self.weight_w, axes=[-1, 0]), self.bias)
        # attention_weight: (batch, k, dim)

        output = context_relevance_output + cross_pos_output
        output = tf.squeeze(output, axis=-1)
        # score: (batch, len)
        tf.logging.info('XPAModel: output: {}'.format(output))
        return output
