# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.interaction import CrossMLayer


class DCNMModel(tf.keras.Model):
    """
    Model: DCN-M model

    Paper: DCN-M: Improved Deep & Cross Network for Feature Cross Learning in Web-scale Learning to Rank Systems

    Link: https://arxiv.org/abs/2008.13535

    Author: Ruoxi Wang, Rakesh Shivanna, Derek Z. Cheng, Sagar Jain, Dong Lin, Lichan Hong, Ed H. Chi

    Developer: anbo

    Date: 2020-10-21

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

    """
    def __init__(self, hidden_units=[16], projection_hidden_units=[1], act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 n_cross_layers=2, apply_final_act=False, seed=1024, name='DCNMModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            n_cross_layers: int, num of cross layers
            seed: int, random value for initialization

        """
        super(DCNMModel, self).__init__(name='DCNMModel')
        self.crossm_layer = CrossMLayer(n_layers=n_cross_layers, l2_reg=l2_reg, name="{}_crossm_layer".format(name))
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))
        self.projection_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                         dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False, seed=seed,
                                         name="{}_projection_layer".format(name))

    def call(self, inputs, lego='parallel', training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, n_dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        if lego == 'parallel':
            cross_output = self.crossm_layer(inputs)
            dnn_output = self.dnn_layer(inputs, training=training)
            combined_output = tf.keras.layers.Concatenate()([cross_output, dnn_output])
            output = self.projection_layer(combined_output)
        else:
            # stacked
            cross_output = self.crossm_layer(inputs)
            output = self.dnn_layer(cross_output, training=training)

        tf.logging.info('DCNMModel: output {}'.format(output))
        return output
