# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.model.dcn import DCNModel


class CrossSharingModel(tf.keras.Model):
    """
    Model: Cross Sharing Model

    Developer: anbo

    Date: 2020-03-23

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
    def __init__(self, dcn_hidden_units, sharing_hidden_units, task_hidden_units, n_cross_layers=4, task_apply_final_act=False,
                 act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 seed=1024, name='CrossSharingModel'):
        """
        Args:
            dcn_hidden_units: list, unit in each hidden layer
            sharing_hidden_units: list, unit in each hidden layer
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            n_cross_layers: int, num of cross layers
            seed: int, random value for initialization

        """
        super(CrossSharingModel, self).__init__(name='CrossSharingModel')
        self.dcn_model = DCNModel(hidden_units=dcn_hidden_units, act_fn=act_fn, l2_reg=l2_reg, dropout_rate=dropout_rate,
                                  use_bn=use_bn, n_cross_layers=n_cross_layers, seed=seed, name="{}_dcnmodel".format(name))

        self.sharing_layer = DNNLayer(hidden_units=sharing_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, name="{}_sharing_dnn_layer".format(name))

        self.n_tasks = len(task_hidden_units)
        self.task_layers = []
        for i in range(self.n_tasks):
            units = task_hidden_units[i]
            self.task_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                      dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=task_apply_final_act, seed=seed, name="{}_task_{}_dnn_layer".format(name, i)))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features

        Returns:
            list of 2d tensor (batch_size, out_dim)

        """
        dcn_output = self.dcn_model(inputs, training=training)
        tf.logging.info('CrossSharingModel: dcn_output {}'.format(dcn_output))

        sharing_output = self.sharing_layer(dcn_output, training=training)
        tf.logging.info('CrossSharingModel: sharing_output {}'.format(sharing_output))

        task_outputs = []
        for i in range(self.n_tasks):
            task_outputs.append(self.task_layers[i](sharing_output, training=training))
            tf.logging.info('CrossSharingModel: {}th task, task_output {}'.format(i, task_outputs[-1]))

        return task_outputs

