# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import FieldWiseBiInterationLayer

class FLENModel(tf.keras.Model):
    """
    Model: FLEN Model

    Paper: FLEN: Leveraging Field for Scalable CTR Prediction

    Link: https://arxiv.org/pdf/1911.04690.pdf

    Author: Wenqiang Chen, Lizhang Zhan, Yuanlong Ci,Chen Lin

    Developer: anbo

    Date: 2020-04-23

    inputs:
        inputs: list of 3d tensor (batch_size, n_field, dim_1), deep features
        extra_input: 2d tensor (batch_size, dim_2), wide features

    rturns:
            2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, projection_hidden_units, apply_final_act=False, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 use_bias=True, seed=1024, name='FLENModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            hidden_units: list, unit in final projection layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(FLENModel, self).__init__(name='FLENModel')
        self.flen_layer = FieldWiseBiInterationLayer(l2_reg=l2_reg, use_bias=use_bias, seed=seed, name="{}_fwbi_layer".format(name))
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, name="{}_dnn_layer".format(name))
        self.projection_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, apply_final_act=apply_final_act, name="{}_projection_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of 3d tensor (batch_size, n_field, dim_1), deep features
            extra_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        fm_mf_output = self.flen_layer(inputs)
        tf.logging.info('FLENModel: fm_mf_output {}'.format(fm_mf_output))

        concat_input = tf.keras.layers.Concatenate(axis=1)(inputs) if len(inputs)>1 else inputs[0]
        concat_input = tf.keras.layers.Flatten()(concat_input)
        tf.logging.info('FLENModel: concat_input {}'.format(concat_input))

        dnn_output = self.dnn_layer(concat_input, training=training)

        if extra_input is None:
            combined_output = tf.keras.layers.Concatenate()([fm_mf_output, dnn_output])
        else:
            combined_output = tf.keras.layers.Concatenate()([fm_mf_output, dnn_output, extra_input])

        flen_output = self.projection_layer(combined_output, training=training)
        tf.logging.info('FLENModel: flen_output {}'.format(flen_output))
        return flen_output

