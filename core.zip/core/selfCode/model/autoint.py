# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import AutoIntLayer
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer

class AutoIntModel(tf.keras.Model):
    """
    Model: AutoInt Model

    Paper: AutoInt: Automatic Feature Interaction Learning via Self-Attentive Neural Networks

    Link: https://arxiv.org/abs/1810.11921

    Author: Weiping Song, Chence Shi, Zhiping Xiao, Zhijian Duan, Yewen Xu, Ming Zhang, Jian Tang

    Developer: anbo

    Date: 2019-12-09

    inputs: (batch, seq_len, hidden_units)

    output: (batch, hidden_units)

    """
    def __init__(self, hidden_units, heads, projection_hidden_units=[4, 1], apply_final_act=False,
                 act_fn='relu', dropout_rate=0, l2_reg=0.001, use_bn=False, seed=1024,
                 min_timescale=1.0, max_timescale=1.0e4, pos_type='fixed',
                 mha_type='origin',
                 dim_e=3,
                 synthesizer_type='dense',
                 inf=1e9,
                 name='AutoIntModel'):
        """
        Args:
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
        """
        super(AutoIntModel, self).__init__(name='AutoIntModel')
        self.hidden_units = hidden_units
        assert (hidden_units % heads==0), ('hidden_units must be dividable by heads')
        self.pos_type = pos_type

        if self.pos_type != 'no_pos':
            self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale, pos_type = self.pos_type, name="{}_pos_enco_layer".format(name))

        self.autoint_layer = AutoIntLayer(hidden_units=hidden_units, heads=heads, act_fn=act_fn,
                                          dropout_rate=dropout_rate, l2_reg=l2_reg,
                                          mha_type=mha_type, dim_e=dim_e, synthesizer_type=synthesizer_type, inf=inf,
                                          name="{}_autoint_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None, lego='standard'):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)

        Returns:
            2d tensor (batch, hidden_units)

        """
        input_dim = tf.keras.backend.int_shape(inputs)[-1]
        assert (input_dim==self.hidden_units), ("last dim of inputs must equal to hidden_units")

        if self.pos_type != 'no_pos':
            seq_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(input_dim, tf.float32))))(inputs)
            seq_input = self.position_layer(seq_input)
        else:
            seq_input = inputs

        autoint_output = self.autoint_layer(seq_input, training=training, lego=lego)

        if extra_input is not None:
            if tf.keras.backend.ndim(autoint_output) > 2:
                autoint_output = tf.keras.layers.Flatten()(autoint_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([autoint_output, extra_input])
            tf.logging.info('AutoIntModel: combined_input {}'.format(combined_input))

            autoint_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('AutoIntModel: autoint_output {}'.format(autoint_output))
        return autoint_output
