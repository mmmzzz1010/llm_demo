# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

class GMVESMMModel(tf.keras.Model):
    """
    Model: GMV ESMM Model

    Paper: Entire Space Multi-Task Model: An Effective Approach for Estimating Post-Click Conversion Rate

    Link: https://arxiv.org/abs/1804.07931

    Author: Xiao Ma, Liqin Zhao, Guan Huang, Zhi Wang, Zelin Hu, Xiaoqiang Zhu, Kun Gai

    Developer: muxi

    Date: 2020-04-08

    inputs: 2d tensor (batch_size, n_dim)

    outputs: list of 2d tensor [input_a, input_b]
             input_a: (batch_size, 1)
             input_b: (batch_size, 1)

    """

    def __init__(self, ctr_hidden_units, gmv_hidden_units, act_fn='relu', l2_reg=0.001, dropout_rate=0.2, use_bn=False, seed=1024):
        """
        Args:
            ctr_hidden_units: int, unit in ctr hidden layer
            gmv_hidden_units: int, unit in cvr hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(GMVESMMModel, self).__init__(name='GMVESMMModel')
        assert (ctr_hidden_units is not None and isinstance(ctr_hidden_units, int) is True), (
            'Must specify ctr_hidden_units with one unit')
        assert (gmv_hidden_units is not None and isinstance(gmv_hidden_units, int) is True), (
            'Must specify cvr_hidden_units with one unit')

        self.ctr_last_layer = tf.keras.layers.Dense(1, activation=None,
                                                     kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
                                                     name='ctr_last_dense_layer')
        self.gmv_last_layer = tf.keras.layers.Dense(1, activation=None,
                                                     kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
                                                     name='gmv_last_dense_layer')
        self.act_layer = tf.keras.layers.Activation(activation=act_fn)

        self.drop_layer = tf.keras.layers.Dropout(rate=dropout_rate)

        self.ctr_layer = tf.keras.layers.Dense(ctr_hidden_units, activation=None,
                                                     kernel_initializer="glorot_uniform",
                                                     name='ctr_dense_layer')
        self.gmv_layer = tf.keras.layers.Dense(gmv_hidden_units, activation=None,
                                                     kernel_initializer="glorot_uniform",
                                                     name='gmv_dense_layer')

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, n_dim)

        Returns:
            list of 2d tensor [ctr_output, cvr_output]
             ctr_output: (batch_size, 1)
             cvr_output: (batch_size, 1)

        """
        #--------------------------cvr part-------------------------------
        cvr_layer1 = self.drop_layer(self.act_layer(inputs), training=training)
        cvr_layer2 = self.ctr_layer(cvr_layer1)
        tf.logging.info('GMVESMMModel: cvr_layer2 {}'.format(cvr_layer2))
        cvr_layer3 = tf.keras.layers.Concatenate(axis=-1)([cvr_layer2, extra_input]) if extra_input is not None else cvr_layer2
        cvr_layer4 = self.drop_layer(self.act_layer(cvr_layer3), training=training)
        tf.logging.info('GMVESMMModel: ctr_hidden {}'.format(cvr_layer4))

        ctr_output = self.ctr_last_layer(cvr_layer4)
        tf.logging.info('ESMMEstimator: cvr_output {}'.format(ctr_output))

        #-------------------------gmv part------------------------------
        gmv_layer1 = self.drop_layer(self.act_layer(inputs), training=training)
        gmv_layer2 = self.gmv_layer(gmv_layer1)
        tf.logging.info('GMVESMMModel: gmv_layer2 {}'.format(gmv_layer2))
        gmv_layer3 = tf.keras.layers.Concatenate(axis=-1)([gmv_layer2, inputs])
        gmv_layer4 = self.drop_layer(self.act_layer(gmv_layer3), training=training)
        tf.logging.info('GMVESMMModel: gmv_hidden {}'.format(gmv_layer4))

        gmv_output = self.gmv_last_layer(gmv_layer4)
        tf.logging.info('ESMMEstimator: gmv_output {}'.format(gmv_output))

        return ctr_output, gmv_output
