# coding: utf-8
# @Author: anbo
# @Date: 2020-09-22
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.multimodality import RMDANLayer


class RMDANModel(tf.keras.Model):
    """
    Model: r- and m-dan model for vqa and image-text matching

    Paper: Dual Attention Networks for Multimodal Reasoning and Matching

    Link: http://static.naver.net/clova/service/clova_ai/research/publications/Dual.Attention.Networks.for.Multimodal.Reasoning.and.Matching.pdf

    Author: Hyeonseob Nam, Jung-Woo Ha, Jeonghee Kim

    Developer: anbo

    Date: 2020-09-22

    """
    def __init__(self, hidden_units, l2_reg=0, seed=1024, n_dan_layers=2,
                 text_attention=True, vis_attention=True, shared_agg_attention=True, 
                 projection_hidden_units=[4,1], apply_final_act=False, use_bn=False, act_fn='relu', dropout_rate=0,
                 name='RMDANModel'):
        """
        Args:
            hidden_units: int
            l2_reg: float, regularization value
            seed: int, random value for initialization
            text_attention: bool
        """
        super(RMDANModel, self).__init__(name='RMDANModel')
        self.dan_layer = RMDANLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, n_dan_layers=n_dan_layers, 
                                   text_attention=text_attention, vis_attention=vis_attention, shared_agg_attention=shared_agg_attention, name="{}_rmdan_layer".format(name))

        self.final_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_projection_layer".format(name))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: list of 3d tensors

        Returns:
            2d tensor (batch_size, out_dim)

        """
        dan_output = self.dan_layer(inputs, training=training)

        output = self.final_layer(dan_output, training=training)
        tf.logging.info('RMDANModel: output {}'.format(output))
        return output

