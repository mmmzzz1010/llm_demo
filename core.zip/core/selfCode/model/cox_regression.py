import tensorflow as tf
from tensorflow.keras.regularizers import L1L2
from tensorflow.keras.layers import LeakyReLU
from alps_biz.core.layer.cox_regression_layer import CoxRegressionLayer
from alps_biz.core.common.parse_inputs import parse_dense_inputs, parse_sparse_inputs
from alps_biz.core.common.constants import Constants


class CoxRegressionModel(tf.keras.Model):
    """Cox regression model, or cox proportional hazards model, is a commonly used statisitcal model.

    Please refer to wikipedia for more details:
    https://en.wikipedia.org/wiki/Proportional_hazards_model

    Author: 开远、易山、云谏

    """
    def __init__(self, dnn_sparse_feas_list, dnn_dense_feas_list, dense_cost_fea, hidden_units, embedding_dims, feature_shapes, l2_reg=0.0, l1_reg=0.0, embedding_transform_layer=None, cost_transform_layer=None, max_amount=None):
        """
        Args:
            dnn_sparse_feas_list: A list of column names of dnn sparse features.
            dnn_dense_feas_list: A list of column names of dnn dense features.
            dense_cost_fea: The column name of dense cost.
            hidden_units: The hidden unit number of dense layer.
            embedding_dims: An integer or a dict. If an integer, it is the embedding dimension for all sparse features.
            If a dict, it specifies embedding dimension for each sparse feature.
            feature_shapes: A dict of feature shapes for all sparse features.
            l2_reg: The coefficient for l2 regularization.
            l1_reg: The coefficient for l1 regularization.
            embedding_transform_layer: A string or a callable object that speficifies the layer
                for embedding transformation.
            cost_transform_layer: A string or a callable object that specifies the layer for
                cost transformation.
            max_amount: A number specifies the max value of cost.
        """
        super(CoxRegressionModel, self).__init__('CoxRegressionModel')
        self.dnn_sparse_feas_list = dnn_sparse_feas_list
        self.dnn_dense_feas_list = dnn_dense_feas_list
        self.dense_cost_fea = dense_cost_fea
        self.embedding_dims = embedding_dims
        self.feature_shapes = feature_shapes

        self.dense1 = tf.keras.layers.Dense(hidden_units, activation=LeakyReLU(0.2), kernel_regularizer=L1L2(l1_reg, l2_reg), bias_regularizer=L1L2(l1_reg, l2_reg))
        self.concat_all_user_tensors = tf.keras.layers.Concatenate(axis=1, name="concat_all_user_tensors")
        self.cox_reg_layer = CoxRegressionLayer(embedding_transform_layer, cost_transform_layer, max_amount, l2_reg, l1_reg)

    def call(self, features):
        deep_embed_dict = parse_sparse_inputs(features, self.dnn_sparse_feas_list, self.embedding_dims, self.feature_shapes)
        deep_embed_list = [value for name, value in sorted(deep_embed_dict.items(), key=lambda x: x[0])]

        dense_input_dict = parse_dense_inputs(features, self.dnn_dense_feas_list)
        dense_input_list = [value for name, value in sorted(dense_input_dict.items(), key=lambda x: x[0])]

        dense_cost_tensor = features[self.dense_cost_fea]
        if dense_cost_tensor.dtype == tf.string:
            dense_cost_tensor = tf.string_to_number(dense_cost_tensor, tf.float32)

        user_tensor_list = deep_embed_list + dense_input_list
        user_embedding = self.concat_all_user_tensors(user_tensor_list)

        user_embedding = self.dense1(user_embedding)
        logits = self.cox_reg_layer([user_embedding, dense_cost_tensor])
        logistic = 1.0 - tf.exp(-logits)
        logits = tf.clip_by_value(logits, 1e-7, 1e5)

        return {Constants.LOGITS: logits, Constants.LOGISTIC: logistic}
