# coding: utf-8
# @Author: anbo
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.search import StarTopologyFCNLayer, PartitionedNorm


class STARModel(tf.keras.Model):
  """
    Model: STAR Model

    Paper: One Model to Serve All: Star Topology Adaptive Recommender for Multi-Domain CTR Prediction

    Link: https://arxiv.org/abs/2101.11427

    Author: Xiang-Rong Sheng, Liqin Zhao, Guorui Zhou, Xinyao Ding, Binding Dai, Qiang Luo, Siran Yang, Jingshan Lv, Chi Zhang, Hongbo Deng, Xiaoqiang Zhu

    Developer: anbo

    Date: 2021-08-17

    inputs: 2d tensor (batch_size, n_dim)

    outputs: list of 2d tensor [input_1, input_2, ....]
             input_x: (batch_size, 1)

    """
  def __init__(self,
               hidden_units=[16, 8, 1],
               aux_hidden_units=[4, 1],
               num_domains=2,
               act_fn='relu',
               l2_reg=0.001,
               dropout_rate=0,
               use_bn=False,
               seed=1024,
               apply_final_act=False,
               momentum=0.99,
               eps=1.e-6,
               name='STARModel'):
    """
        Args:
            hidden_units: list, unit in both shared and domain hidden layers
            num_domains: int, number of domains or tasks
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
    super(STARModel, self).__init__(name='STARModel')
    assert (hidden_units is not None and len(hidden_units) > 0), (
        'Must specify hidden_units with at least one unit')
    assert (hidden_units[-1] == aux_hidden_units[-1]), (
        'Last dim of hidden_units and aux_hidden_units must be the same')
    self.num_domains = num_domains
    self.star_fc_layer = StarTopologyFCNLayer(
        hidden_units=hidden_units,
        num_domains=self.num_domains,
        l2_reg=l2_reg,
        seed=seed,
        apply_final_act=apply_final_act,
        name='{}_star_topology_fc_layer'.format(name))

    self.pn_layer = PartitionedNorm(
        num_domains=self.num_domains,
        momentum=momentum,
        l2_reg=l2_reg,
        eps=eps,
        name='{}_partitioned_norm_layer'.format(name))

    self.aux_fc_layer = DNNLayer(hidden_units=aux_hidden_units,
                                 activation=act_fn,
                                 l2_reg=l2_reg,
                                 dropout_rate=dropout_rate,
                                 use_bn=use_bn,
                                 seed=seed,
                                 apply_final_act=apply_final_act,
                                 name='{}_aux_fc_layer'.format(name))

  def call(self,
           inputs,
           domain_split_size=None,
           domain_index=0,
           extra_input=None,
           training=None):
    """
    Args:
        inputs: 2d tensor (batch_size, n_dim1)
        domain_split_size: list of int, size of data samples from each domain
        extra_inputs: mainly domain id related features, 2d tensor (batch_size, n_dim2)
        domain_index: int

    Returns:
            list of 2d tensor [input_1, input_2, ....]
             input_x: (batch_size, 1)
    """
    domain_inputs = self.pn_layer(inputs,
                                  domain_index=domain_index,
                                  training=training)
    star_fc_output = self.star_fc_layer(domain_inputs,
                                        domain_index=domain_index,
                                        training=training)

    # if training == tf.estimator.ModeKeys.TRAIN or training == tf.estimator.ModeKeys.EVAL:
    #   mode = True
    #   domain_inputs = tf.split(inputs,
    #                            num_or_size_splits=domain_split_size,
    #                            axis=0,
    #                            name='domain_split')
    #   tf.logging.info(
    #       'STARModel: domain split, domain_inputs {}'.format(domain_inputs))

    #   star_fc_output_list = []
    #   for i in range(self.num_domains):
    #     domain_inputs[i] = self.pn_layer(domain_inputs[i],
    #                                      domain_index=i,
    #                                      training=mode)
    #     star_fc_output_i = self.star_fc_layer(domain_inputs[i],
    #                                           domain_index=i,
    #                                           training=mode)
    #     tf.logging.info('STARModel: star_fc_output {} of domain {}'.format(
    #         star_fc_output_i, i))
    #     star_fc_output_list.append(star_fc_output_i)
    #   star_fc_output = tf.keras.layers.Concatenate(
    #       axis=0)(star_fc_output_list
    #               ) if len(star_fc_output_list) > 1 else star_fc_output_list[0]
    # # star_fc_output = self.star_fc_layer(domain_inputs, training=training)
    # # star_fc_output: list of 2d tensors, each of (batch, dim)
    # else:
    #   mode = False
    #   domain_inputs = self.pn_layer(inputs,
    #                                 domain_index=domain_index,
    #                                 training=mode)
    #   star_fc_output = self.star_fc_layer(domain_inputs,
    #                                       domain_index=domain_index,
    #                                       training=mode)

    tf.logging.info('STARModel: star_fc_output {}'.format(star_fc_output))

    if extra_input is not None:
      mode = (training == tf.estimator.ModeKeys.TRAIN)
      domain_input = tf.keras.layers.Concatenate(axis=-1)(
          [inputs, extra_input])
      aux_fc_output = self.aux_fc_layer(domain_input, training=mode)
      tf.logging.info('STARModel: aux_fc_output {} of domain {}'.format(
          aux_fc_output, domain_index))
      star_fc_output = tf.add(star_fc_output, aux_fc_output)
      tf.logging.info('STARModel: star_fc_output {} of domain {}'.format(
          star_fc_output, domain_index))

    return star_fc_output
