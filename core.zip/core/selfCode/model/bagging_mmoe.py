import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import GeneralMMoELayer
# from alps_biz.core.layer.interaction import CrossLayer
from alps_biz.core.layer.sequence import SelfAttentionLayer
import random
from random import shuffle


class BaggingMSLMMoEModel(tf.keras.Model):
    """
    Model: Bagging MMoE

    Paper:

    Link:

    Author:

    Developer: muxi

    Date: 2020-04-26

    inputs:
        list of 2d tensor (batch_size, dim_1)
        list of 2d tensor (batch_size, dim_1)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
    def __init__(self, num_input, scenes_hidden_units, sharing_hidden_units, task_hidden_units, num_experts,
                 is_random=False, task_apply_final_act=False, act_fn='relu', l2_reg=0.001, dropout_rate=0,
                 use_bn=False, expert_hidden_units=[16, 8],
                 bias_init=[],
                 is_bias_net=False, bias_hidden_units=[16, 8], seed=1024, name='BaggingMSLMMoEModel'):
        """
        Args:
            num_input: int
            scenes_hidden_units: list of list, unit of each hidden layer in each scene layers
            sharing_hidden_units: list of list, unit in each hidden layer
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            num_experts: int
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            seed: int, random value for initialization

        """
        super(BaggingMSLMMoEModel, self).__init__(name='BaggingMSLMMoEModel')
        self.num_scenes = len(scenes_hidden_units)
        self.num_experts = num_experts
        self.num_tasks = len(task_hidden_units)
        self.bias_init = bias_init
        self.is_bias_net = is_bias_net
        self.num_input = num_input
        self.is_random = is_random

        # if is_adaptive:
        #     assert (len(self.bias_init) == self.num_tasks), ("length of bias_init must equal to the number of tasks")
        #     self.gmmoe_layer = GeneralMMoELayer(num_experts=self.num_experts, num_tasks=self.num_tasks, bias_init=self.bias_init, l2_reg=l2_reg, seed=seed)
        # else:
        self.gmmoe_layer = GeneralMMoELayer(num_experts=self.num_experts, num_tasks=self.num_tasks, bias_init=self.bias_init, l2_reg=l2_reg, seed=seed, name="{}_mmoe_layer".format(name))

        self.cvr_sharing_layer = []
        # self.bias_sharing_layer = []
        for i in range(self.num_input):
            self.cvr_sharing_layer_i = DNNLayer(hidden_units=sharing_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                    dropout_rate=dropout_rate, use_bn=use_bn, seed=seed)
            self.cvr_sharing_layer.append(self.cvr_sharing_layer_i)

        if is_bias_net:
            self.bias_sharing_layer = DNNLayer(hidden_units=sharing_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                    dropout_rate=dropout_rate, use_bn=use_bn, seed=seed)
            self.expert_bias_layers = []
            for j in range(self.num_experts):
                self.expert_bias_layers.append(DNNLayer(hidden_units=bias_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=use_bn,
                                                    apply_final_act=True, seed=seed))

        self.scenes_layers = []
        self.expert_layers = []
        for j in range(self.num_experts):
            self.scenes_cvr_layers = []
            for i in range(self.num_scenes):
                self.scenes_cvr_layers.append(DNNLayer(hidden_units=scenes_hidden_units[i], activation=act_fn, l2_reg=l2_reg,
                                                dropout_rate=dropout_rate, use_bn=use_bn,
                                                apply_final_act=True, seed=seed))
            self.scenes_layers.append(self.scenes_cvr_layers)
            self.expert_layers.append(DNNLayer(hidden_units=expert_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                dropout_rate=dropout_rate, use_bn=use_bn,
                                                apply_final_act=True, seed=seed))

        self.task_layers = []
        for i, units in enumerate(task_hidden_units):
            self.task_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                      dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=task_apply_final_act, seed=seed))
        self.attnlayer = SelfAttentionLayer(dropout_rate)

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of 2d tensor (batch_size, dim_1)
            extra_input: list of 2d tensor (batch_size, dim_1)

        Returns:
            list of 2d tensor (batch_size, out_dim)

        """

        # sharing layer
        if self.is_bias_net:
            bias_input, scenes_feature = extra_input
            bias_expert_inputs = self.bias_sharing_layer(bias_input, training=training)
            tf.logging.info('BaggingMSLMMoEModel: bias_expert_inputs {}'.format(bias_expert_inputs))
        else:
            scenes_feature = extra_input

        expert_inputs_list = []
        cvr_expert_inputs_list = []
        # bias_expert_inputs_list = []
        for i in range(self.num_input):
            cvr_expert_inputs = self.cvr_sharing_layer[i](inputs[i], training=training)
            cvr_expert_inputs_list.append(cvr_expert_inputs)
            tf.logging.info('BaggingMSLMMoEModel: cvr_expert_inputs {}'.format(cvr_expert_inputs))
            tf.logging.info('BaggingMSLMMoEModel: is_bias_net {}'.format(self.is_bias_net))
            if self.is_bias_net:
                expert_inputs_i = tf.keras.layers.Concatenate(axis=-1)([cvr_expert_inputs, bias_expert_inputs])
            else:
                expert_inputs_i = cvr_expert_inputs
            expert_inputs_list.append(expert_inputs_i)
        expert_inputs = tf.keras.layers.Concatenate(axis=-1)(expert_inputs_list)
        tf.logging.info('BaggingMSLMMoEModel: cvr_expert_inputs_list {}'.format(cvr_expert_inputs_list))
        # tf.logging.info('BaggingMSLMMoEModel: bias_expert_inputs_list {}'.format(bias_expert_inputs_list))
        tf.logging.info('BaggingMSLMMoEModel: expert_inputs {}'.format(expert_inputs))

        # bagging
        sampled_expert_input_list = []
        for i in range(self.num_experts):
            if self.is_random:
                sample = random.sample(cvr_expert_inputs_list[1:], self.num_scenes-1)
                tf.logging.info('MMOEEstimator: sample {}'.format(sample))
                sample = [cvr_expert_inputs_list[0]]+sample
            else:
                shuffle(cvr_expert_inputs_list)
                sample = cvr_expert_inputs_list[:self.num_scenes]
            sampled_expert_input_list.append(sample)

        # expert layer
        expert_outputs_list = []
        for j in range(self.num_experts):
            # each expert contains several scenes layer
            scenes_outputs_list = []
            for i in range(self.num_scenes):
                scenes_outputs_i = self.scenes_layers[j][i](sampled_expert_input_list[j][i], training=training)
                scenes_outputs_i = tf.keras.layers.Lambda(lambda x: tf.expand_dims(x, axis=-1))(scenes_outputs_i)
                tf.logging.info('BaggingMSLMMoEModel: {}th expert, {}th scene, scenes_outputs_i {}'.format(j, i, scenes_outputs_i))
                scenes_outputs_list.append(scenes_outputs_i)
                tf.logging.info('BaggingMSLMMoEModel: {}th expert, {}th scene, scenes_outputs_list {}'.format(j, i, scenes_outputs_list))
            key = tf.transpose(tf.stack(scenes_outputs_list), (1,0,3,2))
            #shape: (-1, seq_len, self.heads, self.d_k)
            tf.logging.info('BaggingMSLMMoEModel: key {} '.format(key))
            value = key
            tf.logging.info('BaggingMSLMMoEModel: value {} '.format(value))
            tf.logging.info('BaggingMSLMMoEModel: {}th expert, scenes_feature {} '.format(j, scenes_feature[j]))
            expand_scenes_feature = tf.keras.layers.Lambda(lambda x: tf.expand_dims(tf.expand_dims(x, axis=1), axis=1))(scenes_feature[j])
            tf.logging.info('BaggingMSLMMoEModel: query {} '.format(expand_scenes_feature))
            #shape: (-1, 1, 1, self.d_k)
            query = tf.tile(expand_scenes_feature, [1, self.num_scenes, 1, 1])
            tf.logging.info('BaggingMSLMMoEModel: query {} '.format(query))
            # apply scaled self dot attention
            expert_input_i = self.attnlayer([query, key, value], training=training)
            expert_input_i = tf.reduce_mean(expert_input_i, axis=1)
            if self.is_bias_net:
                expert_bias_outputs_i = self.expert_bias_layers[j](bias_expert_inputs, training=training)
                expert_input_i = tf.keras.layers.Concatenate(axis=-1)([expert_input_i, expert_bias_outputs_i])
            expert_output_i = self.expert_layers[j](expert_input_i, training=training)
            expert_output_i = tf.keras.layers.Lambda(lambda x: tf.expand_dims(x, axis=-1))(expert_output_i)
            expert_outputs_list.append(expert_output_i)
            tf.logging.info('BaggingMSLMMoEModel: {}th exprt, expert_outputs_list {} '.format(j, expert_outputs_list))

        expert_outputs = tf.keras.layers.Concatenate(axis=-1)(expert_outputs_list)
        tf.logging.info('BaggingMSLMMoEModel: expert_outputs {}'.format(expert_outputs))

        task_inputs = self.gmmoe_layer([expert_inputs, expert_outputs])

        task_outputs = []
        for i in range(self.num_tasks):
            task_outputs.append(self.task_layers[i](task_inputs[i], training=training))
            tf.logging.info('BaggingMSLMMoEModel: {}th task, task_output {}'.format(i, task_outputs[-1]))

        return task_outputs
