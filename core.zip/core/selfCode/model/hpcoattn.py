# coding: utf-8
# @Author: anbo
# @Date: 2020-09-22
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.multimodality import ParallelCoAttentionLayer


class HierarchyParallelCoAttnModel(tf.keras.Model):
    """
    Model: Hierarchy Parallel Co-attention model for vqa

    Paper: Hierarchical Question-Image Co-Attention for Visual Question Answering

    Link: https://papers.nips.cc/paper/6202-hierarchical-question-image-co-attention-for-visual-question-answering.pdf

    Author: Jiasen Lu, Jianwei Yang, Dhruv Batra, Devi Parikh

    Developer: anbo

    Date: 2020-09-22

    inputs: list of 3d tensors

    returns:
            2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, l2_reg=0, seed=1024, 
                 projection_hidden_units=[4,1], apply_final_act=False, use_bn=False, act_fn='relu', dropout_rate=0,
                 name='HierarchyParallelCoAttnModel'):
        """
        Args:
            hidden_units: int
            l2_reg: float, regularization value
            seed: int, random value for initialization
            text_attention: bool
        """
        super(HierarchyParallelCoAttnModel, self).__init__(name='HierarchyParallelCoAttnModel')
        self.pcoattn_layer = ParallelCoAttentionLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, name="{}_hpcoattn_layer".format(name))

        self.final_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_projection_layer".format(name))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: list of 3d tensors

        Returns:
            2d tensor (batch_size, out_dim)

        """
        dan_output = self.pcoattn_layer(inputs, training=training)

        output = self.final_layer(dan_output, training=training)
        tf.logging.info('HierarchyParallelCoAttnModel: output {}'.format(output))
        return output

