# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer

class DLCMModel(tf.keras.Model):
    """
    Model: DLCM Model

    Paper: Learning a Deep Listwise Context Model for Ranking Refinement

    Link: https://arxiv.org/abs/1804.05936

    Author: Qingyao Ai, Keping Bi, Jiafeng Guo, W. Bruce Croft

    Developer: anbo

    Date: 2020-06-15

    note: it is recommended to reverse the order of item context and label list

    inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)

    returns:
            2d tensor (batch_size, seq_len)

    """
    def __init__(self, rnn_unit, intermediate_unit, input_length=6, hidden_units=[16],
                rnn_act_fn='tanh', act_fn='relu', l2_reg=0.001, dropout_rate=0,
                 apply_final_act=True, use_bn=False, seed=1024, shared_pv=False, name='DLCMModel'):
        """
        Args:
            hidden_units: int, the last dim of the inputs
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
        """
        super(DLCMModel, self).__init__(name='DLCMModel')
        self.hidden_units = hidden_units
        self.shared_pv = shared_pv

        self.rnn_layer = tf.keras.layers.GRU(units=rnn_unit, activation=rnn_act_fn, return_sequences=True, return_state=True, name="{}_gru_layer".format(name))

        if self.shared_pv:
            self.dnn_layer = tf.keras.layers.TimeDistributed(
                tf.keras.layers.Dense(hidden_units[-1], activation='elu', use_bias=True))
        else:
            self.dnn_layer_list = []
            for i in range(input_length):
                self.dnn_layer_list.append(DNNLayer(hidden_units=hidden_units, activation='relu', l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=False, apply_final_act=True,
                                                    seed=1024, name="{}_dnn_layer_{}".format(name, i)))

        self.weight_w = tf.get_variable(name='weight_w', shape=[rnn_unit, intermediate_unit, rnn_unit], dtype=tf.float32, initializer=tf.initializers.he_normal(seed=seed))
        self.bias = tf.get_variable(name='bias', shape=[intermediate_unit, rnn_unit], dtype=tf.float32, initializer=tf.initializers.he_normal(seed=seed))
        self.weight_v = tf.get_variable(name='weight_v', shape=[intermediate_unit, ], dtype=tf.float32, initializer=tf.initializers.he_normal(seed=seed))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)
        Returns:
            2d tensor (batch_size, seq_len)

        """
        seq_len = inputs.get_shape()[1].value
        context_input = inputs
        if extra_input is not None:
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(extra_input)
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.tile(x, [1, seq_len, 1]))(extra_input_3d)
            tf.logging.info('DLCMModel: extra_input_3d {}'.format(extra_input_3d))
            context_input = tf.keras.layers.Concatenate(axis=-1)([inputs, extra_input_3d])

        tf.logging.info('DLCMModel: context_input {}'.format(context_input))

        if self.shared_pv:
            context_seq_input = self.dnn_layer(context_input)
            tf.logging.info('DLCMModel: shared pv context_seq_input {}'.format(context_seq_input))
        else:
            context_seq_input_list = []
            for i in range(seq_len):
                user_item_input_i = self.dnn_layer_list[i](context_input[:, i, :])
                user_item_input_i = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(
                    user_item_input_i)
                context_seq_input_list.append(user_item_input_i)
            context_seq_input = tf.keras.layers.Concatenate(axis=1)(context_seq_input_list) if len(
                context_seq_input_list) > 1 else context_seq_input_list[0]
            tf.logging.info('DLCMModel: separate pv context_seq_input {}'.format(context_seq_input))

        rnn_hidden_output, rnn_last_state = self.rnn_layer(context_seq_input)
        # rnn_hidden_output: (batch, len, dim)
        # rnn_last_state: (batch, dim)
        tf.logging.info('DLCMModel: rnn_hidden_output {}, rnn_last_state {}'.format(rnn_hidden_output, rnn_last_state))

        attention_weight = tf.add(tf.tensordot(rnn_last_state, self.weight_w, axes=[-1, 0]), self.bias)
        # attention_weight: (batch, k, dim)
        tf.logging.info('DLCMModel: attention_weight {}'.format(attention_weight))

        attention_weight = tf.nn.tanh(attention_weight)
        attention_score = tf.matmul(rnn_hidden_output, attention_weight, transpose_b=True)
        # attention_score: (batch, len, k)
        tf.logging.info('DLCMModel: attention_score {}'.format(attention_score))

        score = tf.tensordot(attention_score, self.weight_v, axes=[-1, 0])
        # score: (batch, len)
        tf.logging.info('DLCMModel: score: {}'.format(score))
        return score
