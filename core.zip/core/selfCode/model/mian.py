# coding: utf-8
# @Author: anbo
# @Date: 2021-11-11
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import TransformerEncoder
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer, WeightedAttentionLayer


class MIANModel(tf.keras.Model):
  """
    Model: MIAN Model

    Paper: Multi-Interactive Attention Network for Fine-grained Feature Learning in CTR Prediction

    Link: https://dl.acm.org/doi/10.1145/3437963.3441761

    Author: Kai Zhang, Hao Qian, Qing Cui, Qi Liu, Longfei Li, Jun Zhou, Jianhui Ma, Enhong Chen

    Developer: anbo

    Date: 2021-11-11

    Note: to keep it simple, please set the same embedding unit for user, item, context and sequence behavior inputs

    inputs: list of tensors: [user_input, seq_input, item_input, context_input]
          user_input: (batch, user_fields * emb_dim)
          seq_input: (batch, seq_len, emb_dim)
          item_input: (batch, item_fields * emb_dim)
          context_input: (batch, context_fields * emb_dim)

    output: (batch, hidden_units)

    """
  def __init__(self,
               user_fields=8,
               item_fields=8,
               context_fields=8,
               hidden_units=16,
               heads=4,
               intermediate_size=64,
               n_transform_layers=1,
               act_fn='relu',
               dropout_rate=0,
               l2_reg=0.001,
               return_all_layers=False,
               projection_hidden_units=[4, 1],
               apply_final_act=False,
               use_bn=False,
               seed=1024,
               min_timescale=1.0,
               max_timescale=1.0e4,
               pos_type='learnable',
               mha_type='origin',
               name='MIANModel'):
    """
    Args:
        n_transform_layers: int, num of transformer encoder layers
        hidden_units: int, the last dim of the inputs
        heads: int, num of self-attention modules, must be dividable by hidden_units
        intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
        act_fn: string, activation function
        dropout_rate: float, dropout rate
        l2_reg: float, regularization value
        return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
        projection_hidden_units: list, units for the projection layer
        apply_final_act: whether to apply act in final layer
        use_bn: boolean, if True use BatchNormalization, otherwise not
        seed: int, random value

    """
    super(MIANModel, self).__init__(name='MIANModel')
    self.hidden_units = hidden_units
    assert (hidden_units %
            heads == 0), ('hidden_units must be dividable by heads')
    self.pos_type = pos_type
    self.user_fields = user_fields
    self.item_fields = item_fields
    self.context_fields = context_fields

    if self.pos_type != 'no_pos':
      self.position_layer = PositionalEncodingLayer(
          min_timescale=min_timescale,
          max_timescale=max_timescale,
          pos_type=self.pos_type,
          name="{}_pos_enco_layer".format(name))

    self.bert_layer = TransformerEncoder(
        n_layers=n_transform_layers,
        hidden_units=hidden_units,
        heads=heads,
        intermediate_size=intermediate_size,
        act_fn=act_fn,
        dropout_rate=dropout_rate,
        l2_reg=l2_reg,
        return_all_layers=return_all_layers,
        mha_type=mha_type,
        name="{}_transformer_layer".format(name))

    self.ibim_layer = WeightedAttentionLayer(l2_reg=l2_reg,
                                             seed=seed,
                                             name="{}_ibim_layer".format(name))
    self.iuim_layer = WeightedAttentionLayer(l2_reg=l2_reg,
                                             seed=seed,
                                             name="{}_iuim_layer".format(name))
    self.icim_layer = WeightedAttentionLayer(l2_reg=l2_reg,
                                             seed=seed,
                                             name="{}_icim_layer".format(name))
    self.gim_layer = WeightedAttentionLayer(l2_reg=l2_reg,
                                            seed=seed,
                                            name="{}_gim_layer".format(name))

    self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units,
                              activation=act_fn,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              apply_final_act=apply_final_act,
                              seed=seed,
                              name="{}_dnn_layer".format(name))

  def reshape_to_3d_func(self, inputs, fields):
    """
    Args:
      inputs: 2d tensor, (batch, fields * dim)
      fields: int,
      dim: int, embedding unit

    output: 3d tensor, (batch, fields, dim)
    """
    if inputs is None:
      return inputs
    dims = tf.keras.backend.int_shape(inputs)[-1]
    emb_dim = dims // fields
    input_3d = tf.reshape(inputs, shape=(-1, fields, emb_dim))
    tf.logging.info('MIAN: reshaped 3d tensor input_3d {}'.format(input_3d))
    return input_3d

  def call(self, inputs, extra_input=None, training=None, lego='preln'):
    """
      Args:
          inputs: list of tensors: [user_input, seq_input, item_input, context_input]
          user_input: (batch, user_fields * emb_dim)
          seq_input: (batch, seq_len, emb_dim)
          item_input: (batch, item_fields * emb_dim)
          context_input: (batch, context_fields * emb_dim)

      Returns:
          2d tensor (batch_size, out_dim)

    """
    user_input, seq_input, item_input = inputs[:3]
    context_input = inputs[-1] if len(inputs) == 4 else None

    # reshape 2d tensors to 3d tensors
    user_input_3d = self.reshape_to_3d_func(user_input, self.user_fields)
    item_input_3d = self.reshape_to_3d_func(item_input, self.item_fields)
    context_input_3d = self.reshape_to_3d_func(context_input,
                                               self.context_fields)
    item_input_expand = tf.expand_dims(item_input, axis=1)

    # add position encoding to sequence behavior
    input_dim = tf.keras.backend.int_shape(seq_input)[-1]
    seq_len = tf.keras.backend.int_shape(seq_input)[1]
    if self.pos_type != 'no_pos':
      seq_input = tf.keras.layers.Lambda(lambda x: tf.multiply(
          x, tf.sqrt(tf.cast(input_dim, tf.float32))))(seq_input)
      seq_input = self.position_layer(seq_input)

    # IBIM module
    seq_output = self.bert_layer(seq_input, training=training, lego=lego)
    item_input_seq_tile = tf.tile(item_input_expand, [1, seq_len, 1])
    ibim_input = tf.keras.layers.Concatenate(axis=-1)(
        [seq_output, item_input_seq_tile])
    tf.logging.info('MIANModel: ibim_input {}'.format(ibim_input))
    ibim_output = self.ibim_layer(ibim_input)
    tf.logging.info('MIANModel: ibim_output {}'.format(ibim_output))

    # IUIM module
    item_input_user_tile = tf.tile(item_input_expand, [1, self.user_fields, 1])
    iuim_input = tf.keras.layers.Concatenate(axis=-1)(
        [user_input_3d, item_input_user_tile])
    tf.logging.info('MIANModel: iuim_input {}'.format(iuim_input))
    iuim_output = self.iuim_layer(iuim_input)
    tf.logging.info('MIANModel: iuim_output {}'.format(iuim_output))

    # ICIM module
    item_input_context_tile = tf.tile(item_input_expand,
                                      [1, self.context_fields, 1])
    icim_input = tf.keras.layers.Concatenate(axis=-1)([
        context_input_3d, item_input_context_tile
    ]) if context_input_3d is not None else item_input_context_tile
    tf.logging.info('MIANModel: icim_input {}'.format(icim_input))
    icim_output = self.icim_layer(icim_input)
    tf.logging.info('MIANModel: icim_output {}'.format(icim_output))

    # GIM module
    if context_input is not None:
      gim_input = tf.keras.layers.Concatenate(axis=-1)([
          user_input, item_input, context_input, ibim_output, iuim_output,
          icim_output
      ])
    else:
      gim_input = tf.keras.layers.Concatenate(axis=-1)(
          [user_input, item_input, ibim_output, iuim_output, icim_output])
    total_fields = tf.keras.backend.int_shape(gim_input)[1] // input_dim
    gim_input = tf.reshape(gim_input, shape=(-1, total_fields, input_dim))
    tf.logging.info('MIANModel: gim_input {}'.format(gim_input))
    gim_output = self.gim_layer(gim_input)
    tf.logging.info('MIANModel: gim_output {}'.format(gim_output))

    if extra_input is not None:
      if tf.keras.backend.ndim(bert_output) > 2:
        bert_output = tf.keras.layers.Flatten()(gim_output)
      combined_input = tf.keras.layers.Concatenate(axis=-1)(
          [gim_output, extra_input])
      tf.logging.info('MIANModel: combined_input {}'.format(combined_input))
    else:
      combined_input = gim_output

    output = self.dnn_layer(combined_input, training=training)
    tf.logging.info('MIANModel: output {}'.format(output))
    return output
