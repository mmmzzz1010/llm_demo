# coding: utf-8
# @Author: anbo
# @Date: 2021-04-21
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer

class HGNModel(tf.keras.Model):
    """
    Model: HGN model

    Paper: Hierarchical Gating Networks for Sequential Recommendation

    Link: dl.acm.org/doi/10.1145/3292500.3330984

    Author: Chen Ma, Peng Kang, Xue Liu

    Developer: anbo

    Date: 2021-04-21

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, user_hidden_units=[64, 16], project_user_tag=True, item_hidden_units=[64, 16], project_item_tag=True,
                 hidden_units=[16], input_length=6,
                 act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False, seed=1024,name='HGNModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(HGNModel, self).__init__(name='HGNModel')
        self.hidden_size = hidden_units[-1]
        self.project_user_tag = project_user_tag
        self.project_item_tag = project_item_tag

        if self.project_user_tag:
            self.user_projection_layer = DNNLayer(hidden_units=user_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False,
                                                  seed=seed, name="{}_user_projection_layer".format(name))
        if self.project_item_tag:
            self.item_projection_layer = DNNLayer(hidden_units=item_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                              dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False,
                                              seed=seed, name="{}_item_projection_layer".format(name))

        self.feature_gating_item_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False, seed=seed, name="{}_feature_gating_item_layer".format(name))

        self.feature_gating_user_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False,
                                                  seed=seed, name="{}_feature_gating_item_layer".format(name))

        self.instance_gating_item_weight = tf.get_variable(name='instance_gating_item_weight', shape=[self.hidden_size, 1],
                                        dtype=tf.float32, initializer=tf.initializers.he_normal(seed=seed))
        self.instance_gating_user_weight = tf.get_variable(name='instance_gating_user_weight', shape=[self.hidden_size, input_length], dtype=tf.float32,
                                    initializer=tf.initializers.he_normal(seed=seed))

        self.candidate_item_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False,
                                                  seed=seed, name="{}_candidate_item_layer".format(name))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: tuple of tensors, (user_input, hist_seq_input, candidate_item_input)
            user_input: 2d tensor (batch_size, dim1)
            hist_seq_input: 3d tensor (batch, input_length, dim)
            candidate_item_input: 2d tensor, (batch, dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        user_input, hist_seq_input, candidate_item_input = inputs

        if self.project_user_tag:
            user_input = self.user_projection_layer(user_input, training=training)
        tf.logging.info('HGNModel: user_input {}'.format(user_input))

        if self.project_item_tag:
            candidate_item_input = self.item_projection_layer(candidate_item_input, training=training)
        tf.logging.info('HGNModel: candidate_item_input {}'.format(candidate_item_input))

        # feature gating
        hist_seq_feature_gating_score = self.feature_gating_item_layer(hist_seq_input, training=training) + tf.expand_dims(self.feature_gating_user_layer(user_input,training=training), axis=1)
        # hist_seq_feature_gating_score: (batch, L, d)
        hist_seq_feature_gating_output = hist_seq_input * tf.nn.sigmoid(hist_seq_feature_gating_score)
        tf.logging.info('HGNModel: hist_seq_feature_gating_output {}'.format(hist_seq_feature_gating_output))

        # instance gating
        instance_gating_item_score = tf.tensordot(hist_seq_feature_gating_output, self.instance_gating_item_weight, axes=[-1, 0])
        instance_gating_user_score = tf.tensordot(user_input, self.instance_gating_user_weight, axes=[-1, 0])
        instance_gating_score = tf.nn.sigmoid(instance_gating_item_score + tf.expand_dims(instance_gating_user_score, axis=-1))
        # instance_gating_score： (batch, L, 1)
        instance_gating_output = hist_seq_feature_gating_output * instance_gating_score
        tf.logging.info('HGNModel: instance_gating_output {}'.format(instance_gating_output))
        hist_seq_instance_gating_output = tf.reduce_sum(instance_gating_output, axis=1) / tf.reduce_sum(instance_gating_score, axis=1)
        tf.logging.info('HGNModel: hist_seq_instance_gating_output {}'.format(hist_seq_instance_gating_output))

        candidate_item_output = self.candidate_item_layer(candidate_item_input, training=training)
        tf.logging.info('HGNModel: candidate_item_output {}'.format(candidate_item_output))

        # prediction layer
        long_term_output = tf.keras.backend.batch_dot(user_input, candidate_item_output, axes=[-1, -1])
        tf.logging.info('HGNModel: long_term_output {}'.format(long_term_output))

        short_term_output = tf.keras.backend.batch_dot(hist_seq_instance_gating_output, candidate_item_output, axes=[-1, -1])
        tf.logging.info('HGNModel: short_term_output {}'.format(short_term_output))

        hist_seq_inter_output = tf.reduce_sum(tf.matmul(hist_seq_input, tf.expand_dims(candidate_item_output, axis=-1)), axis=1)
        #hist_seq_inter_output = tf.squeeze(hist_seq_inter_output, axis=-1)
        tf.logging.info('HGNModel: hist_seq_inter_output {}'.format(hist_seq_inter_output))

        output = long_term_output + short_term_output + hist_seq_inter_output
        tf.logging.info('HGNModel: output {}'.format(output))
        return output

