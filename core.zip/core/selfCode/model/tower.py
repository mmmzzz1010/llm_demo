# coding: utf-8
# @Author: anbo
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer


class TowerModel(tf.keras.Model):
    """
    Model: Tower Model

    Developer: anbo

    Date: 2020-03-19

    inputs: list of 2d tensor [input_a, input_b]
             input_a: (batch_size, dim_1)
             input_b: (batch_size, dim_2)

    outputs: 2d tensor (batch_size, 1)

    """
    def __init__(self, user_hidden_units, item_hidden_units, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False, seed=1024, name='TowerModel'):
        """
        Args:
            user_hidden_units: list, unit in user tower hidden layer
            item_hidden_units: list, unit in item tower hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(TowerModel, self).__init__(name='TowerModel')
        assert (user_hidden_units is not None and len(user_hidden_units) >= 1), ('Must specify user_hidden_units with at least one unit')
        assert (item_hidden_units is not None and len(item_hidden_units) >= 1), ('Must specify item_hidden_units with at least one unit')
        assert (user_hidden_units[-1] == item_hidden_units[-1]), ('the last unit of user_hidden_units must equal to that of item_hidden_units')

        user_last_dim = user_hidden_units.pop()
        item_last_dim = item_hidden_units.pop()
        self.user_last_layer = tf.keras.layers.Dense(user_last_dim, activation=None, kernel_initializer=tf.keras.initializers.he_normal(seed=seed), name='{}_user_last_dense_layer'.format(name))
        self.item_last_layer = tf.keras.layers.Dense(item_last_dim, activation=None, kernel_initializer=tf.keras.initializers.he_normal(seed=seed), name='{}_item_last_dense_layer'.format(name))

        self.user_hidden_units = user_hidden_units
        self.item_hidden_units = item_hidden_units
        self.user_tower = DNNLayer(hidden_units=self.user_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, name='{}_user_tower_layer'.format(name)) if len(self.user_hidden_units) > 0 else None
        self.item_tower = DNNLayer(hidden_units=self.item_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, name='{}_item_tower_layer'.format(name)) if len(self.item_hidden_units) > 0 else None

    def call(self, inputs, training=None):
        """
        Args:
            inputs: list of 2d tensor [input_a, input_b]
             input_a: (batch_size, dim_1)
             input_b: (batch_size, dim_2)

        Returns:
            2d tensor (batch_size, 1)

        """
        user_inputs, item_inputs = inputs

        user_hidden = self.user_tower(user_inputs, training=training) if self.user_tower is not None else user_inputs
        tf.logging.info('TowerModel: user_hidden {}'.format(user_hidden))
        item_hidden = self.item_tower(item_inputs, training=training) if self.item_tower is not None else item_inputs
        tf.logging.info('TowerModel: item_hidden {}'.format(item_hidden))

        user_output = self.user_last_layer(user_hidden)
        tf.logging.info('TowerModel: user_output {}'.format(user_output))
        item_output = self.item_last_layer(item_hidden)
        tf.logging.info('TowerModel: item_output {}'.format(item_output))

        logit = tf.reduce_sum(user_output * item_output, axis=-1)
        logit = tf.reshape(logit, shape=[-1, 1])
        tf.logging.info('TowerModel: logit {}'.format(logit))

        return logit

