# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import CrossStitchLayer


class CrossStitchModel(tf.keras.Model):
  """
    Model: Cross Stitch Model

    Paper: Cross-stitch Networks for Multi-task Learning

    Link: https://arxiv.org/pdf/1604.03539

    Author: Ishan Misra, Abhinav Shrivastava, Abhinav Gupta, Martial Hebert

    Developer: anbo

    Date: 2020-03-23

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
  def __init__(self,
               sharing_hidden_units,
               task_hidden_units,
               task_apply_final_act=False,
               act_fn='relu',
               dropout_rate=0,
               use_bn=False,
               l2_reg=0.001,
               seed=1024,
               name='CrossStitchModel'):
    """
        Args:
            sharing_hidden_units: list, unit in each hidden layer
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            cross_stitch_layers_list: list of int, maximum should be <= min(layers of task_hidden_units)
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            seed: int, random value for initialization

        """
    super(CrossStitchModel, self).__init__(name='CrossStitchModel')
    self.sharing_layer = DNNLayer(hidden_units=sharing_hidden_units,
                                  activation=act_fn,
                                  l2_reg=l2_reg,
                                  dropout_rate=dropout_rate,
                                  use_bn=use_bn,
                                  seed=seed,
                                  name="{}_sharing_dnn_layer".format(name))

    self.n_tasks = len(task_hidden_units)
    self.task_layers = []
    self.n_cross_stitch_layers = min(
        [len(units) for units in task_hidden_units])

    self.cross_stitch_layers = []
    for i in range(self.n_cross_stitch_layers):
      self.cross_stitch_layers.append(
          CrossStitchLayer(name="{}_cross_stitch_layer".format(name)))

    tf.logging.info('CrossStitchModel: {} tasks, len(task_layers) {}'.format(
        self.n_tasks, len(self.task_layers)))
    for i, units in enumerate(task_hidden_units):
      self.task_layers.append([])
      for j, unit in enumerate(units):
        if j == len(units) - 1:
          act_fn = None
        self.task_layers[i].append(
            tf.keras.layers.Dense(
                unit,
                activation=act_fn,
                use_bias=True,
                kernel_initializer=tf.keras.initializers.he_normal(seed=seed),
                kernel_regularizer=tf.keras.regularizers.l2(l2_reg),
                name="{}_task_{}_{}_dense_layer".format(name, i, unit)))

  def call(self, inputs, training=None):
    """
    Args:
        inputs: 2d tensor (batch_size, dim_1), deep features

    Returns:
        list of 2d tensor (batch_size, out_dim)

    """
    sharing_output = self.sharing_layer(inputs, training=training)
    tf.logging.info(
        'CrossStitchModel: sharing_output {}'.format(sharing_output))

    task_outputs = [sharing_output] * self.n_tasks
    for i in range(self.n_cross_stitch_layers):
      for j in range(self.n_tasks):
        task_outputs[j] = self.task_layers[j][i](task_outputs[j])
        tf.logging.info(
            'CrossStitchModel: {}th cross stitch layer, {}th layer, {}'.format(
                i, j, task_outputs[j]))
      task_outputs = self.cross_stitch_layers[i](task_outputs)
    return task_outputs
