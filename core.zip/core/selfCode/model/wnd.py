# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer

class WndModel(tf.keras.Model):
    """
    Model: Wnd Model

    Paper: Wide & Deep Learning for Recommender Systems

    Link: https://arxiv.org/abs/1606.07792

    Author: Heng-Tze Cheng, Levent Koc, Jeremiah Harmsen, etc.

    Developer: anbo

    Date: 2019-12-09

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 seed=1024, apply_final_act=True, name='WndModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(WndModel, self).__init__(name='WndModel')
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, apply_final_act=apply_final_act, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features
            extra_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        dnn_output = self.dnn_layer(inputs, training=training)

        if extra_input is None:
            combined_output = dnn_output
        else:
            combined_output = tf.keras.layers.Concatenate()([dnn_output, extra_input])
        tf.logging.info('WndModel: combined_output {}'.format(combined_output))
        return combined_output

