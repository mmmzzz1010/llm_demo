# coding: utf-8
# @Author: anbo
# @Date: 2021-01-07
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer, GeneralMMoELayer, GeneralMultiHeadAttnLayer, PeachLayer


class HGMEModel(tf.keras.Model):
    """
    Model: Hierarchical Gated Multi-Expert Model

    Paper:

    Link:

    Author:

    Developer: anbo

    Date: 2021-01-07

    note: it is recommended to reverse the order of item context and label list

    """
    def __init__(self, hidden_units=16, heads=4, num_tasks=2, l2_reg=0.001, dropout_rate=0, seed=1024, list_tag=False,
                 mha_type='vanilla', dim_e=None, synthesizer_type='dense', inf=1e9, window=1, pos_type='learnable',
                 min_timescale=1.0, max_timescale=100, projection_hidden_units=[1], act_fn='relu', name='HGMEModel'):
        """
        Args:
            hidden_units: int, the last dim of the inputs
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
        """
        super(HGMEModel, self).__init__(name='HGMEModel')
        self.hidden_units = hidden_units
        self.num_tasks = num_tasks
        self.num_experts = heads
        self.pos_type = pos_type

        # item context and user input interaction layer
        self.pi_layer = PeachLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, name="{}_pi_layer".format(name))

        # postion layer
        from alps_biz.core.layer import PositionalEncodingLayer, LayerNorm
        if self.pos_type != 'no_pos':
            self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale, pos_type=pos_type, name="{}_pos_enco_layer".format(name))

        # item context sequence extraction layer
        self.icel_layer = GeneralMultiHeadAttnLayer(hidden_units=hidden_units, heads=heads, l2_reg=l2_reg, dropout_rate=dropout_rate, seed=seed, list_tag=list_tag,
                                            mha_type=mha_type, dim_e=dim_e, synthesizer_type=synthesizer_type, inf=inf, window=window, concat_heads=False, name="{}_icel_layer".format(name))

        # mtl layer
        self.mmoe_layer = GeneralMMoELayer(num_experts=self.num_experts, num_tasks=self.num_tasks, bias_init=[], l2_reg=l2_reg, seed=seed, name="{}_multi_experts_layer".format(name))

        # linear projection layer
        self.linear_layers = []
        for i in range(self.num_tasks):
            #self.linear_layers.append(tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(projection_hidden_units, activation=None, use_bias=True, name="{}_task_projection {}th_layer".format(name, i))))
            self.linear_layers.append(tf.keras.layers.TimeDistributed(DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                         dropout_rate=dropout_rate, use_bn=False, apply_final_act=False, seed=seed,
                                         name="{}_task_projection {}th_layer".format(name, i))))

    def call(self, inputs, extra_input=None, mask=None, training=None):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)
        Returns:
            2d tensor (batch_size, seq_len)

        """
        context_input = inputs

        if extra_input is not None:
            #extra_input = self.ln(extra_input)
            context_input = self.pi_layer([context_input, extra_input])

        tf.logging.info('HGMEModel: context_input {}'.format(context_input))

        if self.pos_type != 'no_pos':
            seq_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(self.hidden_units, tf.float32))))(context_input)
            seq_input = self.position_layer(seq_input)
        else:
            seq_input = context_input

        expert_output = self.icel_layer(seq_input, mask=mask)
        tf.logging.info('HGMEModel: expert_output {}'.format(expert_output))

        mtl_output = self.mmoe_layer([seq_input, expert_output])
        tf.logging.info('HGMEModel: mtl_output {}'.format(mtl_output))

        output = []
        for i in range(self.num_tasks):
            output_i = self.linear_layers[i](mtl_output[i])
            output.append(tf.keras.layers.Flatten()(output_i))

        tf.logging.info('HGMEModel: output {}'.format(output))

        return output