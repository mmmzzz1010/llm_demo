# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.sequence import TransformerEncoder
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer

class PRMModel(tf.keras.Model):
    """
    Model: PRM Model

    Paper: Personalized Re-ranking for Recommendation

    Link: https://arxiv.org/abs/1904.06813

    Author: Changhua Pei, Yi Zhang, Yongfeng Zhang, Fei Sun, Xiao Lin, Hanxiao Sun, Jian Wu, Peng Jiang, Wenwu Ou

    Developer: anbo

    Date: 2020-06-15

    inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)

    returns:
            2d tensor (batch_size, seq_len)

    """
    def __init__(self, hidden_units, heads, intermediate_size, input_length=6, n_transform_layers=1, act_fn='relu',
                 dropout_rate=0, l2_reg=0.001, return_all_layers=False, projection_hidden_units=[16],
                 apply_final_act=True, use_bn=False, seed=1024, min_timescale=1.0, max_timescale=1.0e4, pos_type='fixed', shared_pv=False, name='PRMModel'):
        """
        Args:
            n_transform_layers: int, num of transformer encoder layers
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(PRMModel, self).__init__(name='PRMModel')
        self.hidden_size = hidden_units[-1] if isinstance(hidden_units, list) else hidden_units
        self.shared_pv = shared_pv

        self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale, pos_type = pos_type, name="{}_pos_enco_layer".format(name))

        self.bert_layer = TransformerEncoder(n_layers=n_transform_layers, hidden_units=self.hidden_size, heads=heads,
                                           intermediate_size=intermediate_size, act_fn=act_fn, dropout_rate=dropout_rate,
                                           l2_reg=l2_reg, return_all_layers=return_all_layers, name="{}_transformer_layer".format(name))

        if self.shared_pv:
            self.dnn_layer = tf.keras.layers.TimeDistributed(
                tf.keras.layers.Dense(hidden_units[-1], activation='elu', use_bias=True))
        else:
            self.dnn_layer_list = []
            for i in range(input_length):
                self.dnn_layer_list.append(DNNLayer(hidden_units=hidden_units, activation='relu', l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=False, apply_final_act=True,
                                                    seed=1024, name="{}_dnn_layer_{}".format(name, i)))

        self.linear_layer = tf.keras.layers.Dense(1, activation=None, use_bias=True)

    def call(self, inputs, extra_input=None, mask=None, training=None, lego='standard'):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)
            extra_input: (batch, dim)

        Returns:
            2d tensor (batch_size, seq_len)

        """
        seq_len = inputs.get_shape()[1].value
        context_input = inputs
        if extra_input is not None:
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(extra_input)
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.tile(x, [1, seq_len, 1]))(extra_input_3d)
            tf.logging.info('PRMModel: extra_input_3d {}'.format(extra_input_3d))
            context_input = tf.keras.layers.Concatenate(axis=-1)([inputs, extra_input_3d])

        tf.logging.info('PRMModel: context_input {}'.format(context_input))

        if self.shared_pv:
            context_seq_input = self.dnn_layer(context_input)
            tf.logging.info('PRMModel: shared pv context_seq_input {}'.format(context_seq_input))
        else:
            context_seq_input_list = []
            for i in range(seq_len):
                user_item_input_i = self.dnn_layer_list[i](context_input[:, i, :])
                user_item_input_i = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(
                    user_item_input_i)
                context_seq_input_list.append(user_item_input_i)
            context_seq_input = tf.keras.layers.Concatenate(axis=1)(context_seq_input_list) if len(
                context_seq_input_list) > 1 else context_seq_input_list[0]
            tf.logging.info('PRMModel: separate pv context_seq_input {}'.format(context_seq_input))

        seq_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(self.hidden_size, tf.float32))))(context_seq_input)
        seq_input = self.position_layer(seq_input)
        tf.logging.info('PRMModel: seq_input {}'.format(seq_input))

        bert_output = self.bert_layer(seq_input, mask=mask, training=training, lego=lego)
        tf.logging.info('PRMModel: bert_output {}'.format(bert_output))

        output = self.linear_layer(bert_output)
        output = tf.keras.layers.Flatten()(output)

        return output
