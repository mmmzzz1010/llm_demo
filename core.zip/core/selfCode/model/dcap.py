# coding: utf-8
# @Author: anbo
# @Date: 2021-11-19
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.search import DCAPLayer


class DCAPModel(tf.keras.Model):
  """
    Model: Deep Cross Attentional Product Network

    Paper: DCAP: Deep Cross Attentional Product Network for User Response Prediction

    Link: https://arxiv.org/abs/2105.08649

    Author: Zekai Chen, Fangtian Zhong, Zhumin Chen, Xiao Zhang, Robert Pless, Xiuzhen Cheng

    Developer: anbo

    Date: 2021-11-19

    inputs: 3d tensor (batch_size, seq_len, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

    """
  def __init__(self,
               hidden_units=16,
               heads=4,
               l2_reg=0.001,
               dropout_rate=0.1,
               seed=1024,
               list_tag=False,
               mha_type='origin',
               dim_e=None,
               synthesizer_type='dense',
               window=1,
               concat_heads=True,
               pool_size=2,
               strides=1,
               product_type='inner',
               n_layers=2,
               projection_hidden_units=[4, 1],
               apply_final_act=False,
               use_bn=False,
               act_fn='relu',
               name='DCAPModel'):
    """
    Args:
        rnn_unit: int, rnn hidden units
        rnn_act_fn: string, activation function in rnn
        return_sequences: bool, whether return hidden states of rnn
        apply_final_act: whether to apply act in final layer
        projection_hidden_units: list, unit in each hidden layer
        act_fn: string, activation function
        l2_reg: float, regularization value
        dropout_rate: float, fraction of the units to dropout.
        use_bn: boolean, if True, apply BatchNormalization in each hidden layer
        seed: int, random value for initialization

    """
    super(DCAPModel, self).__init__(name='DCAPModel')
    self.dcap_layer = DCAPLayer(hidden_units=hidden_units,
                                heads=heads,
                                l2_reg=l2_reg,
                                dropout_rate=dropout_rate,
                                seed=seed,
                                list_tag=list_tag,
                                mha_type=mha_type,
                                dim_e=dim_e,
                                synthesizer_type=synthesizer_type,
                                window=window,
                                concat_heads=concat_heads,
                                pool_size=pool_size,
                                strides=strides,
                                product_type=product_type,
                                n_layers=n_layers,
                                name="{}_dcap_layer".format(name))

    self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units,
                              activation=act_fn,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              apply_final_act=apply_final_act,
                              seed=seed,
                              name="{}_dnn_layer".format(name))

  def call(self, inputs, mask=None, extra_input=None, training=None):
    """
    Args:
        inputs: 3d tensor (batch_size, len, dim_1), sequence features
        extra_input: 2d tensor (batch_size, dim_2), wide features

    Returns:
        2d tensor (batch_size, out_dim)

    """
    dcap_output = self.dcap_layer(inputs, mask=mask)
    tf.logging.info('DCAPModel: dcap_output {}'.format(dcap_output))

    if extra_input is not None:
      if tf.keras.backend.ndim(dcap_output) > 2:
        dcap_output = tf.keras.layers.Flatten()(dcap_output)
      combined_input = tf.keras.layers.Concatenate(axis=-1)(
          [dcap_output, extra_input])
      tf.logging.info('DCAPModel: combined_input {}'.format(combined_input))

      rnn_output = self.dnn_layer(combined_input, training=training)

    tf.logging.info('DCAPModel: rnn_output: {}'.format(rnn_output))
    return rnn_output
