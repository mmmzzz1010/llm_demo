# coding: utf-8
# @Author: anbo
# @Date: 2021-04-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.spatial import CoActionLayer

class CANModel(tf.keras.Model):
    """
    MModel: CAN model

    Paper: CAN: Revisiting Feature Co-Action for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/2011.05625

    Author: Guorui Zhou, Weijie Bian, et.al

    Developer: anbo

    Date: 2021-04-08

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units=[8], use_bias=True, projection_hidden_units=[4,1], act_fn='relu', l2_reg=0.001,
                 dropout_rate=0, use_bn=False, seed=1024, apply_final_act=False, name='CANModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(CANModel, self).__init__(name='CANModel')
        self.co_action_layer = CoActionLayer(hidden_units=hidden_units, apply_final_act=True, use_bias=use_bias, name="{}_co_action_layer".format(name))
        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: tuple, (input_a, input_b)
            input_a: (batch, dim1)
            input_b: (batch, dim2)

            dim2 >> dim1

        Returns:
            2d tensor (batch_size, out_dim)

        """
        co_action_output = self.co_action_layer(inputs)
        tf.logging.info('CANModel: co_action_output {}'.format(co_action_output))

        if extra_input is not None:
            if tf.keras.backend.ndim(extra_input) > 2:
                extra_input = tf.keras.layers.Flatten()(extra_input)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([co_action_output, extra_input])
        else:
            combined_input = co_action_output

        tf.logging.info('CANModel: combined_input {}'.format(combined_input))

        output = self.dnn_layer(combined_input, training=training)

        return output

