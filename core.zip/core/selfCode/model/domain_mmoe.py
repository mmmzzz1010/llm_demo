# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import GeneralMMoELayer


class DomainMMoEModel(tf.keras.Model):
    """
    Model: Domain MMoE Model

    Paper: Modeling Task Relationships in Multi-task Learning with Multi-gate Mixture-of-Experts

    Link: dl.acm.org/doi/10.1145/3219819.3220007

    Author: Jiaqi Ma, Zhe Zhao, Xinyang Yi, Jilin Chen, Lichan Hong, Ed Chi

    Developer: anbo

    Date: 2020-03-23

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
    def __init__(self, experts_hidden_units, sharing_hidden_units, task_hidden_units,
                 task_apply_final_act=False, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 seed=1024, bias_init=[], is_bias_net=False, experts_bias_hidden_units=[], bias_sharing_hidden_units=[],
                 name='DomainMMoEModel'):
        """
        Args:
            experts_hidden_units: list of list, unit of each hidden layer in expert layers
            experts_bias_hidden_units: list of list, unit of each hidden layer in expert layers
            sharing_hidden_units: list, unit in each hidden layer
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            seed: int, random value for initialization
            bias_init=[[0.6, 0.3, 0.1], [0.3, 0.6, 0.1], [0.1, 0.3, 0.6]],
        """
        super(DomainMMoEModel, self).__init__(name='DomainMMoEModel')
        self.num_experts = len(experts_hidden_units)
        self.num_tasks = len(task_hidden_units)
        self.bias_init = bias_init

        self.gmmoe_layer = GeneralMMoELayer(num_experts=self.num_experts, num_tasks=self.num_tasks, bias_init=self.bias_init, l2_reg=l2_reg, seed=seed,name="{}_mmoe_layer".format(name))

        self.sharing_layer = DNNLayer(hidden_units=sharing_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed,name="{}_sharing_dnn_layer".format(name))

        self.bias_sharing_layer = DNNLayer(hidden_units=bias_sharing_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                           dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, name="{}_bias_sharing_dnn_layer".format(name))

        self.expert_ctr_layers = []
        self.expert_bn_layers = []
        for i, units in enumerate(experts_hidden_units):
            self.expert_ctr_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                             dropout_rate=dropout_rate, use_bn=use_bn,
                                             apply_final_act=True, seed=seed, name="{}_expert_ctr_{}_dnn_layer".format(name,i)))
            self.expert_bn_layers.append(tf.keras.layers.BatchNormalization(name="{}_expert_bn_{}_dnn_layer".format(name,i)))

        self.expert_bias_layers = []
        self.expert_bias_bn_layers = []
        for i, units in enumerate(experts_bias_hidden_units):
            self.expert_bias_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, use_bn=use_bn,
                                                    apply_final_act=True, seed=seed, name="{}_expert_bias_{}_dnn_layer".format(name,i)))
            self.expert_bias_bn_layers.append(tf.keras.layers.BatchNormalization(name="{}_expert_bias_bn_{}_dnn_layer".format(name,i)))

        self.task_layers = []
        for i, units in enumerate(task_hidden_units):
            self.task_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                      dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=task_apply_final_act, seed=seed, name="{}_task_{}_dnn_layer".format(name,i)))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features

        Returns:
            list of 2d tensor (batch_size, out_dim)

        """
        ctr_expert_inputs = self.sharing_layer(inputs, training=training)
        tf.logging.info('DomainMMoEModel: ctr_expert_inputs {}'.format(ctr_expert_inputs))

        if extra_input is not None:
            bias_expert_inputs = self.bias_sharing_layer(extra_input, training=training)
            tf.logging.info('DomainMMoEModel: bias_expert_inputs {}'.format(bias_expert_inputs))
            expert_inputs = tf.keras.layers.Concatenate(axis=-1)([ctr_expert_inputs, bias_expert_inputs])
        else:
            expert_inputs = ctr_expert_inputs
        tf.logging.info('DomainMMoEModel: expert_inputs {}'.format(expert_inputs))

        expert_outputs_list = []
        for i in range(self.num_experts):
            expert_bn_outputs_i = self.expert_bn_layers[i](ctr_expert_inputs, training=training)
            expert_ctr_outputs_i = self.expert_ctr_layers[i](expert_bn_outputs_i, training=training)
            if extra_input is not None:
                expert_bias_bn_outputs_i = self.expert_bias_bn_layers[i](bias_expert_inputs, training=training)
                expert_bias_outputs_i = self.expert_bias_layers[i](expert_bias_bn_outputs_i, training=training)
                expert_outputs_i = tf.keras.layers.Concatenate(axis=-1)([expert_ctr_outputs_i, expert_bias_outputs_i])
            else:
                expert_outputs_i = expert_ctr_outputs_i
            expert_outputs_i = tf.keras.layers.Lambda(lambda x: tf.expand_dims(x, axis=-1))(expert_outputs_i)
            tf.logging.info('DomainMMoEModel: {}th expert, expert_output {}'.format(i, expert_outputs_i))
            expert_outputs_list.append(expert_outputs_i)

        expert_outputs = tf.keras.layers.Concatenate(axis=-1)(expert_outputs_list)
        tf.logging.info('DomainMMoEModel: expert_outputs {}'.format(expert_outputs))

        task_inputs = self.gmmoe_layer([expert_inputs, expert_outputs])

        task_outputs = []
        for i in range(self.num_tasks):
            task_outputs.append(self.task_layers[i](task_inputs[i], training=training))
            tf.logging.info('DomainMMoEModel: {}th task, task_output {}'.format(i, task_outputs[-1]))

        return task_outputs

