# coding: utf-8
# @Author: anbo
# @Date: 2020-11-05
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import GeneralMMoELayer


class MoSEModel(tf.keras.Model):
    """
    Model: MoSE model

    Paper: Multitask Mixture of Sequential Experts for User Activity Streams

    Link: https://www.kdd.org/kdd2020/accepted-papers/view/multitask-mixture-of-sequential-experts-for-user-activity-streams

    Author: Yicheng Cheng; Zhen Qin, Zhe Zhao; Zhe Chen; Donald Metzler; Jingzheng Qin

    Developer: anbo

    Date: 2020-11-05

    inputs:
        3d tensor (batch_size, seq_len, dim_1)

    outputs:
        list of 3d tensor (batch_size, seq_len, out_dim)

    """
    def __init__(self, hidden_units, input_dim, experts_rnn_units=[32, 32], sharing_rnn_units=32, task_rnn_units=[16, 16],
                 projection_hidden_units=1, l2_reg=0.001, seed=1024, name='MoSEModel'):
        """
        Args:
            input_unit: int, last dim of inputs
            experts_rnn_units: list of int, unit of each hidden layer in expert layers
            sharing_rnn_units: int, unit in each hidden layer
            task_rnn_units: list of int, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            l2_reg: float, regularization value
            seed: int, random value for initialization

        """
        super(MoSEModel, self).__init__(name='MoSEModel')
        self.num_experts = len(experts_rnn_units)
        self.num_tasks = len(task_rnn_units)

        self.dnn_layer = tf.keras.layers.TimeDistributed(
            tf.keras.layers.Dense(hidden_units, activation='elu', use_bias=True))

        self.sharing_rnn_layer = tf.keras.layers.LSTM(units=sharing_rnn_units, activation='tanh', return_sequences=True, return_state=False)
        self.expert_rnn_layers = []
        for i in range(self.num_experts):
            self.expert_rnn_layers.append(tf.keras.layers.LSTM(units=experts_rnn_units[i], activation='tanh', return_sequences=True, return_state=False))

        self.task_rnn_layers = []
        self.linear_layers = []
        for i in range(self.num_tasks):
            self.task_rnn_layers.append(
                tf.keras.layers.LSTM(units=task_rnn_units[i], activation='tanh', return_sequences=True,
                                     return_state=False))
            self.linear_layers.append(tf.keras.layers.TimeDistributed(
                tf.keras.layers.Dense(projection_hidden_units, activation=None, use_bias=True)))

        self.gate_weight = tf.get_variable(name='gate_weight', shape=[input_dim, self.num_experts,  self.num_tasks],
                                        dtype=tf.float32, initializer=tf.initializers.he_normal(seed=seed))
        self.gate_bias = tf.get_variable(name='gate_bias', shape=[self.num_experts,  self.num_tasks], dtype=tf.float32,
                                    initializer=tf.keras.initializers.Zeros())

    def __build_gate_func(self, inputs):
        gate_input, expert_outputs = inputs
        # gate_input: (batch, seq_len, d)
        # expert_outputs: (batch, seq_len, d1, num_experts)
        gate_output = tf.add(tf.tensordot(gate_input, self.gate_weight, axes=[-1, 0]), self.gate_bias)
        gate_score = tf.nn.softmax(gate_output, axis=1)
        # gate_scopre: (batch, seq_len, num_experts, num_tasks)
        tf.logging.info('MoSEModel: gate_score {}'.format(gate_score))

        task_inputs = tf.keras.backend.batch_dot(expert_outputs, gate_score, axes=[3, -2])
        # task_inputs: (batch, seq_len, d1, num_tasks)
        tf.logging.info('MoSEModel: task_inputs {}'.format(task_inputs))
        return [task_inputs[:,:,:,i] for i in range(self.num_tasks)]

    def call(self, inputs, extra_input=None, mask=None, training=None):
        """
        inputs:
            3d tensor (batch_size, seq_len, dim_1)

        outputs:
            list of 3d tensor (batch_size, seq_len, out_dim)
        """
        seq_len = inputs.get_shape()[1].value
        shared_input = inputs
        if extra_input is not None:
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.expand_dims(x, axis=1))(extra_input)
            extra_input_3d = tf.keras.layers.Lambda(lambda x: tf.keras.backend.tile(x, [1, seq_len, 1]))(extra_input_3d)
            tf.logging.info('MoSEModel: extra_input_3d {}'.format(extra_input_3d))
            shared_input = tf.keras.layers.Concatenate(axis=-1)([inputs, extra_input_3d])

        tf.logging.info('MoSEModel: expert_inputs {}'.format(shared_input))

        expert_inputs = self.sharing_rnn_layer(shared_input)
        tf.logging.info('MoSEModel: expert_inputs {}'.format(expert_inputs))

        expert_outputs_list = []
        for i in range(self.num_experts):
            expert_outputs_i = self.expert_rnn_layers[i](expert_inputs)
            # expert_outputs_i: (batch, seq_len, d1)
            expert_outputs_i = tf.keras.layers.Lambda(lambda x: tf.expand_dims(x, axis=-1))(expert_outputs_i)
            tf.logging.info('MoSEModel: {}th exprt, expert_output {}'.format(i, expert_outputs_i))
            expert_outputs_list.append(expert_outputs_i)

        expert_outputs = tf.keras.layers.Concatenate(axis=-1)(expert_outputs_list)
        # expert_outputs: (batch, seq_len, d1, num_experts)
        tf.logging.info('MoSEModel: expert_outputs {}'.format(expert_outputs))

        task_inputs = self.__build_gate_func([shared_input, expert_outputs])

        task_outputs = []
        for i in range(self.num_tasks):
            task_rnn_output_i = self.task_rnn_layers[i](task_inputs[i], training=training)
            task_output_i = self.linear_layers[i](task_rnn_output_i)
            task_outputs.append(tf.keras.layers.Flatten()(task_output_i))
            tf.logging.info('MoSEModel: {}th task, task_output_i {}'.format(i, task_output_i))

        return task_outputs