# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import TransformerEncoder
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer
from alps_biz.core.layer.attention import InterestActLayer

class DSINModel(tf.keras.Model):
    """
    Model: DSIN Model

    Paper: Deep Session Interest Network for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1904.06690

    Author: Yufei Feng , Fuyu Lv, Weichen Shen and Menghan Wang and Fei Sun  and Yu Zhu and Keping Yang

    Developer: anbo

    Date: 2020-03-24

    inputs: list of tensors, [a,b],
                    a: 3d tensor (batch, session_len, seq_len, hidden_units)
                    b: 2d tensor (batch, dim)

    output: (batch, hidden_units)

    """
    def __init__(self, hidden_units, heads, intermediate_size, n_transform_layers=1, act_fn='relu',
                 dropout_rate=0, l2_reg=0.001, return_all_layers=False,
                 rnn_unit=64, projection_hidden_units=[4, 1],
                 apply_final_act=False, use_bn=False, seed=1024, min_timescale=1.0, max_timescale=1.0e4,
                 pos_type='fixed', mha_type='origin',
                 dim_e=3,
                 synthesizer_type='dense',
                 inf=1e9,
                 name='DSINModel'):
        """
        Args:
            n_transform_layers: int, num of transformer encoder layers
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(DSINModel, self).__init__(name='DSINModel')
        self.hidden_units = hidden_units
        assert (hidden_units % heads == 0), ('hidden_units must be dividable by heads')

        self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale, pos_type=pos_type, name="{}_pos_enco_layer".format(name))

        self.bert_layer = TransformerEncoder(n_layers=n_transform_layers, hidden_units=hidden_units, heads=heads,
                                           intermediate_size=intermediate_size, act_fn=act_fn, dropout_rate=dropout_rate,
                                           l2_reg=l2_reg, return_all_layers=return_all_layers,
                                            mha_type=mha_type, dim_e=dim_e, synthesizer_type=synthesizer_type, inf=inf,
                                            name="{}_transformer_layer".format(name))

        self.item_interact_layer = InterestActLayer(l2_reg=l2_reg, name="{}_item_interestact_layer".format(name))
        self.hidden_interact_layer = InterestActLayer(l2_reg=l2_reg, name="{}_hidden_interestact_layer".format(name))
        self.rnn_layer = tf.keras.layers.GRU(units=rnn_unit, return_sequences=True, name="{}_gru_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None, lego='standard'):
        """
        Args:
            inputs: list of tensors, [a,b],
                    a: 3d tensor (batch, session_len, seq_len, hidden_units)
                    b: 2d tensor (batch, dim)
        Returns:
            3d tensor (batch_size, out_dim)

        """
        sequence_input, item_input = inputs

        input_dim = tf.keras.backend.int_shape(sequence_input)[-1]
        assert (input_dim == self.hidden_units), ("last dim of inputs must equal to hidden_units")
        input_length = tf.keras.backend.int_shape(sequence_input)[-2]
        session_length = tf.keras.backend.int_shape(sequence_input)[1]

        sequence_input = tf.keras.layers.Lambda(lambda x: tf.reshape(x, shape=(-1, input_length, input_dim)))(sequence_input)
        tf.logging.info('DSINModel: inputs reshaped {}'.format(sequence_input))
        seq_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(input_dim, tf.float32))))(sequence_input)
        seq_input = self.position_layer(seq_input)

        bert_output = self.bert_layer(seq_input, training=training, lego=lego)

        session_output = tf.keras.layers.Lambda(lambda x: tf.reshape(x, shape=(-1, session_length, input_length, input_dim)))(bert_output)
        tf.logging.info('DSINModel: session_output reshaped {}'.format(session_output))

        session_output = tf.keras.layers.Lambda(lambda x: tf.reduce_mean(x, axis=2, keep_dims=False))(session_output)
        tf.logging.info('DSINModel: session_output sum pooled {}'.format(session_output))

        item_interact_output = self.item_interact_layer([session_output, item_input])
        tf.logging.info('DSINModel: item_interact_output {}'.format(item_interact_output))

        rnn_output = self.rnn_layer(session_output)
        hidden_interact_output = self.hidden_interact_layer([rnn_output, item_input])
        tf.logging.info('DSINModel: hidden_interact_output {}'.format(hidden_interact_output))

        dsin_output = tf.keras.layers.Concatenate()([item_interact_output, hidden_interact_output, item_interact_output])
        tf.logging.info('DSINModel: dsin_output {}'.format(dsin_output))

        if extra_input is not None:
            if tf.keras.backend.ndim(bert_output) > 2:
                bert_output = tf.keras.layers.Flatten()(dsin_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([dsin_output, extra_input])
            tf.logging.info('DSINModel: combined_input {}'.format(combined_input))

            dsin_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('DSINModel: dsin_output {}'.format(dsin_output))
        return dsin_output
