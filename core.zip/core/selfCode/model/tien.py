# coding: utf-8
# @Author: anbo
# @Date: 2021-04-07
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.attention import GeneralMultiHeadAttnLayer, PositionalEncodingLayer
from alps_biz.core.layer.core import DNNLayer


class TIENModel(tf.keras.Model):
    """
    Model: TIEN Model

    Paper: Deep Time-Aware Item Evolution Network for Click-Through Rate Prediction

    Link: https://dl.acm.org/doi/abs/10.1145/3340531.3411952

    Author: Xiang Li, Chao Wang, Bin Tong, Jiwei Tan, Xiaoyi Zeng, Tao Zhuang

    Developer: anbo

    Date: 2021-04-07

    inputs: (batch, fields, hidden_units)

    output: (batch, hidden_units)

    """
    def __init__(self, rnn_unit=32, rnn_act_fn='tanh', hidden_size=16, hidden_units=[64, 32], heads=4,
                 act_fn='relu', dropout_rate=0, l2_reg=0.001, projection_hidden_units=[4, 1],
                 apply_final_act=False, use_bn=False, seed=1024,
                 name='TIENModel'):
        """
        Args:
            n_transform_layers: int, num of transformer encoder layers
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(TIENModel, self).__init__(name='TIENModel')
        self.item_behavior_gru_layer = tf.keras.layers.GRU(units=rnn_unit, activation=rnn_act_fn, return_sequences=True, return_state=False, name="{}_item_behavior_gru_layer".format(name))
        self.time_evolution_gru_layer = tf.keras.layers.GRU(units=rnn_unit, activation=rnn_act_fn, return_sequences=False, return_state=False, name="{}_time_evolution_gru_layer".format(name))

        self.bert_layer = GeneralMultiHeadAttnLayer(hidden_units=hidden_size, heads=heads, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate, list_tag=True,
                                                    name="{}_general_mha_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False, seed=seed, name="{}_dnn_layer".format(name))

        self.projection_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed,
                                  name="{}_projection_layer".format(name))

    def call(self, inputs, extra_input=None, training=None, lego='standard'):
        """
        Args:
            inputs: tuple, (user_input, item_input, item_behavior_input, time_interval_input)
            user_input: (batch, dim)
            item_input: (batch, dim)
            item_behavior_input: (batch, len, dim)
            time_interval_input: (batch, len, dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        user_input, item_input, item_behavior_input, time_interval_input = inputs

        # Time Interval Attention Layer
        item_behavior_hidden_output = self.item_behavior_gru_layer(item_behavior_input)
        h_utk = item_behavior_hidden_output + time_interval_input

        # Robust Personalized Attention Layer
        e_u_smooth = user_input + tf.reduce_sum(item_behavior_input, axis=1, keepdims=False)
        e_u_smooth = tf.expand_dims(e_u_smooth, axis=1)
        bert_output = self.bert_layer([e_u_smooth, h_utk, item_behavior_hidden_output], training=training, lego=lego)
        e_rpi = self.dnn_layer(bert_output, training=training)
        e_rpi = tf.squeeze(e_rpi, axis=1)
        tf.logging.info('TIENModel: e_rpi {}'.format(e_rpi))

        # Time Aware Evolution Layer
        h_tiv = self.time_evolution_gru_layer(time_interval_input)
        h_item = tf.keras.layers.Concatenate(axis=-1)([h_tiv, e_rpi])
        tf.logging.info('TIENModel: h_item {}'.format(h_item))

        if extra_input is not None:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([h_item, user_input, item_input, extra_input])
            tf.logging.info('TIENModel: combined_input {}'.format(combined_input))
        else:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([h_item, user_input, item_input])

        output = self.projection_layer(combined_input, training=training)
        tf.logging.info('TIENModel: output {}'.format(output))
        return output
