# coding: utf-8
# @Author: anbo
# @Date: 2021-04-07
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import TransformerEncoder
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import HierarchicalAttnAggLayer

class InterHAtModel(tf.keras.Model):
    """
    Model: InterHAt Model

    Paper: Interpretable Click-Through Rate Prediction through Hierarchical Attention

    Link: https://dl.acm.org/doi/pdf/10.1145/3336191.3371785

    Author: Zeyu Li, Wei Cheng, Yang Chen, Haifeng Chen, Wei wang

    Developer: anbo

    Date: 2021-04-07

    inputs: (batch, fields, hidden_units)

    output: (batch, hidden_units)

    """
    def __init__(self, n_layers=4, hidden_size=16, hidden_units=16, heads=4, intermediate_size=64,
                 n_transform_layers=1, act_fn='relu',
                 dropout_rate=0, l2_reg=0.001, return_all_layers=False, projection_hidden_units=[4, 1],
                 apply_final_act=False, use_bn=False, seed=1024, mha_type='origin',
                 name='InterHAtModel'):
        """
        Args:
            n_transform_layers: int, num of transformer encoder layers
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(InterHAtModel, self).__init__(name='InterHAtModel')

        self.bert_layer = TransformerEncoder(n_layers=n_transform_layers, hidden_units=hidden_units, heads=heads,
                                           intermediate_size=intermediate_size, act_fn=act_fn, dropout_rate=dropout_rate,
                                           l2_reg=l2_reg, return_all_layers=return_all_layers, mha_type=mha_type,
                                          name="{}_transformer_layer".format(name))

        self.hierarchicalattn_layer = HierarchicalAttnAggLayer(n_layers=n_layers, hidden_size=hidden_size, l2_reg=l2_reg, seed=seed, name="{}_hierarchicalattn_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None, lego='standard'):
        """
        Args:
            inputs: 3d tensor (batch, fields, hidden_units)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        bert_output = self.bert_layer(inputs, training=training, lego=lego)

        hierarchical_attn_output = self.hierarchicalattn_layer(bert_output)

        if extra_input is not None:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([hierarchical_attn_output, extra_input])
            tf.logging.info('InterHAtModel: combined_input {}'.format(combined_input))
        else:
            combined_input = hierarchical_attn_output

        output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('InterHAtModel: output {}'.format(output))
        return output
