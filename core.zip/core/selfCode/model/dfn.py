# coding: utf-8
# @Author: anbo
# @Date: 2021-04-07
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.attention import GeneralMultiHeadAttnLayer, PositionalEncodingLayer
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.interaction import FMLayer

class DFNModel(tf.keras.Model):
    """
    Model: External feedback interaction component

    Paper: Deep Feedback Network for Recommendation

    Link: https://www.ijcai.org/Proceedings/2020/349

    Author: Ruobing Xie, Cheng Ling, Yalong Wang, Rui Wang, Feng Xia, Leyu Lin

    Developer: anbo

    Date: 2021-04-07

    inputs: list of tensors,

    outputs: 2d tensor, (batch, dim3)

    """
    def __init__(self, hidden_units=[64, 16], mlp_units=[16, 1], hidden_size=16, heads=4,
                 act_fn='relu', dropout_rate=0, l2_reg=0.001, projection_hidden_units=[4, 1],
                 apply_final_act=False, use_bn=False, seed=1024, no_explicit_pos_hist=True,
                 name='DFNModel'):
        """
        Args:
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(DFNModel, self).__init__(name='DFNModel')
        self.no_explicit_pos_hist = no_explicit_pos_hist

        self.bert_layer = GeneralMultiHeadAttnLayer(hidden_units=hidden_size, heads=heads, l2_reg=l2_reg,
                                                    dropout_rate=dropout_rate,
                                                    name="{}_general_mha_layer".format(name))

        self.fm_layer = FMLayer(name="{}_fm_layer".format(name))

        self.implicit_uc_dnn_layer = DNNLayer(hidden_units=mlp_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=False, seed=seed,
                                  name="{}_efic_mlp_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=True, seed=seed,
                                  name="{}_deep_component_layer".format(name))

        self.linear_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_linear_projection_layer".format(name))

    def external_feedback_interaction_component(self, pooled_behavior_input, behavior_input, mlp_layer):
        """
        :param pooled_behavior_input: 3d tensor, (batch, 1, dim)
        :param behavior_input: behavior from another type, 3d tensor, (batch, len, dim)
        :param mlp_layer: tf.keras.layers.Layer object, DNNLayer
        :return: 2d tensor (batch, dim)
        """
        seq_len = tf.keras.backend.int_shape(behavior_input)[1]
        # pooled_behavior_input_expand = tf.tile(pooled_behavior_input, [1, seq_len, 1])
        pooled_behavior_input_expand = tf.keras.backend.repeat_elements(pooled_behavior_input, seq_len, axis=1)
        element_wise_output = tf.keras.layers.Multiply()([pooled_behavior_input_expand, behavior_input])
        combined_input = tf.keras.layers.Concatenate(axis=-1)([pooled_behavior_input_expand, behavior_input, pooled_behavior_input_expand-behavior_input, element_wise_output])
        tf.logging.info('DFNModel: external_feedback_interaction_component, combined_input {}'.format(combined_input))

        dnn_output = mlp_layer(combined_input)
        # dnn_output: (batch, len, 1)
        tf.logging.info('DFNModel: external_feedback_interaction_component, dnn_output {}'.format(dnn_output))
        attn_score = tf.nn.softmax(dnn_output, axis=1)

        attn_score = tf.keras.backend.permute_dimensions(attn_score, (0, 2, 1))
        output = tf.matmul(attn_score, behavior_input)
        # output: (batch, 1, dim)

        # output = tf.squeeze(output, axis=1)
        # tf.logging.info('DFNModel: output {}'.format(output))
        return output

    def internal_feedback_interaction_component(self, behavior_input, item_input, mha_layer, mask=None, training=None):
        """
        :param behavior_input: sequence bahvior , 3d tensor, (batch, len, dim)
        :param item_input: input features, 2d tensor of (batch, dim), or 3d tensor (batch, 1, dim)
        :param mha_layer: multihead attention layer
        :return: 3d tensor, (batch, 1, dim)
        """
        if tf.keras.backend.ndim(item_input) == 2:
            item_input = tf.expand_dims(item_input, axis=1)
            # item_input: (batch, 1, dim)

        extend_behavior_input = tf.keras.layers.Concatenate(axis=1)([item_input, behavior_input])

        behavior_output = mha_layer(extend_behavior_input, mask=mask, training=training)
        tf.logging.info('DFNModel: behavior_output {}'.format(behavior_output))
        pooled_behavior_output = tf.reduce_mean(behavior_output, axis=1, keepdims=True)

        return pooled_behavior_output

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: tuple, (user_input, item_input, implicit_pos_hist, implicit_neg_hist, explicit_pos_hist)
            user_input: (batch, fields, dim)
            item_input: (batch, 1, dim)
            *_hist: (batch, len, dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        if self.no_explicit_pos_hist:
            user_input, item_input, implicit_pos_hist, implicit_neg_hist = inputs
            implicit_pos_mask = None
            implicit_neg_mask = None
            explicit_pos_hist = None
            explicit_pos_mask = None
        else:
            user_input, item_input, implicit_pos_hist, implicit_neg_hist, explicit_pos_hist = inputs

        pooled_implicit_pos_hist = self.internal_feedback_interaction_component(implicit_pos_hist, item_input, self.bert_layer, mask=implicit_pos_mask, training=training)
        pooled_implicit_neg_hist = self.internal_feedback_interaction_component(implicit_neg_hist, item_input, self.bert_layer, mask=implicit_neg_mask, training=training)

        uc_feedback_output = self.external_feedback_interaction_component(pooled_implicit_pos_hist, implicit_neg_hist, self.implicit_uc_dnn_layer)

        seq_output_list = [pooled_implicit_pos_hist, pooled_implicit_neg_hist, uc_feedback_output]

        if explicit_pos_hist is not None:
            pooled_explicit_pos_hist = self.internal_feedback_interaction_component(explicit_pos_hist, item_input,
                                                                                    self.bert_layer, mask=explicit_pos_mask, training=training)

            ud_feedback_output = self.external_feedback_interaction_component(pooled_explicit_pos_hist,
                                                                              implicit_neg_hist,
                                                                              self.implicit_uc_dnn_layer)
            seq_output_list.append(pooled_explicit_pos_hist)
            seq_output_list.append(ud_feedback_output)

        seq_output = tf.keras.layers.Concatenate(axis=1)(seq_output_list)
        tf.logging.info('DFNModel: seq_output {}'.format(seq_output))

        fm_input = tf.keras.layers.Concatenate(axis=1)([user_input, item_input, seq_output])
        tf.logging.info('DFNModel: fm_input {}'.format(fm_input))

        fm_output = self.fm_layer(fm_input)
        tf.logging.info('DFNModel: fm_output {}'.format(fm_output))

        deep_output = self.dnn_layer(tf.keras.layers.Flatten()(fm_input), training=training)
        tf.logging.info('DFNModel: deep_output {}'.format(deep_output))

        if extra_input is not None:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([fm_output, deep_output, extra_input])
        else:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([fm_output, deep_output])
        tf.logging.info('DFNModel: combined_input {}'.format(combined_input))

        output = self.linear_layer(combined_input, training=training)

        tf.logging.info('DFNModel: output {}'.format(output))
        return output
