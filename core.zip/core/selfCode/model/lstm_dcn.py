# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.interaction import CrossLayer


class LSTMDCNModel(tf.keras.Model):
    """
    Model: DCN Model

    Paper: Deep & Cross Network for Ad Click Predictions

    Link: https://arxiv.org/abs/1708.05123

    Author: Ruoxi Wang, Bin Fu, Gang Fu, Mingliang Wang

    Developer: anbo

    Date: 2019-12-09

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, rnn_unit, rnn_act_fn='tanh', return_sequences=False, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 n_cross_layers=2, seed=1024):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            n_cross_layers: int, num of cross layers
            seed: int, random value for initialization

        """
        super(LSTMDCNModel, self).__init__(name='LSTMDCNModel')
        self.rnn_layer = tf.keras.layers.LSTM(units=rnn_unit, activation=rnn_act_fn,
                                                return_sequences=return_sequences, return_state=False)
        self.cross_layer = CrossLayer(n_layers=n_cross_layers, l2_reg=l2_reg)
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed)

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, n_dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        if extra_input is not None:
            rnn_output = self.rnn_layer(extra_input)
            tf.logging.info('LSTMDCNModel: rnn_output {}'.format(rnn_output))
            if tf.keras.backend.ndim(rnn_output) > 2:
                rnn_output = tf.keras.layers.Flatten()(rnn_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([rnn_output, inputs])
        else:
            combined_input = inputs
        tf.logging.info('LSTMDCNModel: combined_input {}'.format(combined_input))

        cross_output = self.cross_layer(combined_input)
        dnn_output = self.dnn_layer(combined_input, training=training)

        combined_output = tf.keras.layers.Concatenate()([cross_output, dnn_output])
        tf.logging.info('LSTMDCNModel: combined_output {}'.format(combined_output))
        return combined_output

