# coding:utf-8
# @Author: yunjian
# @Date: 2019-11-26
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import itertools
import tensorflow as tf
from alps_biz.core.layer.isotonic_layer import IsotonicLayer
from alps_biz.core.common.constants import DIPNConstants
from alps_biz.core.layer.multitask_meta_layers import ESMMMetaLayer


class DIPN(tf.keras.Model):
    """ DIPN is a multitask model using ESMM. The core structure for each task
    is an isotonic layer. More details can refer to 
    https://yuque.antfin-inc.com/docs/share/b71ea6a2-2120-457f-aa21-d5086c908338#

    Author: buli

    Developer: yunjian

    """
    def __init__(self,
                 task_name_to_label_name,
                 n_hidden_units_isotonic_layer,
                 amount_buckets,
                 amount_bucket_incs,
                 uplift_weight_prior=0.0,
                 essm_task_dependencies=None):
        """
        Args:
            task_name_to_label_name: a dict maps task name to label name
            n_hidden_units_isotonic_layer: the hidden units number of isotonic layer
            amount_buckets: a numpy ndarray for amount buckets.
            amount_bucket_incs: a numpy ndarray for amount bucket increase.
            uplift_weight_prior: a float number specifies the prior of uplift weight
            essm_task_dependencies: label key dependencies for ESMM. See
                `alps_biz.core.model.dipn.build_dependencies_essm` fore more details.

        """
        super(DIPN, self).__init__(name="DIPN_model")
        essm_task_dependencies = essm_task_dependencies or []
        self.amount_buckets = tf.convert_to_tensor(amount_buckets)
        self.amount_bucket_incs = tf.convert_to_tensor(amount_bucket_incs)
        amount_bucket_num = len(amount_buckets)
        layer_factory = lambda: IsotonicLayer(
            n_hidden_units_isotonic_layer,
            uplift_weight_prior,
            amount_bucket_num
        )
        self.multitask_meta_layer = ESMMMetaLayer(
            task_name_to_label_name,
            essm_task_dependencies,
            layer_factory=layer_factory,
        )

    def call(self, non_amount_input_embedding, amount_input):
        """
        Args:
            non_amount_input_embedding: a tensor of shape (batch_size, embedding_dim) specifies the embedding of non
                amount input
            amount_input: a tensor of shape (batch_size, 1) specifies the input amount value

        Returns:
            a dict of tensors including:
                h_1_base: a tensor of shape (batch_size, amount_bucket_num)
                h_2_smoothed: a tensor of shape (batch_size, )
                amount_buckets: a tensor of shape (amount_bucket_num, )
                amount_bucket_incs: a tensor of shape (amount_bucket_num-1, )
                amount_input: the input amount input tensor of shape (batch_size, 1)
        """
        task_dict = self.multitask_meta_layer([non_amount_input_embedding, amount_input, self.amount_buckets])
        task_dict_new = {}
        for task_name, values in task_dict.items():
            h_2_smoothed, h_1_base = values
            task_dict_new[task_name] = {
                DIPNConstants.H1_SCORE: h_1_base,
                DIPNConstants.H2_SCORE: h_2_smoothed,
                DIPNConstants.AMOUNT_BUCKETS: self.amount_buckets,
                DIPNConstants.AMOUNT_BUCKET_INCS: self.amount_bucket_incs,
                DIPNConstants.AMOUNT_INPUT: amount_input,
            }
        return task_dict_new
