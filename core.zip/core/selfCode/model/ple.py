# coding: utf-8
# @Author: anbo
# @Date: 2020-10-10
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.multimodality import CGCGatingNetworkLayer, ParallelDNNLayer


class PLEModel(tf.keras.Model):
    """
    Model: PLE model

    Paper: Progressive Layered Extraction (PLE): A Novel Multi-Task Learning (MTL) Model for Personalized Recommendations

    Link: dl.acm.org/doi/10.1145/3383313.3412236

    Author: Hongyan Tang, Junning Liu, Ming Zhao, Xudong Gong

    Developer: anbo

    Date: 2020-10-10

    inputs:
        2d tensor (batch_size, input_dim)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
    def __init__(self, expert_units, n_task_experts, n_shared_experts, task_hidden_units,
                 task_apply_final_act=False, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 seed=1024, name='PLEModel'):
        """
        Args:
            expert_units: list of int, unit of each hidden layer in expert layers
            n_task_experts: list of list of int, n_task_experts in each task-specific Expert domain
            n_shared_experts: list of int, n_shared_experts in each shared expert domain
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            seed: int, random value for initialization

        """
        super(PLEModel, self).__init__(name='PLEModel')
        self.num_tasks = len(task_hidden_units)
        # there is self.num_tasks final tasks and expert domains, plus one shared expert domain
        self.num_cgc_layers = len(expert_units)
        # need special treatement in the first and final layers
        # there is only one input in the first cgc layer
        # there are multiple inputs from each expert domain in the middle layers
        # there is no need to calculate gating network in shared expert in the last layer
        assert ((len(n_task_experts) == len(n_shared_experts)) and (len(n_task_experts) == self.num_cgc_layers)), ('There must be the same number of cgc_layers')

        for i, units in enumerate(n_task_experts):
            assert (len(units) == self.num_tasks), ('There must be equal number of task-specific expert domain as num of tasks')

        self.cgc_task_expert_layers, self.cgc_shared_expert_layers, self.cgc_gating_layers = [], [], []
        for i in range(self.num_cgc_layers):
            self.cgc_task_expert_layers.append([ParallelDNNLayer(hidden_units=[expert_units[i]], activation=act_fn, l2_reg=l2_reg, dropout_rate=dropout_rate,
                                                                 use_bn=use_bn, apply_final_act=True, seed=seed, n_experts=unit,
                                                                 name='{}th_cgc_layer_{}th_task-specific_expert_paralleldnnlayer'.format(i, j)) for j, unit in enumerate(n_task_experts[i])])

            self.cgc_shared_expert_layers.append(ParallelDNNLayer(hidden_units=[expert_units[i]], activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=True,
                                  seed=seed, n_experts=n_shared_experts[i],
                                  name='{}th_cgc_layer_shared_expert_paralleldnnlayer'.format(i)))

            n_cgc_gatings = self.num_tasks + 1 if i < self.num_cgc_layers-1 else self.num_tasks
            # by default, last cgc gating network in each cgc layer is shared expert domain
            self.cgc_gating_layers.append([CGCGatingNetworkLayer(l2_reg=l2_reg, seed=seed, name='{}th_cgc_layer_{}th_cgc_gating_network_layer'.format(i,j))
                                           for j in range(n_cgc_gatings)])

        self.task_layers = []
        for i, units in enumerate(task_hidden_units):
            self.task_layers.append(DNNLayer(hidden_units=units, activation=act_fn, l2_reg=l2_reg,
                                      dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=task_apply_final_act,
                                    seed=seed, name="{}_task_{}_dnn_layer".format(name,i)))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features

        Returns:
            list of 2d tensor (batch_size, out_dim)
        """
        task_expert_outputs = []
        shared_expert_output = inputs
        for i in range(self.num_cgc_layers):
            shared_expert_input = shared_expert_output
            shared_expert_output = self.cgc_shared_expert_layers[i](shared_expert_input)
            # shared_expert_output: (batch, n_shared_experts, dim)
            tf.logging.info('PLEModel: {}th cgc layer, before gating network, shared_expert_output {}'.format(i, shared_expert_output))

            tmp_task_expert_outputs = []
            for j in range(self.num_tasks):
                # calculate task-specific experts
                if i == 0:
                    task_expert_input = inputs
                    task_expert_output = self.cgc_task_expert_layers[i][j](task_expert_input)
                    #task_expert_outputs.append(task_expert_output)
                else:
                    task_expert_input = task_expert_outputs[j]
                    task_expert_output = self.cgc_task_expert_layers[i][j](task_expert_input)
                    #task_expert_outputs[j] = task_expert_output
                # task_expert_output: (batch, n_task_experts, dim)
                tf.logging.info('PLEModel: {}th cgc layer, {}th task expert, before gating network task_expert_output {}'.format(i, j, task_expert_output))
                tmp_task_expert_outputs.append(task_expert_output)

                # calculate task-shared gating net output
                task_cgc_gating_network_output = self.cgc_gating_layers[i][j]([task_expert_output, shared_expert_output, task_expert_input])
                # task_cgc_gating_network_output: (batch, dim)
                tf.logging.info('PLEModel: {}th cgc layer, {}th task expert, after gating network task_cgc_gating_network_output {}'.format(i, j, task_cgc_gating_network_output))

                if i == 0:
                    task_expert_outputs.append(task_cgc_gating_network_output)
                else:
                    task_expert_outputs[j] = task_cgc_gating_network_output

            if i < self.num_cgc_layers - 1:
                combined_task_expert_output = tf.keras.layers.Concatenate(axis=1)(tmp_task_expert_outputs) if len(tmp_task_expert_outputs) > 1 else tmp_task_expert_outputs[0]
                shared_expert_output = self.cgc_gating_layers[i][-1]([combined_task_expert_output, shared_expert_output, shared_expert_input])
                tf.logging.info('PLEModel: {}th cgc layer, shared_expert_output {}'.format(i, shared_expert_output))

        task_outputs = []
        for i in range(self.num_tasks):
            task_outputs.append(self.task_layers[i](task_expert_outputs[i], training=training))
            tf.logging.info('PLEModel: {}th task, task_output {}'.format(i, task_outputs[-1]))

        return task_outputs

