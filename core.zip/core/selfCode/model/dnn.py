# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer

class DNNModel(tf.keras.Model):
    """
    Model: DNN or MLP Model

    Developer: anbo

    Date: 2020-03-20

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
    def __init__(self, hidden_units, act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False,
                 seed=1024, apply_final_act=False, name='DNNModel'):
        """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(DNNModel, self).__init__(name='DNNModel')
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: 2d tensor (batch_size, dim_1), deep features
            wide_input: 2d tensor (batch_size, dim_2), wide features

        Returns:
            2d tensor (batch_size, out_dim)

        """
        dnn_output = self.dnn_layer(inputs, training=training)

        return dnn_output

