# coding: utf-8
# @Author: anbo
# @Date: 2021-09-03
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import WeightedAttentionLayer
from alps_biz.core.layer.search import FineSeqLayer
from alps_biz.core.model import MaskNetModel


class FBASModel(tf.keras.Model):
  """
    Model: FBAS Model

    Paper: FBAS: Field-wise User Behavior Modelling with Augmented Semantics forClick-Through Rate Prediction

    Link: 

    Author: Anbo, yunjian, xianyu

    Developer: anbo

    Date: 2021-09-03

    inputs: (batch, seq_len, hidden_units)

    output: (batch, hidden_units)

    """
  def __init__(self,
               hidden_size=32,
               projection_hidden_units=[8, 1],
               l2_reg=0.001,
               use_bn=False,
               seed=1024,
               drop_prob=0.1,
               n_layers=2,
               n_mask_blocks=1,
               lego='parallel',
               name='FBASModel'):
    """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
    super(FBASModel, self).__init__(name='FBASModel')

    self.field_wise_inter_layer = FineSeqLayer(
        n_layers=n_layers,
        l2_reg=l2_reg,
        seed=seed,
        drop_prob=drop_prob,
        name="{}_field_wise_inter_layer".format(name))
    self.sequence_agg_layer = WeightedAttentionLayer(
        l2_reg=l2_reg,
        seed=seed,
        name="{}_sequence_aggregator_layer".format(name))

    self.projection_layer = MaskNetModel(
        n_mask_blocks=n_mask_blocks,
        lego=lego,
        hidden_size=hidden_size,
        projection_hidden_units=projection_hidden_units,
        name="{}_masknet_layer".format(name))

  def call(self, inputs, extra_input=None, training=None):
    """
        Args:
            inputs: list, [user_feature, seq_input, item_feature]
            user_feature: (batch, dim1)
            seq_input: (batch_size, seq_len, dim_2)
            item_feature: (batch, dim3)

        Returns:
            2d tensor (batch_size, out_dim)

        """
    tf.logging.info('FBASModel: inputs {}'.format(inputs))
    user_feature, seq_input, item_feature = inputs

    # find seq cross layer
    seq_output = self.field_wise_inter_layer([seq_input, item_feature],
                                             training=training)
    seq_output = self.sequence_agg_layer(seq_output)
    tf.logging.info('FBASModel: seq_output {}'.format(seq_output))

    if extra_input is not None:
      combined_input = tf.keras.layers.Concatenate(axis=-1)(
          [seq_output, extra_input, user_feature, item_feature])
    else:
      combined_input = tf.keras.layers.Concatenate(axis=-1)(
          [seq_output, user_feature, item_feature])
    tf.logging.info('FBASModel: combined_input {}'.format(combined_input))

    output = self.projection_layer(combined_input, training=training)
    tf.logging.info('FBASModel: output {}'.format(output))
    return output
