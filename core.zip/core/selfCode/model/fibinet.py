# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.multimodality import BiLinearInteractionLayer
from alps_biz.core.layer.attention import SENETLayer

class FiBiNetModel(tf.keras.Model):
    """
    Model: FiBiNet Model

    PPaper: FiBiNET- Combining Feature Importance and Bilinear feature Interaction for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1905.09433

    Author: Tongwen Huang, Zhiqi Zhang, Junlin Zhang

    Developer: anbo

    Date: 2020-10-12

    inputs: 3d tensor (batch_size, fields, n_dim)

    outputs: 2d tensor (batch_size, out_dim)

    """
    def __init__(self, reduction_ratio, bilinear_type='field_all', projection_hidden_units=[4,1],
                 act_fn='relu', l2_reg=0.001, dropout_rate=0, use_bn=False, apply_final_act=False,
                 seed=1024, name='FiBiNetModel'):
        """
        Args:
            reduction_ratio: int
            bilinear_type: string, 'field_all', 'field_each', 'field_interaction'
            projection_hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
        super(FiBiNetModel, self).__init__(name='FiBiNetModel')
        self.senet_layer = SENETLayer(reduction_ratio=reduction_ratio, act_fn=act_fn, l2_reg=l2_reg, seed=seed, name="{}_senet_layer".format(name))
        self.emb_bilinar_layer = BiLinearInteractionLayer(bilinear_type=bilinear_type, l2_reg=l2_reg, seed=seed, name="{}_emb_bilinear_interaction_layer".format(name))
        self.hidden_bilinar_layer = BiLinearInteractionLayer(bilinear_type=bilinear_type, l2_reg=l2_reg, seed=seed, name="{}_hidden_bilinear_interaction_layer".format(name))
        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed, apply_final_act=apply_final_act, name="{}_projection_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: 3d tensor (batch_size, fields, n_dim)

        Returns:
            2d tensor (batch_size, out_dim)

        """
        senet_output = self.senet_layer(inputs)
        tf.logging.info('FiBiNetModel: senet_output {}'.format(senet_output))

        emb_bilinear_output = self.emb_bilinar_layer(inputs)
        tf.logging.info('FiBiNetModel: emb_bilinear_output {}'.format(emb_bilinear_output))
        senet_bilinear_output = self.hidden_bilinar_layer(senet_output)
        tf.logging.info('FiBiNetModel: senet_bilinear_output {}'.format(senet_bilinear_output))

        combined_input = tf.keras.layers.Concatenate(axis=-1)([emb_bilinear_output, senet_bilinear_output])
        if tf.keras.backend.ndim(combined_input) > 2:
            combined_input = tf.keras.layers.Flatten()(combined_input)

        if extra_input is not None:
            combined_input = tf.keras.layers.Concatenate(axis=-1)([combined_input, extra_input])

        tf.logging.info('FiBiNetModel: combined_input {}'.format(combined_input))
        dnn_output = self.dnn_layer(combined_input, training=training)
        tf.logging.info('FiBiNetModel: dnn_output {}'.format(dnn_output))
        return dnn_output

