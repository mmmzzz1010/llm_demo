# coding: utf-8
# @Author: anbo
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import SeqCrossLayer

class SeqCrossModel(tf.keras.Model):
    """
    Model: SeqCross Model

    Paper:

    Link:

    Author:

    Developer: anbo

    Date: 2020-03-20

    inputs: list of tensors [input_1, input_2]
            input_1: (batch, seq_len, dim_1)
            input_2: (batch, dim_2)

    output: (batch, hidden_units)

    """
    def __init__(self, n_layers=2, l2_reg=0.001,
                 remove_attention=False, keep_attention_value=False, flatten_output_seq=True,
                 hidden_units=[64, 16], act_fn='relu', dropout_rate=0, use_bn=False, seed=1024):
        """
        Args:
            n_layers: int, number of layers
            l2_reg: float, regularization value
            remove_attention: bool
            keep_attention_value: bool
            flatten_output_seq: bool
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization
        """
        super(SeqCrossModel, self).__init__(name='SeqCrossModel')

        self.seqcross_layer = SeqCrossLayer(n_layers=n_layers, l2_reg=l2_reg, remove_attention=remove_attention,
                                            keep_attention_value=keep_attention_value, flatten_output_seq=flatten_output_seq, seed=seed, dropout_rate=dropout_rate)
        self.dnn_layer = DNNLayer(hidden_units=hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, seed=seed)

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of tensors [input_1, input_2]
            input_1: (batch, seq_len, dim_1)
            input_2: (batch, dim_2)

        output: (batch, hidden_units)
        """
        seq_inputs, uic_inputs = inputs
        # seq_inputs: (batch, seq_len, dim_1)
        # uic_inputs: (batch, dim_2)

        seqcross_output = self.seqcross_layer(inputs)
        tf.logging.info('SeqCrossModel: seqcross_output {}'.format(seqcross_output))

        if tf.keras.backend.ndim(seqcross_output) == 3:
            seqcross_output = tf.keras.layers.Flatten()(seqcross_output)

        combined_input = tf.keras.layers.Concatenate()([seqcross_output, uic_inputs])
        tf.logging.info('SeqCrossModel: combined_input {}'.format(combined_input))

        if extra_input is not None:
            if tf.keras.backend.ndim(combined_input) > 2:
                combined_input = tf.keras.layers.Flatten()(combined_input)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([combined_input, extra_input])
            tf.logging.info('SeqCrossModel: combined_input {}'.format(combined_input))

            dnn_output = self.dnn_layer(combined_input, training=training)
        else:
            dnn_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('SeqCrossModel: dnn_output {}'.format(dnn_output))
        return dnn_output
