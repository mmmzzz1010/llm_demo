# coding: utf-8
# @Author: anbo
# @Date: 2021-09-28
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import GeneralMMoELayer
from alps_biz.core.layer.sequence import FuseLayer


class SARNetModel(tf.keras.Model):
  """
    Model: SAR-Net Model

    Paper: SAR-Net: A Scenario-Aware Ranking Network for Personalized Fair Recommendation in Hundreds of Travel Scenarios

    Link: https://ata.alibaba-inc.com/articles/211809

    Author: Qijie Shen, Wanjie Tao, Jing Zhang, Hong Wen, Zulong Chen, Quan Lu

    Developer: anbo

    Date: 2021-09-28

    inputs:
        2d tensor (batch_size, dim_1)

    outputs:
        list of 2d tensor (batch_size, out_dim)

    """
  def __init__(self,
               experts_hidden_units,
               sharing_hidden_units,
               task_hidden_units,
               fuse_hidden_units=16,
               task_apply_final_act=False,
               act_fn='relu',
               l2_reg=0.001,
               dropout_rate=0,
               use_bn=False,
               seed=1024,
               input_length=10,
               name='SARNetModel'):
    """
        Args:
            experts_hidden_units: list of list, unit of each hidden layer in expert layers
            sharing_hidden_units: list, unit in each hidden layer
            task_hidden_units: list of list, unit of each hidden layer in task specific layers
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            task_apply_final_act: bool
            seed: int, random value for initialization

        """
    super(SARNetModel, self).__init__(name='SARNetModel')
    self.num_experts = len(experts_hidden_units)
    self.num_tasks = len(task_hidden_units)

    self.feed_forward_attn_layer = FuseLayer(
        input_length=input_length,
        hidden_units=[fuse_hidden_units],
        l2_reg=l2_reg,
        dropout_rate=dropout_rate,
        use_bn=use_bn,
        seed=seed,
        name="{}_feed_forward_attn_layer".format(name))

    self.scenario_specific_transformer_layer = tf.keras.layers.Dense(
        units=fuse_hidden_units,
        activation=None,
        use_bias=True,
        name='scenario_specific_transformer_layer')

    self.gmmoe_layer = GeneralMMoELayer(num_experts=self.num_experts,
                                        num_tasks=self.num_tasks,
                                        l2_reg=l2_reg,
                                        seed=seed,
                                        name="{}_mmoe_layer".format(name))

    self.sharing_layer = DNNLayer(hidden_units=sharing_hidden_units,
                                  activation=act_fn,
                                  l2_reg=l2_reg,
                                  dropout_rate=dropout_rate,
                                  use_bn=use_bn,
                                  seed=seed,
                                  name="{}_sharing_dnn_layer".format(name))

    self.expert_layers = []
    for i, units in enumerate(experts_hidden_units):
      self.expert_layers.append(
          DNNLayer(hidden_units=units,
                   activation=act_fn,
                   l2_reg=l2_reg,
                   dropout_rate=dropout_rate,
                   use_bn=use_bn,
                   apply_final_act=True,
                   seed=seed,
                   name="{}_expert_{}_dnn_layer".format(name, i)))

    self.task_layers = []
    for i, units in enumerate(task_hidden_units):
      self.task_layers.append(
          DNNLayer(hidden_units=units,
                   activation=act_fn,
                   l2_reg=l2_reg,
                   dropout_rate=dropout_rate,
                   use_bn=use_bn,
                   apply_final_act=task_apply_final_act,
                   seed=seed,
                   name="{}_task_{}_dnn_layer".format(name, i)))

  def cross_scenario_behavior_extractor_fn(self,
                                           seq_input,
                                           item_input,
                                           scenario_context_input=None):
    """
    Args:
    seq_input: 3d tensor, (batch, seq_len, d)
    item_input: 2d tensor, (batch, d1)
    scenario_context_input: 2d tensor, (batch, d2)

    return:
    2d tensor, (batch, d3)
    """
    alpha_item = self.feed_forward_attn_layer([seq_input, item_input])
    # alpha_item: (batch, dim)
    alpha_item = tf.keras.backend.expand_dims(alpha_item, axis=1)
    tf.logging.info(
        'cross_scenario_behavior_extractor_fn: alpha_item {}'.format(
            alpha_item))
    if scenario_context_input is not None:
      alpha_scenario = self.feed_forward_attn_layer(
          [seq_input, scenario_context_input])
      # alpha_scenario: (batch, dim)
      alpha_scenario = tf.keras.backend.expand_dims(alpha_scenario, axis=1)
      v_cb = tf.reduce_sum(tf.multiply(tf.multiply(alpha_item, alpha_scenario),
                                       seq_input),
                           axis=1,
                           keepdims=False)
      # v_cb: (batch, d)
    else:
      v_cb = tf.reduce_sum(tf.multiply(alpha_item, seq_input),
                           axis=1,
                           keepdims=False)
      # v_cb: (batch, d)

    return v_cb

  def call(self, inputs, domain_split_size=None, training=None):
    """
    Args:
        inputs: 2d tensor (batch_size, dim_1), deep features

    Returns:
        list of 2d tensor (batch_size, out_dim)

    """
    user_input, seq_input, item_input, scenario_context_input = inputs

    v_cb = self.cross_scenario_behavior_extractor_fn(
        seq_input, item_input, scenario_context_input=scenario_context_input)

    # 4.4 scenario-specific transform layer
    scenario_merged_input = tf.keras.layers.Concatenate(axis=-1)(
        [user_input, item_input, v_cb])
    tf.logging.info(
        'SARNetModel: scenario_merged_input {}'.format(scenario_merged_input))
    v_prime = self.scenario_specific_transformer_layer(scenario_merged_input)
    tf.logging.info('SARNetModel: v_prime {}'.format(v_prime))

    # 4.5 mixture of debias experts
    expert_inputs = self.sharing_layer(v_prime, training=training)
    tf.logging.info('SARNetModel: expert_inputs {}'.format(expert_inputs))

    # domain_inputs = tf.split(v_prime,
    #                          num_or_size_splits=domain_split_size,
    #                          axis=0,
    #                          name='domain_split')
    # tf.logging.info('SARNetModel: domain_inputs {}'.format(domain_inputs))

    expert_outputs_list = []
    for i in range(self.num_experts):
      expert_outputs_i = self.expert_layers[i](v_prime, training=training)
      expert_outputs_i = tf.keras.layers.Lambda(
          lambda x: tf.expand_dims(x, axis=-1))(expert_outputs_i)
      tf.logging.info('SARNetModel: {}th exprt, expert_output {}'.format(
          i, expert_outputs_i))
      expert_outputs_list.append(expert_outputs_i)

    expert_outputs = tf.keras.layers.Concatenate(axis=-1)(expert_outputs_list)
    # expert_outputs: (batch, dim, n_domain_specific_experts)
    tf.logging.info('SARNetModel: expert_outputs {}'.format(expert_outputs))

    # 4.6 multi-gate network
    task_inputs = self.gmmoe_layer([expert_inputs, expert_outputs])

    # final task prediction layer
    task_outputs = []
    for i in range(self.num_tasks):
      task_outputs.append(self.task_layers[i](task_inputs[i],
                                              training=training))
      tf.logging.info('SARNetModel: {}th task, task_output {}'.format(
          i, task_outputs[-1]))

    return task_outputs
