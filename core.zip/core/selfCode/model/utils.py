# coding:utf-8
# @Author: 浩山
# @File: utils.py
# @Date: 2019-10-08
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf


OPTIMIZER_CLASSES = {
    "adagrad": tf.train.AdagradOptimizer,
    "adam": tf.train.AdamOptimizer,
    "ftrl": tf.train.FtrlOptimizer,
    "rmsprop": tf.train.RMSPropOptimizer,
    "sgd": tf.train.GradientDescentOptimizer,
}


def layer_summary(value):
    """Add value to tensorflow summary

    Args:
        value: add tensor
    Returns:
        None

    """
    tf.summary.scalar("fraction_of_zero_values", tf.nn.zero_fraction(value))
    tf.summary.histogram("activation", value)


def get_optimizer_class(optimizer_name="Adam"):
    """Get optimizer class.

    Args:
        optimizer_name: Optimizer name.

    Returns:
        Optimizer class.

    """
    return OPTIMIZER_CLASSES[optimizer_name.lower()]