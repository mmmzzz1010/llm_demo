# coding: utf-8
# @Author: anbo
# @Date: 2020-02-10
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import MultiCNNLayer, SimpleAttnLayer
from alps_biz.core.layer.core import DNNLayer


class MultiCNNModel(tf.keras.Model):
    """
    Model: MultiCNN Model

    Developer: anbo

    Date: 2020-02-10

    inputs: list of tensors, (input_a, input_b)
        * input_a: (batch, a_len, dim)
        * input_b: (batch, dim)

    returns: (batch, dim)

    """
    def __init__(self, filters=[4,4,4], kernel_size=[1,3,6], input_length=30, l2_reg=0.001, act_fn='relu', dropout_rate=0,
                 projection_hidden_units=[4, 1], apply_final_act=False, use_bn=False, seed=1024,name='MultiCNNModel'):
        """
        Args:
            filters: list, number of filters in each 1d conv channel
            kernel_size: list, number of kernel filter size in each 1d conv channel
            input_length: int, length of the input sequence
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
            dropout_rate: float, dropout rate
            act_fn: string, activation function
        """
        super(MultiCNNModel, self).__init__(name='MultiCNNModel')
        self.input_length = input_length

        self.cnn_layer = MultiCNNLayer(filters=filters, kernel_size=kernel_size, name="{}_multicnn_layer".format(name))
        self.attn_layer = SimpleAttnLayer(input_length=input_length, l2_reg=l2_reg, name="{}_simpleattn_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of tensors, (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, dim)

        Returns:
            (batch, dim)

        """
        seq_input, item_input = inputs

        cnn_output = self.cnn_layer(seq_input)
        tf.logging.info('MultiCNNModel: cnn_output {}'.format(cnn_output))

        attn_output = self.attn_layer([cnn_output, item_input])

        if extra_input is not None:
            if tf.keras.backend.ndim(attn_output) > 2:
                attn_output = tf.keras.layers.Flatten()(attn_output)
            combined_input = tf.keras.layers.Concatenate(axis=-1)([attn_output, extra_input])
            tf.logging.info('MultiCNNModel: combined_input {}'.format(combined_input))

            attn_output = self.dnn_layer(combined_input, training=training)

        tf.logging.info('MultiCNNModel: attn_output: {}'.format(attn_output))
        return attn_output
