# coding: utf-8
# @Author: anbo
# @Date: 2020-07-02
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import NextItNetLayer
from alps_biz.core.layer.core import DNNLayer


class NextItNetModel(tf.keras.Model):
    """
    Model: 2d dialted CNN and residual network as NextItNet

    Paper: A Simple but Hard-to-Beat Baseline for Session-based Recommendations

    Link: https://arxiv.org/abs/1706.03762

    Author: Fajie Yuan, Alexandros Karatzoglou, Ioannis Arapakis, Joemon M Jose, Xiangnan He

    Developer: anbo

    Date: 2020-07-02

    inputs: (batch, a_len, dim1)

    outputs: (batch, a_len)

    """

    def __init__(self, kernel_size, dilation_rate, final_filters, n_nextitnet_layers=1, l2_reg=0.001, act_fn='relu',
                 dropout_rate=0, projection_hidden_units=[4, 1], apply_final_act=False, use_bn=False, seed=1024, name='NextItNetModel'):
        """
        Args:
            filters: list, number of filters in each 1d conv channel
            kernel_size: list, number of kernel filter size in each 1d conv channel
            input_length: int, length of the input sequence
            l2_reg: float, regularization value
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value
            dropout_rate: float, dropout rate
            act_fn: string, activation function
        """
        super(NextItNetModel, self).__init__(name='NextItNetModel')
        self.n_nextitnet_layers = n_nextitnet_layers

        self.nextitnet_layers = []
        for i in range(self.n_nextitnet_layers):
            self.nextitnet_layers.append(NextItNetLayer(kernel_size=kernel_size, dilation_rate=dilation_rate,
                                                        name="{}_nextitnet_{}th_layer".format(name, i)))

        self.conv_layer = tf.keras.layers.Conv1D(filters=final_filters, kernel_size=1, strides=1,
                                                 padding='valid', data_format='channels_last',
                                                 activation=None, name="{}_final_cnn_layer".format(name))

        self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed,
                                  name="{}_dnn_layer".format(name))

    def call(self, inputs, extra_input=None, training=None):
        """
        Args:
            inputs: list of tensors, (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, dim)

        Returns:
            (batch, dim)

        """
        seq_len = inputs.get_shape()[1].value

        cnn_output = inputs
        for i in range(self.n_nextitnet_layers):
            cnn_output = self.nextitnet_layers[i](cnn_output) + cnn_output

        tf.logging.info('NextItNetModel: cnn_output {}'.format(cnn_output))

        attn_output = self.conv_layer(cnn_output)
        # attn_output: (batch, len, n)
        tf.logging.info('NextItNetModel: attn_output {}'.format(attn_output))

        if extra_input is not None:
            extra_input_3d = tf.keras.backend.expand_dims(extra_input, axis=1)
            extra_input_3d = tf.tile(extra_input_3d, [1, seq_len, 1])
            tf.logging.info('NextItNetModel: extra_input_3d {}'.format(extra_input_3d))

            attn_output = tf.keras.layers.Concatenate(axis=-1)([attn_output, extra_input_3d])

        tf.logging.info('NextItNetModel: attn_output {}'.format(attn_output))

        output = self.dnn_layer(attn_output, training=training)
        output = tf.squeeze(output, axis=-1)
        tf.logging.info('NextItNetModel: output: {}'.format(output))
        return output
