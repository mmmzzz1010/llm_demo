# coding: utf-8
# @Author: anbo
# @Date: 2019-12-09
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.sequence import TransformerEncoder, TransformerDecoder
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.attention import PositionalEncodingLayer

class TransformerModel(tf.keras.Model):
    """
    Model: Transformer Model

    Paper: Attention Is All You Need

    Link: https://arxiv.org/abs/1706.03762

    Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

    Developer: anbo

    Date: 2020-07-22

    inputs: (batch, seq_len, hidden_units)

    output: (batch, seq_len, hidden_units)

    """
    def __init__(self, hidden_units, heads, intermediate_size, n_enc_layers=1, n_dec_layers=1, act_fn='relu',
                 dropout_rate=0, l2_reg=0.001, return_all_layers=False, projection_hidden_units=[4, 1],
                 apply_final_act=False, use_bn=False, seed=1024, min_timescale=1.0, max_timescale=1.0e4,
                 pos_type='fixed',
                 mha_type='origin',
                 dim_e=3,
                 synthesizer_type='dense',
                 inf=1e9,
                 list_tag=True,
                 name='TransformerModel'):
        """
        Args:
            n_transform_layers: int, num of transformer encoder layers
            hidden_units: int, the last dim of the inputs
            heads: int, num of self-attention modules, must be dividable by hidden_units
            intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
            act_fn: string, activation function
            dropout_rate: float, dropout rate
            l2_reg: float, regularization value
            return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
            projection_hidden_units: list, units for the projection layer
            apply_final_act: whether to apply act in final layer
            use_bn: boolean, if True use BatchNormalization, otherwise not
            seed: int, random value

        """
        super(TransformerModel, self).__init__(name='TransformerModel')
        self.hidden_units = hidden_units
        assert (hidden_units % heads == 0), ('hidden_units must be dividable by heads')
        self.pos_type = pos_type

        if self.pos_type != 'no_pos':
            self.position_layer = PositionalEncodingLayer(min_timescale=min_timescale, max_timescale=max_timescale, pos_type = self.pos_type, name="{}_pos_enco_layer".format(name))

        self.encoder = TransformerEncoder(n_layers=n_enc_layers, hidden_units=hidden_units, heads=heads,
                                           intermediate_size=intermediate_size, act_fn=act_fn, dropout_rate=dropout_rate,
                                           l2_reg=l2_reg, return_all_layers=return_all_layers,
                                             mha_type=mha_type, dim_e=dim_e, synthesizer_type=synthesizer_type, inf=inf,
                                             name="{}_transformer_encoder_layer".format(name))

        self.decoder = TransformerDecoder(n_dec_layers=n_dec_layers, hidden_units=hidden_units, heads=heads,
                                          intermediate_size=intermediate_size, act_fn=act_fn, dropout_rate=dropout_rate,
                                          l2_reg=l2_reg, return_all_layers=return_all_layers,
                                          mha_type=mha_type, dim_e=dim_e, synthesizer_type=synthesizer_type, inf=inf, list_tag=list_tag,
                                          name="{}_transformer_decoder_layer".format(name))

        self.final_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_dnn_layer".format(name))

    def call(self, inputs, targets, enc_padding_mask=None,
             look_ahead_mask=None, dec_padding_mask=None, training=None, lego='standard'):
        """
        Args:
            inputs: 3d tensor (batch, seq_len, hidden_units)

        Returns:
            3d tensor (batch_size, seq_len, out_dim)

        """
        input_dim = tf.keras.backend.int_shape(inputs)[-1]
        assert (input_dim == self.hidden_units), ("last dim of inputs must equal to hidden_units")

        if self.pos_type != 'no_pos':
            enc_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(input_dim, tf.float32))))(inputs)
            enc_input = self.position_layer(enc_input)

            dec_input = tf.keras.layers.Lambda(lambda x: tf.multiply(x, tf.sqrt(tf.cast(input_dim, tf.float32))))(targets)
            dec_input = self.position_layer(dec_input)
        else:
            enc_input = inputs
            dec_input = targets

        enc_output = self.encoder(enc_input, training=training)
        tf.logging.info('TransformerModel: enc_output {}'.format(enc_output))
        # (batch_size, inp_seq_len, d_model)
        # dec_output.shape == (batch_size, tar_seq_len, d_model)
        dec_output = self.decoder(
            dec_input, enc_output=enc_output, look_ahead_mask=look_ahead_mask, dec_padding_mask=dec_padding_mask, training=training)
        tf.logging.info('TransformerModel: dec_output {}'.format(dec_output))

        final_output = self.final_layer(dec_output)  # (batch_size, tar_seq_len, target_vocab_size)
        tf.logging.info('TransformerModel: final_output {}'.format(final_output))
        return final_output
