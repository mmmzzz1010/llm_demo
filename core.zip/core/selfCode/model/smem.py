# coding: utf-8
# @Author: anbo
# @Date: 2020-09-22
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.multimodality import SpatialMemLayer


class SMemModel(tf.keras.Model):
    """
    Model: spatial memory network with 2 hops for vqa

    Paper: Ask, Attend and Answer: Exploring Question-Guided Spatial Attention for Visual Question Answering

    Link: https://cs-people.bu.edu/hxu/CVPR2016_VQA_workshop.pdf

    Author: Huijuan Xu, Kate Saenko

    Developer: anbo

    Date: 2020-09-22

    """
    def __init__(self, hidden_units, l2_reg=0, seed=1024,
                 projection_hidden_units=[4,1], apply_final_act=False, use_bn=False, act_fn='relu', dropout_rate=0,
                 name='SMemModel'):
        """
        Args:
            hidden_units: int
            l2_reg: float, regularization value
            seed: int, random value for initialization
            text_attention: bool
        """
        super(SMemModel, self).__init__(name='SMemModel')
        self.smem_layer = SpatialMemLayer(hidden_units=hidden_units, l2_reg=l2_reg, seed=seed, name="{}_smem_layer".format(name))

        self.final_layer = DNNLayer(hidden_units=projection_hidden_units, activation=act_fn, l2_reg=l2_reg,
                                  dropout_rate=dropout_rate, use_bn=use_bn, apply_final_act=apply_final_act, seed=seed, name="{}_projection_layer".format(name))

    def call(self, inputs, training=None):
        """
        Args:
            inputs: list of 3d tensors

        Returns:
            2d tensor (batch_size, out_dim)

        """
        dan_output = self.smem_layer(inputs, training=training)

        output = self.final_layer(dan_output, training=training)
        tf.logging.info('SMemModel: output {}'.format(output))
        return output

