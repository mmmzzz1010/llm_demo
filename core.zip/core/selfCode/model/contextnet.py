# coding: utf-8
# @Author: anbo
# @Date: 2021-08-17
# Copyright (c) Antfin, Inc. All rights reserved.

import tensorflow as tf
from alps_biz.core.layer.core import DNNLayer
from alps_biz.core.layer.spatial import ContextNetBlockLayer


class ContextNetModel(tf.keras.Model):
  """
    Model: ContextNet model

    Paper: ContextNet: A Click-Through Rate Prediction Framework Using Contextual information to Refine Feature Embedding

    Link: https://arxiv.org/abs/2107.12025

    Author: Zhiqiang Wang, Qingyun She, PengTao Zhang, Junlin Zhang

    Developer: anbo

    Date: 2021-08-17

    inputs: inputs: (batch, fields, dim1)

    outputs:
        2d tensor (batch_size, out_dim)

    """
  def __init__(self,
               hidden_size=32,
               share_aggregation_tag=True,
               point_fnn_tag=False,
               contextnet_block_layers=1,
               projection_hidden_units=[4, 1],
               act_fn='relu',
               l2_reg=0.001,
               dropout_rate=0,
               use_bn=False,
               seed=1024,
               apply_final_act=False,
               name='ContextNetModel'):
    """
        Args:
            hidden_units: list, unit in each hidden layer
            act_fn: string, activation function
            l2_reg: float, regularization value
            dropout_rate: float, fraction of the units to dropout.
            use_bn: boolean, if True, apply BatchNormalization in each hidden layer
            seed: int, random value for initialization

        """
    super(ContextNetModel, self).__init__(name='ContextNetModel')

    self.contextnet_block_layer = ContextNetBlockLayer(
        hidden_size=hidden_size,
        share_aggregation_tag=share_aggregation_tag,
        point_fnn_tag=point_fnn_tag,
        contextnet_block_layers=contextnet_block_layers,
        l2_reg=l2_reg,
        seed=seed,
        name="{}_contextnet_block_layer".format(name))

    self.dnn_layer = DNNLayer(hidden_units=projection_hidden_units,
                              activation=act_fn,
                              l2_reg=l2_reg,
                              dropout_rate=dropout_rate,
                              use_bn=use_bn,
                              apply_final_act=apply_final_act,
                              seed=seed,
                              name="{}_dnn_layer".format(name))

  def call(self, inputs, extra_input=None, training=None):
    """
    Args:
        inputs: (batch, fields, dim1)

    Returns: 2d tensor (batch, out_dim)
    """
    contextnet_output = self.contextnet_block_layer(inputs)
    tf.logging.info(
        'ContextNetModel: contextnet_output {}'.format(contextnet_output))

    if extra_input is not None:
      if tf.keras.backend.ndim(extra_input) > 2:
        extra_input = tf.keras.layers.Flatten()(extra_input)
      combined_input = tf.keras.layers.Concatenate(axis=-1)(
          [contextnet_output, extra_input])
    else:
      combined_input = contextnet_output

    tf.logging.info(
        'ContextNetModel: combined_input {}'.format(combined_input))
    output = self.dnn_layer(combined_input, training=training)

    return output
