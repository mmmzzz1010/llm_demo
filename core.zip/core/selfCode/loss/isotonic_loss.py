# coding:utf-8
# @Author: yunjian
# @Date: 2019-11-26
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf
from alps_biz.core.common.isotonic_utils import create_amount_encoding
from alps_biz.core.common.constants import DIPNConstants


class IsotonicLossFirstOrder(object):
    """First order isotonic loss.

    More details can refer to
    https://yuque.antfin-inc.com/docs/share/b71ea6a2-2120-457f-aa21-d5086c908338#

    Author: buli

    Developer: yunjian

    """
    def __init__(self,
                 alpha,
                 beta,
                 pred_keys=[
                     DIPNConstants.H1_SCORE, DIPNConstants.AMOUNT_INPUT,
                     DIPNConstants.AMOUNT_BUCKETS,
                     DIPNConstants.AMOUNT_BUCKET_INCS
                 ]):
        """
        Args:
            alpha: the weight of amount input when calculating upper and
                lowwer bound of amount input.
            beta: the bias of amount input when calculating upper and lowwer
                bount of amount input.
            pred_keys: the key list of corresponding tensor in model output
                dict.
        """
        self._pred_keys = pred_keys
        self._alpha = alpha
        self._beta = beta

    def __call__(self, labels, model_output_dict, weights=1.0):
        """
        Args:
            labels: label tensor
            model_output_dict: a dict model output tensors
            weights: sample weights when calculating loss. See
                tf.losses.compute_weighted_loss for more details.

        Returns:
            a tensor for calculated loss.

        """
        h_1, amount_input, amount_buckets, amount_bucket_incs = [
            model_output_dict[key] for key in self._pred_keys
        ]
        amount_input_lb = (1.0 - self._alpha) * amount_input - self._beta
        amount_input_ub = (1.0 + self._alpha) * amount_input + self._beta
        amount_encoding_lb, _ = create_amount_encoding(amount_input_lb,
                                                       amount_buckets)
        amount_encoding_ub, _ = create_amount_encoding(amount_input_ub,
                                                       amount_buckets)
        amount_encoding_filter = amount_encoding_ub - amount_encoding_lb

        offset = 0
        h_1 = h_1[:, 1 + offset:] / amount_bucket_incs[offset:]
        amount_encoding_filter = amount_encoding_filter[:, 1 + offset:]
        h_1 = h_1 * amount_encoding_filter + 1e-8 * amount_encoding_filter + 1e-10 * (
            1 - amount_encoding_filter)
        h_1_ratio = h_1 / tf.reshape(tf.reduce_sum(h_1, axis=1),
                                     [tf.shape(h_1)[0], 1])

        negative_entropy = tf.reduce_sum(h_1_ratio * tf.log(h_1_ratio) *
                                         amount_encoding_filter,
                                         axis=1)
        isotonic_loss = tf.losses.compute_weighted_loss(
            negative_entropy, weights)
        return isotonic_loss


class IsotonicLossSecondOrder(object):
    """Second order isotonic loss.

    More details can refer to
    https://yuque.antfin-inc.com/docs/share/b71ea6a2-2120-457f-aa21-d5086c908338#

    Author: buli

    Developer: yunjian

    """
    def __init__(
        self,
        pred_keys=[DIPNConstants.H1_SCORE, DIPNConstants.AMOUNT_BUCKET_INCS]):
        """
        Args:
            pred_keys: the key list of corresponding tensor in model output
                dict.

        """
        self._pred_keys = pred_keys

    def __call__(self, labels, model_output_dict, weights=1.0):
        """
        Args:
            labels: label tensor
            model_output_dict: a dict model output tensors
            weights: sample weights when calculating loss. See
                tf.losses.compute_weighted_loss for more details.

        Returns:
            a tensor for calculated loss.

        """
        h_1, amount_bucket_incs = [
            model_output_dict[key] for key in self._pred_keys
        ]

        offset = 0
        h_1 = h_1[:, 1 + offset:] / amount_bucket_incs[offset:]
        h_1_diff = tf.square(h_1[:, 1:] - h_1[:, :-1]) / (
            (1e-6 + h_1[:, :-1]) * (1e-6 + h_1[:, 1:]))
        mse = tf.reduce_mean(amount_bucket_incs[1:] /
                             tf.reduce_max(amount_bucket_incs[1:]) *
                             tf.square(h_1_diff),
                             axis=1)

        isotonic_loss = tf.losses.compute_weighted_loss(mse, weights)
        return isotonic_loss
