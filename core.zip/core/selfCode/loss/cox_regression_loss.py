import tensorflow as tf
from alps_biz.core.common.constants import Constants

class CoxRegressionLoss(object):
    def __init__(self, logits_key=Constants.LOGITS):
        self._logits_key = logits_key

    def __call__(self, labels, model_outputs):
        logits = model_outputs[self._logits_key]
        logits = tf.reshape(logits, [-1, 1])

        binary_labels = tf.concat([labels, 1 - labels], axis=1)
        y_ = tf.cast(binary_labels, tf.float32)
        y = tf.concat([-tf.log(1.0 - tf.exp(-logits)), logits], 1)
        loss = tf.reduce_mean(tf.multiply(y, y_)) * 2.0
        return loss


