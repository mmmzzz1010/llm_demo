# coding:utf-8
# @Author: yunjian
# @Date: 2019-11-26
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import unittest
import tensorflow as tf
import numpy as np
from alps_biz.core.loss.cox_regression_loss import CoxRegressionLoss
from alps_biz.tests.utils import run_tf_session


class CoxRegressionLossTest(unittest.TestCase):
    def test_cox_regression_loss(self):
        model_outputs = {"logits": tf.constant([[0.1], [0.2], [0.8], [0.9]])}
        labels = tf.constant([[0], [1], [0], [1]])
        loss_object = CoxRegressionLoss("logits")
        loss_tensor = loss_object(labels, model_outputs)
        actual_value = run_tf_session(loss_tensor)
        expected_value = 0.78240186
        self.assertTrue(np.isclose(expected_value, actual_value))
        

if __name__ == '__main__':
    unittest.main()
