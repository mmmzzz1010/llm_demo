# coding:utf-8
# @Author: yunjian
# @Date: 2019-12-10
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.
import tensorflow as tf


class SigmoidCrossEntropy(object):
    """Wraps tf.losses.sigmoid_cross_entropy to compute loss in
    alps-biz.

    """
    def __init__(self, logits_key):
        """
        Args:
            logits_key: The key of logits tensor in model output dict.

        """
        self._logits_key = logits_key

    def __call__(self, labels, model_output_dict, weights=1.0):
        """
        Args:
            labels: Label tensor
            model_output_dict: A dict model output tensors
            weights: Sample weights when calculating loss. See
                tf.losses.sigmoid_cross_entropy for more details.

        """
        logits = model_output_dict[self._logits_key]
        return tf.losses.sigmoid_cross_entropy(labels, logits, weights=weights)
