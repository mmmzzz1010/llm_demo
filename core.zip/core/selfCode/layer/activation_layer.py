# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf


class Dice(tf.keras.layers.Layer):
  """

    Model: Dice activation function

    Paper: Deep Interest Network for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1706.06978

    Author: Guorui Zhou, Chengru Song, Xiaoqiang Zhu, Ying Fan, Han Zhu, Xiao Ma, Yanghui Yan, Junqi Jin, Han Li, Kun Gai

    Developer: anbo

    Date: 2020-04-08

    """
  def __init__(self, axis=-1, epsilon=1.e-9, **kwargs):
    """
        Args:
            axis: int, the axis used to calculate data distribution
            epsilon: double, for smooth purpose
        """
    super(Dice, self).__init__(**kwargs)
    self.axis = axis
    self.epsilon = epsilon

  def build(self, input_shape):
    input_size = input_shape[-1]
    self.alpha = self.add_weight(name="dice_alpha",
                                 shape=(input_size,),
                                 initializer=tf.keras.initializers.Zeros(),
                                 trainable=True)
    self.bn = tf.keras.layers.BatchNormalization(axis=self.axis,
                                                 epsilon=self.epsilon,
                                                 center=False,
                                                 scale=False)
    self.act_layer = tf.keras.layers.Lambda(lambda x: tf.sigmoid(x))
    super(Dice, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    normed_input = self.bn(inputs, training=training)
    p = self.act_layer(normed_input)
    # To Do, need to check the dim of alpha and inputs
    return p * inputs + (1.0 - p) * self.alpha * inputs

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {'axis': self.axis, 'epsilon': self.epsilon}
    base_config = super(Dice, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class Swish(tf.keras.layers.Layer):
  """

    Model: Swish activation function

    Paper: SEARCHING FOR ACTIVATION FUNCTIONS

    Link: https://arxiv.org/pdf/1710.05941

    Author: Prajit Ramachandran, Barret Zoph, Quoc V. Le

    Developer: anbo

    Date: 2020-04-08

    """
  def __init__(self, **kwargs):
    super(Swish, self).__init__(**kwargs)

  def build(self, input_shape):
    self.act_layer = tf.keras.layers.Lambda(lambda x: tf.sigmoid(x))
    super(Swish, self).build(input_shape)

  def call(self, inputs, **kwargs):
    sigmoid_input = self.act_layer(inputs)
    return inputs * sigmoid_input

  def compute_output_shape(self, input_shape):
    return input_shape


class Gelu(tf.keras.layers.Layer):
  """

    Model: GELU activation function

    Paper: Gaussian Error Linear Units

    Link: https://arxiv.org/abs/1606.08415

    Author: Dan Hendrycks, Kevin Gimpel

    Developer: anbo

    Date: 2020-04-08

    For information: OpenAI GPT's gelu is slightly different (and gives slightly different results):
    0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))

    """
  def __init__(self, **kwargs):
    super(Gelu, self).__init__(**kwargs)

  def build(self, input_shape):
    self.act_layer = tf.keras.layers.Lambda(lambda x: 0.5 * (1.0 + tf.tanh(
        tf.sqrt(2. / 3.141592657) * (x + 0.044715 * tf.pow(x, 3)))))
    super(Gelu, self).build(input_shape)

  def call(self, inputs, **kwargs):
    cdf = self.act_layer(inputs)
    tf.logging.info('GELU Activation: cdf shape {}'.format(cdf))
    output = tf.keras.layers.Multiply()([inputs, cdf])
    return output

  def compute_output_shape(self, input_shape):
    return input_shape


class GroupNormLayer(tf.keras.layers.Layer):
  """

    Model: Group Norm

    Paper: Group Normalization

    Link: https://arxiv.org/abs/1803.08494

    Author: Yuxin Wu, Kaiming He

    Developer: anbo

    Date: 2020-11-03

    """
  def __init__(self, group=4, eps=1.e-9, **kwargs):
    self.group = group
    self.eps = eps
    super(GroupNormLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    self.hidden_units = int(input_shape[-1])
    self.kernel = self.add_weight(name='weight_w',
                                  shape=(self.hidden_units,),
                                  initializer=tf.keras.initializers.Ones(),
                                  trainable=True)
    self.bias = self.add_weight(name='bias_w',
                                shape=(self.hidden_units,),
                                initializer=tf.keras.initializers.Zeros(),
                                trainable=True)

    super(GroupNormLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    reshaped_inputs = tf.reshape(inputs,
                                 shape=(-1, self.group,
                                        self.hidden_units // self.group))
    tf.logging.info(
        'GroupNormLayer: reshaped_inputs {}'.format(reshaped_inputs))
    mean, var = tf.nn.moments(reshaped_inputs, axes=[-1], keep_dims=True)
    output = tf.keras.layers.Lambda(lambda x:
                                    (x[0] - x[1]) / tf.sqrt(x[2] + self.eps))(
                                        [reshaped_inputs, mean, var])

    reshaped_output = tf.reshape(output, shape=(-1, self.hidden_units))
    reshaped_output = tf.multiply(reshaped_output, self.kernel)
    reshaped_output = tf.keras.backend.bias_add(reshaped_output, self.bias)
    tf.logging.info(
        'GroupNormLayer: reshaped_output {}'.format(reshaped_output))
    return reshaped_output

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {'eps': self.eps, 'group': self.group}
    base_config = super(GroupNormLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class Squash(tf.keras.layers.Layer):
  """

    Model: Squash non-linear activation in capsulenet

    Paper: Dynamic Routing Between Capsules

    Link: http://papers.neurips.cc/paper/6975-dynamic-routing-between-capsules.pdf

    Author: Sara Sabour, Nicholas Frosst, Geoffrey E. Hinton

    Developer: anbo

    Date: 2021-11-05

    """
  def __init__(self, eps=1.e-9, **kwargs):
    self.eps = eps
    super(Squash, self).__init__(**kwargs)

  def build(self, input_shape):
    super(Squash, self).build(input_shape)

  def call(self, inputs, **kwargs):
    inputs_norm = tf.reduce_sum(tf.square(inputs), axis=-1, keepdims=True)
    scale = inputs_norm / (1.0 + inputs_norm) / tf.sqrt(inputs_norm + self.eps)
    return tf.multiply(scale, inputs)

  def compute_output_shape(self, input_shape):
    return input_shape
