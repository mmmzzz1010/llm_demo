# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape


class CrossStitchLayer(tf.keras.layers.Layer):
  """
    Model: Cross Stitch Layer

    Paper: Cross-stitch Networks for Multi-task Learning

    Link: https://arxiv.org/pdf/1604.03539

    Author: Ishan Misra, Abhinav Shrivastava, Abhinav Gupta, Martial Hebert

    Developer: anbo

    Date: 2020-04-28

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_units[-1])``.
    -    For instance, for a 2D input with shape ``(batch_size, input_dim)``,
            the output would have shape ``(batch_size, hidden_units[-1])``.

    """
  def __init__(self, **kwargs):
    super(CrossStitchLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
        """
    self.initial_shape = input_shape
    self.last_dims = [int(dim[-1]) for dim in input_shape]
    self.total_last_dim = sum(self.last_dims)
    tf.logging.info(
        'CrossStitchLayer: initial_shape {}, total_last_dim {}'.format(
            self.initial_shape, self.total_last_dim))

    self.cross_stitch_weight = self.add_weight(
        name='cross_stitch_weight',
        shape=(self.total_last_dim, self.total_last_dim),
        initializer=tf.initializers.identity(),
        trainable=True)
    super(CrossStitchLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: list of tensors (N, ..., dim_i)
        returns:
            list of tensors (N, ..., dim_i)
        """
    if not isinstance(inputs, (list or tuple)) or len(inputs) <= 1:
      tf.logging.info('inputs is not list or tuple, nothing to cross stitch')
      return inputs

    combined_input = tf.keras.layers.Concatenate(axis=-1)(inputs)
    cross_stitch_output = tf.keras.layers.Lambda(
        lambda x: tf.matmul(x[0], x[1]))(
            [combined_input, self.cross_stitch_weight])
    tf.logging.info(
        'CrossStitchLayer: cross_stitch_output {}'.format(cross_stitch_output))

    # for now, only supports list of 2d tensors as inputs
    outputs = []
    start_index = 0
    end_index = 0
    for i in range(len(inputs)):
      start_index = end_index
      end_index += self.last_dims[i]
      shape_i = list(-1 if s is None else s
                     for s in self.initial_shape[i].as_list())
      tf.logging.info('CrossStitchLayer: shape_i {}'.format(shape_i))
      outputs.append(
          tf.keras.layers.Lambda(lambda x: tf.reshape(x, shape=shape_i))(
              cross_stitch_output[:, start_index:end_index]))
    return outputs

  def compute_output_shape(self, input_shape):
    return input_shape


class GeneralMMoELayer(tf.keras.layers.Layer):
  """
    Model: General MMoE Layer

    Paper: Modeling Task Relationships in Multi-task Learning with Multi-gate Mixture-of-Experts

    Link: www.kdd.org/kdd2018/accepted-papers/view/modeling-task-relationships-in-multi-task-learning-with-multi-gate-mixture-

    Author: Jiaqi Ma, Zhe Zhao, Xinyang Yi, Jilin Chen, Lichan Hong, Ed Chi

    Developer: anbo

    Date: 2020-04-28

    inputs: list of tensors, [shared_outputs, experts_output]
            shared_outputs: (batch, dim_1)
            experts_output: (batch, dim_2, n_experts)
    returns:
        list of tensors (N, ..., dim_i)

    """
  def __init__(self,
               num_experts,
               num_tasks,
               bias_init=[],
               l2_reg=0.001,
               seed=1024,
               **kwargs):
    super(GeneralMMoELayer, self).__init__(**kwargs)
    #self.experts_hidden_units = experts_hidden_units
    # self.num_experts = len(self.experts_hidden_units)
    self.num_experts = num_experts
    self.num_tasks = num_tasks
    self.l2_reg = l2_reg
    self.seed = seed
    self.bias_init = bias_init

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
        """
    #assert input_shape is not None and len(input_shape) >= 2
    shared_input_dim = int(input_shape[0][-1])
    # self.last_expert_dims = [int(dim[-1]) for dim in self.experts_hidden_units]
    self.units = int(input_shape[1][1])

    self.input_ndims = len(input_shape[1])
    tf.logging.info(
        'GeneralMMoELayer: shared inputs are {} ndims tensor'.format(
            self.input_ndims))

    self.gate_kernels = self.add_weight(
        name='gate_kernels',
        shape=(shared_input_dim, self.num_experts, self.num_tasks),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.gate_bias = self.add_weight(name='gate_bias',
                                     shape=[self.num_experts, self.num_tasks],
                                     dtype=tf.float32,
                                     initializer=tf.keras.initializers.Zeros(),
                                     trainable=True)

    # shared_input_dim = int(input_shape[0][-1])
    # #self.last_expert_dims = [int(dim[-1]) for dim in self.experts_hidden_units]
    # self.units = int(input_shape[1][1])
    #
    # self.gate_kernels, self.gate_bias = [], []
    # for i in range(self.num_tasks):
    #     unit = shared_input_dim
    #     tf.logging.info('GeneralMMoELayer: unit {}'.format(unit))
    #     self.gate_kernels.append(self.add_weight(name='gate_kernel_task_{}'.format(i), shape=(unit, self.num_experts),
    #                                              initializer=tf.keras.initializers.he_normal(seed=self.seed),
    #                                              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg), trainable=True))
    #     self.gate_bias.append(
    #         self.add_weight(name='gate_bias_task_{}'.format(i), shape=(self.num_experts, ),
    #                         initializer=tf.keras.initializers.Zeros() if len(self.bias_init)==0 else tf.constant_initializer(self.bias_init[i]),
    #                         regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg), trainable=True))

    super(GeneralMMoELayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: list of tensors, [shared_outputs, experts_output]
                shared_outputs: (batch, dim_1)
                experts_output: (batch, dim_2, n_experts)
        returns:
            list of tensors (N, ..., dim_i)
        """
    shared_outputs, expert_outputs = inputs

    gate_output = tf.add(
        tf.tensordot(shared_outputs, self.gate_kernels, axes=[-1, 0]),
        self.gate_bias)
    gate_score = tf.nn.softmax(gate_output, axis=1)
    # gate_scopre: (batch, num_experts, num_tasks)
    tf.logging.info('GeneralMMoELayer: gate_score {}'.format(gate_score))

    for j in range(self.num_experts):
      for i in range(self.num_tasks):
        if self.input_ndims == 4:
          tf.summary.scalar('{}th_expert_for_{}th_task_gate'.format(j, i),
                            tf.reduce_mean(gate_score[:, :, j, i]))
        elif self.input_ndims == 3:
          tf.summary.scalar('{}th_expert_for_{}th_task_gate'.format(j, i),
                            tf.reduce_mean(gate_score[:, j, i]))

    final_outputs = tf.matmul(expert_outputs, gate_score)
    # final_outputs: (batch, dim_2, num_tasks)
    tf.logging.info('GeneralMMoELayer: final_outputs {}'.format(final_outputs))

    if self.input_ndims == 4:
      return [final_outputs[:, :, :, i] for i in range(self.num_tasks)]
    elif self.input_ndims == 3:
      return [final_outputs[:, :, i] for i in range(self.num_tasks)]

    # gate_outputs = []
    # for i in range(self.num_tasks):
    #     gate_output_i = tf.keras.backend.bias_add(tf.keras.backend.dot(shared_outputs, self.gate_kernels[i]), self.gate_bias[i])
    #     tf.logging.info('GeneralMMoELayer: {}th gate, gate_output {}'.format(i, gate_output_i))
    #     gate_output_i = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, axis=-1))(gate_output_i)
    #     gate_outputs.append(gate_output_i)
    #     for j in range(self.num_experts):
    #         tf.summary.scalar('{}_expert_gate_output_{}'.format(j, i), tf.reduce_mean(gate_output_i[:, j]))
    #
    # final_outputs = []
    # for i, gate_output in enumerate(gate_outputs):
    #     expanded_gate_output = tf.keras.backend.expand_dims(gate_output, axis=1)
    #     tf.logging.info('GeneralMMoELayer: {}th gate_experts, expanded_gate_output {}'.format(i, expanded_gate_output))
    #     weighted_expert_output = expert_outputs * tf.keras.backend.repeat_elements(expanded_gate_output, self.units, axis=1)
    #
    #     # expert_unit = int(expert_outputs[i].get_shape().as_list()[-1])
    #     # weighted_expert_output = expert_outputs[i] * tf.keras.backend.repeat_elements(expanded_gate_output, expert_unit, axis=1)
    #
    #     tf.logging.info('GeneralMMoELayer: {}th gate_experts, weighted_expert_output {}'.format(i, weighted_expert_output))
    #     final_outputs.append(tf.keras.backend.sum(weighted_expert_output, axis=2))
    #     tf.logging.info('GeneralMMoELayer: {}th gate_experts, final_outputs {}'.format(i, final_outputs[-1]))

    #return final_outputs

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[1])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return [input_shape[:-1] for _ in range(self.num_tasks)]

  def get_config(self):
    config = {
        'num_experts': self.num_experts,
        'num_tasks': self.num_tasks,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'bias_init': self.bias_init
    }
    base_config = super(GeneralMMoELayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class ResnetLayer(tf.keras.layers.Layer):
  """
    Model: Residual Network layer

    Paper: Deep Residual Learning for Image Recognition

    Link: https://arxiv.org/abs/1512.03385

    Author: Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun

    Developer: anbo

    Date: 2020-04-28

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_units[-1])``.
        - For instance, for a 2D input with shape ``(batch_size, input_dim)``,
            the output would have shape ``(batch_size, hidden_units[-1])``.

    """
  def __init__(self, n_blocks=2, l2_reg=0.001, seed=1024, **kwargs):
    super(ResnetLayer, self).__init__(**kwargs)
    self.n_blocks = n_blocks
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    size = int(input_shape[-1])
    self.kernels = []
    self.bias = []
    self.bn = []

    for i in range(self.n_blocks):
      self.kernels.append(
          self.add_weight(
              name="kernel_{}".format(i * 2),
              shape=(size, size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i * 2),
                          shape=(size,),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))
      self.bn.append(tf.keras.layers.BatchNormalization())
      self.kernels.append(
          self.add_weight(
              name="kernel_{}".format(i * 2 + 1),
              shape=(size, size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i * 2 + 1),
                          shape=(size,),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))
      self.bn.append(tf.keras.layers.BatchNormalization())
    super(ResnetLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    pre_input = inputs
    for i in range(self.n_blocks):
      next_input = tf.keras.backend.bias_add(
          tf.keras.backend.dot(pre_input, self.kernels[2 * i]),
          self.bias[2 * i])
      tf.logging.info('Resnet_layer: block {}, next_input {}'.format(
          2 * i, next_input))
      next_input = self.bn[i * 2](next_input, training=training)
      next_input = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(next_input)
      #next_input = self.kernels[i*2+1](next_input)
      next_input = tf.keras.backend.bias_add(
          tf.keras.backend.dot(next_input, self.kernels[2 * i + 1]),
          self.bias[2 * i + 1])
      tf.logging.info('Resnet_layer: block {}, next_input {}'.format(
          2 * i + 1, next_input))
      next_input = self.bn[i * 2 + 1](next_input, training=training)
      pre_input = pre_input + next_input
      pre_input = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(pre_input)
    return pre_input

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {
        'n_blocks': self.n_blocks,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(ResnetLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class HighWayLayer(tf.keras.layers.Layer):
  """
    Model: Highway Network layer

    Paper: Highway Networks

    Link: https://arxiv.org/abs/1505.00387

    Author: Rupesh Kumar Srivastava, Klaus Greff, Jürgen Schmidhuber

    Developer: anbo

    Date: 2020-04-28

    Y = H(x, W) * T(x, W_t) + x * (1 - T(x, W_t))

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_units[-1])``.
        - For instance, for a 2D input with shape ``(batch_size, input_dim)``,
            the output would have shape ``(batch_size, hidden_units[-1])``.
    """
  def __init__(self, act_fn='tanh', l2_reg=0.001, seed=1024, **kwargs):
    super(HighWayLayer, self).__init__(**kwargs)
    self.act_fn = act_fn
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape, **kwargs):
    self.dim = int(input_shape[-1])

    self.kernel_gate = self.add_weight(
        name='kernel_gate',
        shape=(self.dim, self.dim),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.bias_gate = self.add_weight(name='bias_gate',
                                     shape=(self.dim,),
                                     initializer=tf.keras.initializers.Zeros(),
                                     regularizer=tf.keras.regularizers.L1L2(
                                         0, self.l2_reg),
                                     trainable=True)

    self.kernel = self.add_weight(
        name='kernel',
        shape=(self.dim, self.dim),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.bias = self.add_weight(name='bias',
                                shape=(self.dim,),
                                initializer=tf.keras.initializers.Zeros(),
                                regularizer=tf.keras.regularizers.L1L2(
                                    0, self.l2_reg),
                                trainable=True)

    super(HighWayLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
          inputs: (*, dim)
        return: (*, dim)
        """
    gate = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernel_gate), self.bias_gate)
    gate = tf.keras.layers.Lambda(lambda x: tf.nn.sigmoid(x))(gate)
    tf.logging.info('HighWayLayer: gate {}'.format(gate))
    neg_gate = tf.keras.layers.Lambda(lambda x: 1.0 - x,
                                      output_shape=(self.dim,))(gate)

    transformed = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernel), self.bias)
    transformed = tf.keras.layers.Lambda(lambda x: tf.nn.tanh(x))(transformed)
    transformed_gated = tf.keras.layers.Multiply()([gate, transformed])
    tf.logging.info(
        'HighWayLayer: transformed_gated {}'.format(transformed_gated))
    transformed_neg = tf.keras.layers.Multiply()([neg_gate, inputs])
    tf.logging.info('HighWayLayer: transformed_neg {}'.format(transformed_neg))
    output = tf.keras.layers.Add()([transformed_gated, transformed_neg])
    tf.logging.info('HighWayLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {'act_fn': self.act_fn, 'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(HighWayLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class NextItemAttnLayer(tf.keras.layers.Layer):
  """
    Model: Next Item Attention layer

    Paper: Next Item Recommendation with Self-Attention

    Link: https://arxiv.org/abs/1808.06414

    Author: Shuai Zhang, Yi Tay, Lina Yao, Aixin Sun

    Developer: anbo

    Date: 2020-04-28

    this is the modified self attention layer in Next Item Recommendation with Self-attention

    inputs: (batch, len, dim)

    outputs: (batch, dim)

    """
  def __init__(self, l2_reg=0.001, seed=1024, **kwargs):
    super(NextItemAttnLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    dim = int(input_shape[-1])
    self.kernels, self.bias = [], []

    for i in range(2):
      self.kernels.append(
          self.add_weight(
              name='weight_{}'.format(i),
              shape=(dim, dim),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(dim,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    super(NextItemAttnLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        inputs: (batch, len, dim)
        outputs: (batch, dim)
        """
    query = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernels[0]), self.bias[0])
    key = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernels[1]), self.bias[1])

    query = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(query)
    key = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(key)
    # query, key: (batch, len, dim)
    tf.logging.info('NextItemAttnLayer: query {}, key {}'.format(query, key))

    dim = int(inputs.get_shape().as_list()[-1])
    # score = K.batch_dot(query, key, axes=[-1, -1])
    score = tf.keras.backend.batch_dot(
        query, tf.keras.backend.permute_dimensions(key, [0, 2, 1]))
    score = tf.keras.layers.Lambda(lambda x: tf.multiply(
        x, 1. / tf.sqrt(tf.cast(dim, tf.float32))))(score)
    score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x))(score)
    # score: (batch, len, len)
    tf.logging.info('score {}'.format(score))

    attn_score = tf.keras.backend.batch_dot(score, inputs, axes=[1, 1])
    # attn_score: (batch, len, dim)
    attn_score = tf.keras.layers.Lambda(lambda x: tf.reduce_mean(x, axis=1))(
        attn_score)
    tf.logging.info('NextItemAttnLayer: query {}, key {}'.format(query, key))
    # attn_score: (batch, dim)
    return attn_score

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(NextItemAttnLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SENETLayer(tf.keras.layers.Layer):
  """
    Model: Squeeze and Excitation Layer

    Paper: FiBiNET- Combining Feature Importance and Bilinear feature Interaction for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1905.09433

    Author: Tongwen Huang, Zhiqi Zhang, Junlin Zhang

    Developer: anbo

    Date: 2020-04-28

    inputs: (batch, fields, dim)

    output: (batch, fields, dim)
    """
  def __init__(self,
               reduction_ratio,
               act_fn='relu',
               l2_reg=0.0001,
               seed=23,
               **kwargs):
    super(SENETLayer, self).__init__(**kwargs)
    self.reduction_ratio = reduction_ratio
    self.act_fn = act_fn
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    fields = int(input_shape[1])
    hidden_size = max(1, fields // self.reduction_ratio)

    self.w1 = self.add_weight(
        shape=(fields, hidden_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        name="W_1")
    self.w2 = self.add_weight(
        shape=(hidden_size, fields),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        name="W_2")

    super(SENETLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
          inputs: (batch, fields, dim)
        returns:
            (batch, fields, dim)
        """
    #z = K.sum(inputs, axis=-1, keepdims=False)
    z = tf.keras.layers.Lambda(
        lambda x: tf.reduce_mean(x, axis=-1, keepdims=False))(inputs)
    # Z: (batch, fields)
    tf.logging.info('SENETLayer: z shape {}'.format(z))

    # squeeze and excitation part
    A = tf.keras.backend.dot(z, self.w1)
    A = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(A)
    # A: (batch, hidden_size)
    A = tf.keras.backend.dot(A, self.w2)
    A = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(A)
    #A = tf.keras.layers.Lambda(lambda x: tf.nn.sigmoid(x))(A)
    # A : (batch, fields)
    # A (batch, fields)
    tf.logging.info('SENETLayer: A {}'.format(A))
    A = tf.keras.backend.expand_dims(A, axis=-1)
    # A (batch, fields, 1)
    V = tf.keras.layers.Multiply()([inputs, A])
    tf.logging.info('SENETLayer: V {}'.format(V))
    # V (batch, fields, dim)
    return V

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {
        'reduction_ratio': self.reduction_ratio,
        'act_fn': self.act_fn,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(SENETLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class CaserLayer(tf.keras.layers.Layer):
  """
    Model: Caser Layer

    Paper: Personalized Top-N Sequential Recommendation via Convolutional Sequence Embedding

    Link: https://arxiv.org/abs/1809.07426

    Author: Jiaxi Tang, Ke Wang

    Developer: anbo

    Date: 2019-12-19

    Note: horizontal filters: h*d
          vertical filters: len*1

    Input shape
        - 3D tensor with shape: ``(batch_size,field_size,embedding_size)``.

    Output shape
        - 2D tensor with shape: ``(batch_size, dim)``.
    """
  def __init__(self,
               h_filters=[4, 6, 8],
               h_kernel=[2, 4, 5],
               v_filters=[1, 2, 4],
               seed=1024,
               **kwargs):
    super(CaserLayer, self).__init__(**kwargs)
    self.h_filters = h_filters
    self.h_kernel = h_kernel
    self.v_filters = v_filters
    self.seed = seed

  def build(self, input_shape):
    seq_len, dim = int(input_shape[1]), int(input_shape[2])
    self.total_filters = sum(self.h_filters) + sum(self.v_filters) * dim
    self.h_conv_kernels = []
    self.h_max_pools = []
    self.v_conv_kernels = []
    tf.logging.info('CaserLayer: total_filters {}'.format(self.total_filters))

    for i in range(len(self.h_filters)):
      self.h_conv_kernels.append(
          tf.keras.layers.Conv2D(
              filters=self.h_filters[i],
              kernel_size=(self.h_kernel[i], dim),
              strides=[1, 1],
              padding='valid',
              data_format='channels_last',
              activation='tanh',
              use_bias=True,
              kernel_initializer=tf.keras.initializers.he_normal(
                  seed=self.seed),
              name='hconv2d_layer_{}'.format(i)))
      row = (seq_len - self.h_kernel[i]) + 1
      self.h_max_pools.append(
          tf.keras.layers.MaxPool2D(pool_size=(row, 1),
                                    strides=[1, 1],
                                    padding='valid',
                                    data_format='channels_last',
                                    name='maxpool2d_layer_{}'.format(i)))

    for i in range(len(self.v_filters)):
      self.v_conv_kernels.append(
          tf.keras.layers.Conv2D(
              filters=self.v_filters[i],
              kernel_size=(seq_len, 1),
              strides=[1, 1],
              padding='valid',
              data_format='channels_last',
              activation='tanh',
              use_bias=True,
              kernel_initializer=tf.keras.initializers.he_normal(
                  seed=self.seed),
              name='vconv2d_layer_{}'.format(i)))

    super(CaserLayer, self).build(input_shape)

  def __squeeze_axis(self, inputs):
    inputs = tf.keras.layers.Lambda(
        lambda x: tf.keras.backend.squeeze(x, axis=1))(inputs)
    inputs = tf.keras.layers.Lambda(
        lambda x: tf.keras.backend.squeeze(x, axis=1))(inputs)
    tf.logging.info('CaserLayer: inputs squeezed {}'.format(inputs))
    return inputs

  def call(self, inputs, **kwargs):
    """
        :params, input_a: (batch, a_len, dim)
        returns: (batch, output_dim)
        """
    inputs_4d = tf.keras.layers.Lambda(
        lambda x: tf.keras.backend.expand_dims(x, axis=3))(inputs)
    tf.logging.info('CaserLayer: inputs_4d {}'.format(inputs_4d))

    h_outputs, v_outputs = [], []
    for i in range(len(self.h_filters)):
      h_conv_output = self.h_conv_kernels[i](inputs_4d)
      # h_conv_output: (batch, row, 1, h_filters[i])
      tf.logging.info('CaserLayer: h_conv_output {} {}'.format(
          i, h_conv_output))
      h_conv_output = self.h_max_pools[i](h_conv_output)
      tf.logging.info('CaserLayer: h_conv_output max_pooled {} {}'.format(
          i, h_conv_output))
      h_outputs.append(self.__squeeze_axis(h_conv_output))

    for i in range(len(self.v_filters)):
      v_conv_output = self.v_conv_kernels[i](inputs_4d)
      # v_conv_output: : (batch, 1, 1, v_filters[i])
      tf.logging.info('CaserLayer: v_conv_output {} {}'.format(
          i, v_conv_output))
      v_conv_output = tf.keras.layers.Lambda(
          lambda x: tf.keras.backend.squeeze(x, axis=1))(v_conv_output)
      tf.logging.info('CaserLayer: v_conv_output squeezed {} {}'.format(
          i, v_conv_output))
      v_outputs.append(tf.keras.layers.Flatten()(v_conv_output))

    output = tf.keras.layers.Concatenate(axis=-1)(h_outputs + v_outputs)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.total_filters)

  def get_config(self):
    config = {
        'h_filters': self.h_filters,
        'h_kernel': self.h_kernel,
        'v_filters': self.v_filters,
        'seed': self.seed
    }
    base_config = super(CaserLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class DSTNLayer(tf.keras.layers.Layer):
  """
  Model: Deep Spatio-Temporal Neural (DSTN)

  Paper: Deep Spatio-Temporal Neural Networks for Click-Through Rate Prediction

  Link: https://arxiv.org/abs/1906.03776

  Author: Wentao Ouyang, Xiuwu Zhang, Li Li, Heng Zou, Xin Xing, Zhaojie Liu, Yanlong Du

  Developer: anbo

  Date: 2019-12-31

  Input shape: 3d tensor, (batch, len, dim)

  Output shape: 2d tensor, (batch, hidden_units[-1])

  """
  def __init__(self,
               input_dim,
               hidden_units=[32],
               l2_reg=0.001,
               act_fn='relu',
               seed=1024,
               **kwargs):
    """
      params:
      hidden_units: list of positive integer, the layer number and units in each layer.
      l2_reg: float, between 0 and 1. L2 regularizer strength applied to the kernel weights matrix.
      act_fn: string, Activation function to use.
      """
    super(DSTNLayer, self).__init__(**kwargs)
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.act_fn = act_fn
    self.input_dim = input_dim
    self.seed = seed

  def build(self, input_shape):
    hidden_size = [self.input_dim] + list(self.hidden_units) + [1]
    self.kernels, self.bias = [], []
    for i in range(len(hidden_size) - 1):
      self.kernels.append(
          self.add_weight(
              name="kernel_{}".format(i),
              shape=(hidden_size[i], hidden_size[i + 1]),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(hidden_size[i + 1],),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))

    super(DSTNLayer, self).build(input_shape)

  def call(self, inputs, extra_inputs=None, **kwargs):
    """
      Args:
          input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
      """
    attn_score = inputs if extra_inputs is None else tf.concat(
        [inputs, extra_inputs], axis=-1)
    tf.logging.info(
        "DSTNLayer: concat inputs attn_score {}".format(attn_score))
    for i in range(len(self.kernels)):
      attn_score = tf.nn.bias_add(
          tf.tensordot(attn_score, self.kernels[i], axes=[-1, 0]),
          self.bias[i])
      # attn_score: (batch, len, hidden_unit)
      tf.logging.info("DSTNLayer: layer {}, attn_score {}".format(
          i, attn_score))
      if i < len(self.kernels) - 1:
        attn_score = tf.nn.relu(attn_score)
      else:
        attn_score = tf.nn.softmax(attn_score)

    scaled_inputs = tf.matmul(inputs, attn_score, transpose_a=True)
    # scaled_inputs: (batch, dim, 1)
    scaled_inputs = tf.squeeze(scaled_inputs, axis=-1)
    return scaled_inputs

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'act_fn': self.act_fn,
        'input_dim': self.input_dim,
        'seed': self.seed
    }
    base_config = super(DSTNLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class GeneralMultiHeadAttnLayer(tf.keras.layers.Layer):
  """
    Model: GeneralMultiHeadAttnLayer

    Paper: Attention Is All You Need

    Link: https://arxiv.org/abs/1706.03762

    Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

    Developer: anbo

    Date: 2019-11-30

    This is the multi-head self attention module in bert/transformer, depending on self attention layer

    inputs: 3d tensor, (batch_size, fields, hidden_size)

    outputs: 3d tensor, (batch_size, fields, hidden_size)
    """
  def __init__(self,
               hidden_units,
               heads,
               l2_reg=0.001,
               dropout_rate=0.1,
               seed=1024,
               list_tag=False,
               mha_type='origin',
               dim_e=None,
               synthesizer_type='dense',
               inf=1e9,
               window=1,
               concat_heads=True,
               **kwargs):
    super(GeneralMultiHeadAttnLayer, self).__init__(**kwargs)
    assert (hidden_units %
            heads == 0), ('hidden_size must be dividable by heads')
    self.d_k = hidden_units // heads
    self.heads = heads
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.dropout_rate = dropout_rate
    self.seed = seed
    self.list_tag = list_tag

    self.dim_e = dim_e
    self.inf = inf
    self.synthesizer_type = synthesizer_type
    self.mha_type = mha_type
    self.concat_heads = concat_heads
    self.window = window

  def build(self, input_shape):
    from alps_biz.core.layer.sequence import SelfAttentionLayer

    if self.list_tag:
      dim = [int(unit[-1]) for unit in input_shape]
      # self.seq_len = int(input_shape[-1][1])
      self.seq_len = [
          int(input_shape[0][1]),
          int(input_shape[1][1]),
          int(input_shape[2][1])
      ]
      self.query_len = int(input_shape[0][1])
    else:
      dim = [int(input_shape[-1])] * 3
      self.seq_len = int(input_shape[1])
      self.query_len = self.seq_len

    dim += [self.hidden_units]

    self.kernels = []
    self.bias = []
    for i in range(3):
      self.kernels.append(
          self.add_weight(
              name="kernel_{}".format(i),
              shape=(dim[i], self.hidden_units),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(self.hidden_units,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    if self.concat_heads:
      self.kernels.append(
          self.add_weight(
              name="kernel_4",
              shape=(self.hidden_units, self.hidden_units),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_4',
                          shape=(self.hidden_units,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    # self.attnlayer = SelfAttentionLayer(self.dropout_rate, name='general_mha_selfattn_layer')

    if self.mha_type == 'origin':
      self.attnlayer = SelfAttentionLayer(self.dropout_rate,
                                          name='general_mha_selfattn_layer')
    else:
      from alps_biz.core.layer.attention import GeneralSelfAttnLayer
      self.attnlayer = GeneralSelfAttnLayer(
          mha_type=self.mha_type,
          dim_e=self.dim_e,
          synthesizer_type=self.synthesizer_type,
          l2_reg=self.l2_reg,
          dropout_rate=self.dropout_rate,
          seed=self.seed,
          inf=self.inf,
          window=self.window,
          name='general_mha_selfattn_layer')

    super(GeneralMultiHeadAttnLayer, self).build(input_shape)

  def call(self, inputs, mask=None, training=None, **kwargs):
    """
        Args:
            inputs: (batch, seq_len, dim)

        return: (batch, seq_len, dim)
        """
    tf.logging.info('GeneralMultiHeadAttnLayer: inputs {}'.format(inputs))

    # To Do: deal with different input sequence length
    if self.list_tag:
      if tf.keras.backend.ndim(inputs[0]) == 2:
        inputs[0] = tf.keras.layers.Lambda(
            lambda x: tf.expand_dims(x, axis=1))(inputs[0])

      query, key, value = [
          tf.keras.backend.reshape(tf.keras.backend.bias_add(
              tf.keras.backend.dot(inputs[i], self.kernels[i]), self.bias[i]),
                                   shape=(-1, self.seq_len[i], self.heads,
                                          self.d_k)) for i in range(3)
      ]
    else:
      query, key, value = [
          tf.keras.backend.reshape(tf.keras.backend.bias_add(
              tf.keras.backend.dot(inputs, self.kernels[i]), self.bias[i]),
                                   shape=(-1, self.seq_len, self.heads,
                                          self.d_k)) for i in range(3)
      ]

    tf.logging.info(
        'GeneralMultiHeadAttnLayer: query {}, key {}, value {} '.format(
            query, key, value))

    # apply scaled self dot attention
    output = self.attnlayer([query, key, value], mask=mask, training=training)
    tf.logging.info(
        'GeneralMultiHeadAttnLayer: self attention output {}'.format(output))
    # ouput: (batch, query_len, heads*d_k)

    # concat and apply a final linear layer
    if self.concat_heads:
      tf.logging.info('GeneralMultiHeadAttnLayer: self.kernel_4 {}'.format(
          self.kernels[-1]))
      output = tf.keras.backend.bias_add(
          tf.keras.backend.dot(output, self.kernels[3]), self.bias[3])
      tf.logging.info('GeneralMultiHeadAttnLayer: output {}'.format(output))
      # outpu: (batch, seq_len, hidden_size), hidden_size = d_model= heads*d_k
    else:
      output = tf.reshape(output,
                          shape=(-1, self.query_len, self.d_k, self.heads))
      tf.logging.info('GeneralMultiHeadAttnLayer: output {}'.format(output))

    return output

  def compute_output_shape(self, input_shape):
    if self.list_tag:
      input_shape = tensor_shape.TensorShape(input_shape[0])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)

      if self.concat_heads:
        return input_shape[:2].concatenate(
            tensor_shape.TensorShape(self.hidden_units))
      else:
        return input_shape[:2].concatenate(
            tensor_shape.TensorShape([self.d_k, self.heads]))
    else:
      if self.concat_heads:
        return input_shape
      else:
        input_shape = tensor_shape.TensorShape(input_shape[0])
        return input_shape[:2].concatenate(
            tensor_shape.TensorShape([self.d_k, self.heads]))

  def get_config(self):
    config = {
        'heads': self.heads,
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'dropout_rate': self.dropout_rate,
        'seed': self.seed,
        'list_tag': self.list_tag,
        'inf': self.inf,
        'synthesizer_type': self.synthesizer_type,
        'dim_e': self.dim_e,
        'mha_type': self.mha_type,
        'concat_heads': self.concat_heads,
        'window': self.window
    }
    base_config = super(GeneralMultiHeadAttnLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


def positional_signal(hidden_size,
                      length,
                      min_timescale=1.0,
                      max_timescale=1e4):
  """
    Helper function, constructing basic positional encoding.
    The code is partially based on implementation from Tensor2Tensor library
    https://github.com/tensorflow/tensor2tensor/blob/master/tensor2tensor/layers/common_attention.py
    """

  import numpy as np

  if hidden_size % 2 != 0:
    raise ValueError(
        "The hidden dimension of the model must be divisible by 2. Currently it is {hidden_size}"
    )
  position = tf.keras.backend.arange(0,
                                     length,
                                     dtype=tf.keras.backend.floatx())
  num_timescales = int(hidden_size // 2)
  log_timescale_increment = tf.keras.backend.constant(
      (np.log(float(max_timescale) / float(min_timescale)) /
       (num_timescales - 1)),
      dtype=tf.keras.backend.floatx())
  inv_timescales = (min_timescale * tf.keras.backend.exp(
      tf.keras.backend.arange(num_timescales, dtype=tf.keras.backend.floatx())
      * -log_timescale_increment))
  scaled_time = tf.keras.backend.expand_dims(
      position, 1) * tf.keras.backend.expand_dims(inv_timescales, 0)
  signal = tf.keras.backend.concatenate(
      [tf.keras.backend.sin(scaled_time),
       tf.keras.backend.cos(scaled_time)],
      axis=1)
  return tf.keras.backend.expand_dims(signal, axis=0)


def learnabel_position_encoding(hidden_size, length, seed=1024):
  import numpy as np

  position_index = np.arange(length)[np.newaxis, :]
  position_tensor = tf.convert_to_tensor(position_index, dtype=tf.int32)
  tf.logging.info('position_index {}'.format(position_index))

  embedding_table = tf.keras.layers.Embedding(
      input_dim=length,
      output_dim=hidden_size,
      embeddings_initializer=tf.keras.initializers.TruncatedNormal(mean=0.0,
                                                                   stddev=0.05,
                                                                   seed=seed))
  position_embedding = embedding_table(position_tensor)
  tf.logging.info('learnabel_position_encoding: position_embedding {}'.format(
      position_embedding))
  return position_embedding


class PositionalEncodingLayer(tf.keras.layers.Layer):
  """
    Model: Positional Encoding Layer

    Paper: Attention Is All You Need

    Link: https://arxiv.org/abs/1706.03762

    Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

    Developer: anbo

    Date: 2019-11-30

    This is the multi-head self attention module in bert/transformer, depending on self attenton layer

    inputs: 3d tensor, (batch_size, fields, hidden_units)

    outputs: 3d tensor, (batch_size, fields, hidden_units)
    """
  def __init__(self,
               min_timescale=1.0,
               max_timescale=1.0e4,
               pos_type='fixed',
               seed=1024,
               add_pos=True,
               hidden_size=None,
               **kwargs):
    self.min_timescale = min_timescale
    self.max_timescale = max_timescale
    self.seed = seed
    self.pos_type = pos_type
    self.add_pos = add_pos
    self.hidden_size = hidden_size
    super(PositionalEncodingLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    tf.logging.info(
        'PositionalEncodingLayer: build input_shape {}'.format(input_shape))
    _, length, hidden_size = input_shape

    self.hidden_size = hidden_size if self.hidden_size is None else self.hidden_size

    if self.pos_type == 'fixed':
      self.signal = positional_signal(self.hidden_size, length,
                                      self.min_timescale, self.max_timescale)
    elif self.pos_type == 'learnable':
      self.signal = learnabel_position_encoding(int(self.hidden_size),
                                                int(length), self.seed)

    return super(PositionalEncodingLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    if self.add_pos:
      return inputs + self.signal
    else:
      tf.logging.info('pos embeeding only')
      return self.signal

  def compute_output_shape(self, input_shape):
    if not self.add_pos:
      return (1, input_shape[1], input_shape[2])
    else:
      return input_shape

  def get_config(self):
    config = {
        'min_timescale': self.min_timescale,
        'max_timescale': self.max_timescale,
        'pos_type': self.pos_type,
        'seed': self.seed,
        'add_pos': self.add_pos,
        'hidden_size': self.hidden_size
    }
    base_config = super(PositionalEncodingLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class WeightedAttentionLayer(tf.keras.layers.Layer):
  """
    Model: weighted attention

    Developer: anbo

    Date: 2020-05-06

    attn = softmax(a * w)
    attn = a . attn

    inputs: (batch, seq_len, dim)

    return: (batch, dim)
    """
  def __init__(self, l2_reg=0.001, seed=11, **kwargs):
    super(WeightedAttentionLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    hidden_size = int(input_shape[-1])
    self.weight = self.add_weight(
        name='weight',
        shape=(hidden_size, 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(WeightedAttentionLayer, self).build(input_shape)

  def call(self, inputs, mask=None, **kwargs):
    """
        Args:
            inputs: (batch, seq_len, dim)
        returns: (batch, dim)
        """
    attn = tf.keras.backend.dot(inputs, self.weight)
    # attn: (batch, seq_len, 1)
    tf.logging.info('WeightedAttentionLayer: attn {}'.format(attn))

    if mask is not None:
      tf.logging.info('WeightedAttentionLayer: mask {}'.format(mask))
      attn = tf.keras.layers.Add()([attn, -1e9 * mask])
      tf.logging.info('WeightedAttentionLayer: masked attn {}'.format(attn))

    attn = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, 1))(attn)
    self.attn_distribution = attn

    output = tf.keras.backend.batch_dot(inputs, attn, axes=[1, 1])
    # output (batch, dim, 1)
    output = tf.keras.backend.squeeze(output, axis=-1)
    tf.logging.info('WeightedAttentionLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(WeightedAttentionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SelfRNNAttentionLayer(tf.keras.layers.Layer):
  """
    Model: Self RNN based attention layer

    Developer: anbo

    Date: 2020-05-06

    inputs: (batch, seq_len, dim)

    return: (batch, dim)

    """
  def __init__(self, s1_unit=32, s2_unit=8, l2_reg=0.001, seed=1024, **kwargs):
    super(SelfRNNAttentionLayer, self).__init__(**kwargs)
    self.s1_unit = s1_unit
    self.s2_unit = s2_unit
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape, **kwargs):
    dim = int(input_shape[-1])
    self.output_dim = dim * self.s2_unit

    self.kernel_s1 = self.add_weight(
        name='kernel_s1',
        shape=(dim, self.s1_unit),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.bias_s1 = self.add_weight(name='bias_s1',
                                   shape=(self.s1_unit,),
                                   initializer=tf.keras.initializers.Zeros(),
                                   regularizer=tf.keras.regularizers.L1L2(
                                       0, self.l2_reg),
                                   trainable=True)

    self.kernel_s2 = self.add_weight(
        name='kernel_s2',
        shape=(self.s1_unit, self.s2_unit),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.bias_s2 = self.add_weight(name='bias_s2',
                                   shape=(self.s2_unit,),
                                   initializer=tf.keras.initializers.Zeros(),
                                   regularizer=tf.keras.regularizers.L1L2(
                                       0, self.l2_reg),
                                   trainable=True)

    super(SelfRNNAttentionLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
          inputs: (batch, len, dim)
        return: (batch, dim_2)
        """
    score = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernel_s1), self.bias_s1)
    # score: (batch, len, s1_unit)
    score = tf.keras.layers.Lambda(lambda x: tf.nn.tanh(x))(score)
    score = tf.keras.backend.bias_add(
        tf.keras.backend.dot(score, self.kernel_s2), self.bias_s2)
    # score: (batch, len, s2_unit)
    score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, axis=-1))(score)
    #print('score ', score)
    tf.logging.info('SelfRNNAttentionLayer: score {}'.format(score))

    output = tf.keras.backend.batch_dot(inputs, score, axes=[1, 1])
    # output: (batch, dim, s2_unit)
    tf.logging.info('SelfRNNAttentionLayer: output {}'.format(output))
    output = tf.keras.backend.reshape(output, shape=[-1, self.output_dim])
    # output: (batch, output_dim)
    tf.logging.info('SelfRNNAttentionLayer: output reshape {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.output_dim)

  def get_config(self):
    config = {
        's1_unit': self.s1_unit,
        's2_unit': self.s2_unit,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(SelfRNNAttentionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class AttentionOverAttentionLayer(tf.keras.layers.Layer):
  """
    Model: attention over attention layer

    Paper: Attention-over-Attention Neural Networks for Reading Comprehension

    Link: https://arxiv.org/abs/1607.04423

    Author: Yiming Cui, Zhipeng Chen, Si Wei, Shijin Wang, Ting Liu, Guoping Hu

    Developer: anbo

    Date: 2020-05-06

    This is the attention over attention layer.
    inputs: list with length of 2, [input_a, input_b]
        input_a: (batch, a_len, dim)
        input_b: (batch, b_len, dim)

    return: (batch, dim)
    """
  def __init__(self, **kwargs):
    super(AttentionOverAttentionLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    super(AttentionOverAttentionLayer, self).build(input_shape)

  def call(self, inputs):
    """
        Args:
            inputs: list of 2 tensors, [doc, query],
                    doc: (batch, doc_len, dim)
                    query: (batch, query_len, dim) or (batch, dim)
        return:
            (batch, dim)
        """
    doc, query = inputs

    if tf.keras.backend.ndim(query) == 2:
      query = tf.keras.backend.expand_dims(query, axis=1)
      tf.logging.info(
          'AttentionOverAttentionLayer: query expand_dims {}'.format(query))

    # doc_len = K.input_shape(doc)[1]
    # query_len = K.input_shape(query)[1]
    # dim = K.int_shape(doc)[2]
    tf.logging.info(
        'AttentionOverAttentionLayer doc shape {}, query shape {}'.format(
            doc, query))

    # get score weight matrix scores
    scores = tf.keras.backend.batch_dot(doc, query, axes=[2, 2])
    # scores (batch, doc_len, query_len)
    tf.logging.info(
        'AttentionOverAttentionLayer scores shape {}'.format(scores))
    alpha = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, 1))(scores)
    beta = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, -1))(scores)
    beta_avg = tf.keras.backend.mean(beta, axis=1,
                                     keepdims=True)  # (batch, 1, query_len)
    gamma = tf.keras.backend.batch_dot(beta_avg, alpha,
                                       axes=[2, 2])  # # (batch, 1, doc_len)
    tf.logging.info('AttentionOverAttentionLayer gamma shape {}'.format(gamma))

    weight_doc = tf.keras.backend.batch_dot(doc, gamma,
                                            axes=[1, 2])  # (batch, dim, 1)
    weight_doc = tf.keras.backend.squeeze(weight_doc, axis=-1)  # (batch, dim)
    return weight_doc

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])


class InterestActLayer(tf.keras.layers.Layer):
  """
    Model: Interest Activation layer

    Paper: Deep Session Interest Network for Click through rate prediction

    Link: https://arxiv.org/abs/1905.06482

    Author: Yufei Feng, Fuyu Lv, Weichen Shen, Menghan Wang, Fei Sun, Yu Zhu, Keping Yang

    Developer: anbo

    Date: 2020-05-06

    inputs: list of 3d tensors, (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, b_len, dim) or (batch, dim)

    returns: (batch, a_len)

    """
  def __init__(self, l2_reg=0.001, seed=1024, **kwargs):
    super(InterestActLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    dim_1 = int(input_shape[0][-1])
    dim_2 = int(input_shape[1][-1])

    self.weight = self.add_weight(
        name='weight',
        shape=(dim_1, dim_2),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(InterestActLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: list of 3d tensors, (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, b_len, dim) or (batch, dim)
        returns: (batch, a_len)
        """
    input_a, input_b = inputs

    if tf.keras.backend.ndim(input_b) == 2:
      input_b = tf.keras.backend.expand_dims(input_b, axis=1)
      tf.logging.info('InterestActLayer: input_b {}'.format(input_b))

    attn = tf.keras.backend.dot(input_a, self.weight)
    # attn: (batch, len, dim_2)
    tf.logging.info('InterestActLayer: attn {}'.format(attn))
    attn = tf.keras.backend.batch_dot(attn, input_b, axes=[2, 2])
    tf.logging.info('InterestActLayer: attn {}'.format(attn))
    # attn: (batch, a_len, 1)
    attn = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, 1))(attn)
    attn = tf.keras.backend.batch_dot(attn, input_a, axes=[1, 1])
    tf.logging.info('InterestActLayer: attn {}'.format(attn))
    attn = tf.keras.backend.squeeze(attn, axis=1)
    # attn_output: (batch, dim)
    return attn

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(InterestActLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class DrAttnLayer(tf.keras.layers.Layer):
  """
    Model: Dr attention layer

    Developer: anbo

    Date: 2020-05-06

    attn = softmax(relu(w. p) . relu(w. q))

    inputs: list with length of 2, [input_a, input_b]
        input_a: (batch, a_len, dim)
        input_b: (batch, b_len, dim)

    outputs: (batch, a_len, b_len)
    """
  def __init__(self,
               l2_reg=0.001,
               return_scaled_a=False,
               return_scaled_b=False,
               seed=1024,
               **kwargs):
    super(DrAttnLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.return_scaled_a = return_scaled_a
    self.return_scaled_b = return_scaled_b
    self.seed = seed

  def build(self, input_shape):
    hidden_size = int(input_shape[0][-1])
    self.input_b_len = 1 if len(input_shape[1]) < 3 else input_shape[1][1]
    self.weight = self.add_weight(
        name='weight',
        shape=(hidden_size, hidden_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    super(DrAttnLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, b_len, dim) or (batch, dim)
        returns: (batch, a_len, b_len)
        """
    input_a, input_b = inputs

    if tf.keras.backend.ndim(input_b) == 2:
      input_b = tf.keras.backend.expand_dims(input_b, axis=1)
      tf.logging.info('DrAttnLayer: input_b expand {}'.format(input_b))

    attn_a = tf.keras.backend.relu(tf.keras.backend.dot(input_a, self.weight))
    # attn_a (batch, a_len, dim)
    tf.logging.info('DrAttnLayer: attn_a {}'.format(attn_a))
    attn_b = tf.keras.backend.relu(tf.keras.backend.dot(input_b, self.weight))
    # attn_b (batch, b_len, dim)
    tf.logging.info('DrAttnLayer: attn_b {}'.format(attn_b))

    attn = tf.keras.backend.batch_dot(attn_a, attn_b, axes=[2, 2])
    # attn (batch, a_len, b_len)
    tf.logging.info('DrAttnLayer: attn {}'.format(attn))

    if self.return_scaled_a:
      scaled_input_a = tf.keras.backend.batch_dot(attn, input_b)
      # (batch, a_len, dim)
      return scaled_input_a

    if self.return_scaled_b:
      scaled_input_b = tf.keras.backend.batch_dot(attn, input_a, axes=[1, 1])
      # (batch, b_len, dim)
      return scaled_input_b

    return attn

  def compute_output_shape(self, input_shape):
    if self.return_scaled_a:
      input_shape = tensor_shape.TensorShape(input_shape[0])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      return input_shape
    elif self.return_scaled_b:
      input_shape = tensor_shape.TensorShape(input_shape[1])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      output_shape_1 = input_shape[:1].concatenate(self.input_b_len)
      return output_shape_1.concatenate(input_shape[-1])
    else:
      input_shape = tensor_shape.TensorShape(input_shape[0])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      return input_shape[:-1].concatenate(self.input_b_len)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'return_scaled_a': self.return_scaled_a,
        'return_scaled_b': self.return_scaled_b,
        'seed': self.seed
    }
    base_config = super(DrAttnLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SelfAlignLayer(tf.keras.layers.Layer):
  """
    Model: Self align attention layer

    Developer: anbo

    Date: 2020-05-06

    This is the self align attention layer
    attn = softmax(a . w. a)
    weight = attn . a

    inputs: (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, b_len, dim)

        returns: (batch, a_len, b_len)
    """
  def __init__(self,
               l2_reg=0.001,
               return_scaled_a=False,
               return_scaled_b=False,
               seed=1024,
               **kwargs):
    super(SelfAlignLayer, self).__init__()
    self.l2_reg = l2_reg
    self.return_scaled_a = return_scaled_a
    self.return_scaled_b = return_scaled_b
    self.seed = seed

  def build(self, input_shape):
    hidden_size = int(input_shape[0][-1])
    self.input_b_len = 1 if len(input_shape[1]) < 3 else input_shape[1][1]

    self.weight = self.add_weight(
        name='weight',
        shape=(hidden_size, 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    super(SelfAlignLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (input_a, input_b)
                input_a: (batch, a_len, dim)
                input_b: (batch, b_len, dim) or (batch, dim)

        returns: (batch, a_len, b_len)
        """
    input_a, input_b = inputs

    if tf.keras.backend.ndim(input_b) == 2:
      input_b = tf.keras.backend.expand_dims(input_b, axis=1)
      tf.logging.info('SelfAlignLayer: input_b expand {}'.format(input_b))

    dim = tf.keras.backend.int_shape(input_a)[-1]
    rank_a = len(tf.keras.backend.int_shape(input_a)) - 1
    geo_a = [1 for _ in range(rank_a)]

    attn = tf.keras.backend.dot(input_a, self.weight)
    # attn (*, 1)
    tf.logging.info('SelfAlignLayer attn {}'.format(attn))
    attn_a_exp = tf.keras.layers.Lambda(lambda x: tf.tile(x, geo_a + [dim]))(
        attn)
    tf.logging.info('SelfAlignLayer attn_a_exp {}'.format(attn_a_exp))

    input_b_tra = tf.keras.layers.Lambda(
        lambda x: tf.transpose(x, perm=[0, 2, 1]))(input_b)
    tf.logging.info('SelfAlignLayer input_b_tra {}'.format(input_b_tra))
    attn = tf.keras.backend.batch_dot(attn_a_exp, input_b_tra)
    # attn (batch, a_len, b_len)
    tf.logging.info('SelfAlignLayer attn {}'.format(attn))

    if self.return_scaled_a:
      scaled_input_a = tf.keras.backend.batch_dot(attn, input_b)
      # (batch, a_len, dim)
      return scaled_input_a

    if self.return_scaled_b:
      scaled_input_b = tf.keras.backend.batch_dot(attn, input_a, axes=[1, 1])
      # (batch, b_len, dim)
      return scaled_input_b

    return attn

  def compute_output_shape(self, input_shape):
    if self.return_scaled_a:
      input_shape = tensor_shape.TensorShape(input_shape[0])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      return input_shape
    elif self.return_scaled_b:
      input_shape = tensor_shape.TensorShape(input_shape[1])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      output_shape_1 = input_shape[:1].concatenate(self.input_b_len)
      return output_shape_1.concatenate(input_shape[-1])
    else:
      input_shape = tensor_shape.TensorShape(input_shape[0])
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      return input_shape[:-1].concatenate(self.input_b_len)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'return_scaled_a': self.return_scaled_a,
        'return_scaled_b': self.return_scaled_b,
        'seed': self.seed
    }
    base_config = super(SelfAlignLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class BahdanauAttnLayer(tf.keras.layers.Layer):
  """
    Model:  Bahdanau attention

    Paper: NEURAL MACHINE TRANSLATION BY JOINTLY LEARNING TO ALIGN AND TRANSLATE

    Link: https://arxiv.org/pdf/1409.0473.pdf

    Author: Dzmitry Bahdanau,KyungHyun Cho Yoshua Bengio

    Developer: anbo

    Date: 2020-05-06

    Bahdanau attention layer, computes attention between lstm_output and final_hidden_state

    inputs: list of 2 tensors, [sequences_inputs, hidden_state]
          sequences_inputs: (batch, len, dim), hidden_states of all time_steps
          hidden_state: (batch, dim)

    returns: (batch, dim)

    """
  def __init__(self, **kwargs):
    super(BahdanauAttnLayer, self).__init__(**kwargs)

  def build(self, input_shape, **kwargs):
    super(BahdanauAttnLayer, self).build(input_shape)

  def call(self, inputs, mask=None, **kwargs):
    """
        Args:
         inputs: list of 2 tensors, [sequences_inputs, hidden_state]
          sequences_inputs: (batch, len, dim), hidden_states of all time_steps
          hidden_state: (batch, dim)
        returns: (batch, dim)
        """
    sequence_input, hidden_state = inputs
    hidden_state_3d = tf.keras.backend.expand_dims(hidden_state, axis=-1)
    # hidden_state_3d: (batch, dim, 1)
    score = tf.keras.backend.batch_dot(sequence_input, hidden_state_3d)
    # score: (batch, len, 1)

    if mask is not None:
      tf.logging.info('BahdanauAttnLayer: mask {}'.format(mask))
      score = tf.keras.layers.Add()([score, -1e9 * mask])
      tf.logging.info('BahdanauAttnLayer: masked score {}'.format(score))

    score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x))(score)
    output = tf.keras.backend.batch_dot(
        tf.keras.backend.permute_dimensions(sequence_input, [0, 2, 1]), score)
    # output: (batch, dim, 1)
    output = tf.keras.backend.squeeze(output, axis=-1)
    # output: (batch, dim)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[-1])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape


class FieldWiseBiInterationLayer(tf.keras.layers.Layer):
  """
    Model: FLEN Layer

    Paper: FLEN: Leveraging Field for Scalable CTR Prediction

    Link: https://arxiv.org/pdf/1911.04690.pdf

    Author: Wenqiang Chen, Lizhang Zhan, Yuanlong Ci,Chen Lin

    Developer: anbo

    Date: 2020-05-06

    inputs: list of 3d tensors

    output: 2d tensor

    """
  def __init__(self, l2_reg=0.0001, use_bias=True, seed=1024, **kwargs):
    super(FieldWiseBiInterationLayer, self).__init__(**kwargs)
    self.use_bias = use_bias
    self.seed = seed
    self.l2_reg = l2_reg

  def build(self, input_shape):
    """
        Args:
          input_shape: list of 3d tensors
        """
    if not isinstance(input_shape, list) or len(input_shape) < 2:
      raise ValueError('FLEN must accept list of 3d tensors, with length > 2')

    self.n_fields = len(input_shape)
    emb_unit = int(input_shape[0][-1])

    self.kernel_mf = self.add_weight(
        name='kernel_mf',
        shape=(int(self.n_fields * (self.n_fields - 1) / 2), 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.kernel_fm = self.add_weight(
        name='kernel_fm',
        shape=(self.n_fields, 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    if self.use_bias:
      self.bias_mf = self.add_weight(name='bias_mf',
                                     shape=(emb_unit,),
                                     initializer=tf.keras.initializers.Zeros(),
                                     trainable=True)
      self.bias_fm = self.add_weight(name='bias_fm',
                                     shape=(emb_unit,),
                                     initializer=tf.keras.initializers.Zeros(),
                                     trainable=True)

    super(FieldWiseBiInterationLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of 3d tensors
        :return: 2d tensor
        """
    import itertools

    if tf.keras.backend.ndim(inputs[0]) != 3:
      raise ValueError('FLEN must accept list of 3d tensors, with length > 2')

    field_wise_emb_list = inputs

    # MF part
    field_wise_vectors = tf.concat([
        tf.reduce_sum(vector_i, axis=1, keepdims=True)
        for vector_i in field_wise_emb_list
    ],
                                   axis=1)
    # field_wise_vectors: (batch, n_fields, dim)
    tf.logging.info('FieldWiseBiInterationLayer: field_wise_vectors {}'.format(
        field_wise_vectors))

    left, right = [], []
    for i, j in itertools.combinations(list(range(self.n_fields)), 2):
      left.append(i)
      right.append(j)
    tf.logging.info('left {},\n, right {}'.format(left, right))

    emb_left = tf.gather(params=field_wise_vectors, indices=left, axis=1)
    tf.logging.info('FieldWiseBiInterationLayer: emb_left {}'.format(emb_left))
    emb_right = tf.gather(params=field_wise_vectors, indices=right, axis=1)
    tf.logging.info(
        'FieldWiseBiInterationLayer: emb_right {}'.format(emb_right))

    emb_prob = tf.multiply(emb_left, emb_right)
    tf.logging.info('FieldWiseBiInterationLayer: emb_prob {}'.format(emb_prob))
    emb_mf = tf.tensordot(emb_prob, self.kernel_mf, axes=[1, 0])
    emb_mf = tf.squeeze(emb_mf, axis=-1)
    tf.logging.info('FieldWiseBiInterationLayer: emb_mf {}'.format(emb_mf))
    if self.use_bias:
      emb_mf = tf.nn.bias_add(emb_mf, self.bias_mf)

    # FM part
    squared_sum = [
        tf.square(tf.reduce_sum(vector_i, axis=1, keepdims=True))
        for vector_i in field_wise_emb_list
    ]
    sum_squared = [
        tf.reduce_sum(vector_i * vector_i, axis=1, keepdims=True)
        for vector_i in field_wise_emb_list
    ]
    tf.logging.info(
        'FieldWiseBiInterationLayer: squared_sum {}\n, sum_squared {}'.format(
            squared_sum, sum_squared))

    field_emb_fm = [
        square_of_sum_i - sum_of_square_i
        for square_of_sum_i, sum_of_square_i in zip(squared_sum, sum_squared)
    ]
    tf.logging.info(
        'FieldWiseBiInterationLayer: field_emb_fm {}'.format(field_emb_fm))

    field_emb_fm = tf.concat(field_emb_fm, axis=1)
    tf.logging.info(
        'FieldWiseBiInterationLayer: field_emb_fm {}'.format(field_emb_fm))

    emb_fm = tf.tensordot(field_emb_fm, self.kernel_fm, axes=[1, 0])
    tf.logging.info('FieldWiseBiInterationLayer: emb_fm {}'.format(emb_fm))
    emb_fm = tf.squeeze(emb_fm, axis=-1)
    tf.logging.info('FieldWiseBiInterationLayer: emb_fm {}'.format(emb_fm))
    if self.use_bias:
      emb_fm = tf.nn.bias_add(emb_fm, self.bias_fm)
      tf.logging.info('FieldWiseBiInterationLayer: emb_fm {}'.format(emb_fm))

    tf.logging.info('FieldWiseBiInterationLayer: emb_mf {}, emb_fm'.format(
        emb_mf, emb_fm))
    return tf.add(emb_mf, emb_fm)

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {
        'use_bias': self.use_bias,
        'seed': self.seed,
        'l2_reg': self.l2_reg
    }
    base_config = super(FieldWiseBiInterationLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SeqCrossLayer(tf.keras.layers.Layer):
  """
    inputs: list of tensors [input_1, input_2]
            input_1: (batch, seq_len, dim_1)
            input_2: (batch, dim_2)

    output: (batch, seq_len, hidden_units)
    """
  def __init__(self,
               n_layers=2,
               l2_reg=0.001,
               remove_attention=False,
               keep_attention_value=False,
               flatten_output_seq=True,
               seed=1024,
               dropout_rate=0,
               **kwargs):
    """
        Args:
            n_layers: int, number of layers
            l2_reg: float
        """
    super(SeqCrossLayer, self).__init__(**kwargs)
    self.n_layers = n_layers
    self.l2_reg = l2_reg
    self.remove_attention = remove_attention
    self.keep_attention_value = keep_attention_value
    self.flatten_output_seq = flatten_output_seq
    self.seed = seed
    self.dropout_rate = dropout_rate
    tf.logging.info('SeqCross layer, n_layers {}, l2_reg {}'.format(
        n_layers, l2_reg))

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
        """
    input_dim1 = int(input_shape[0][-1])
    input_len = int(input_shape[0][1])
    input_dim2 = int(input_shape[1][-1])
    self.flatten_output_seq_dim = input_len * input_dim1
    self.output_list_dim = self.n_layers * input_dim1

    tf.logging.info(
        'input_dim1 {}, input_dim2 {}, flatten_output_seq_dim {}, output_list_dim {}'
        .format(input_dim1, input_dim2, self.flatten_output_seq_dim,
                self.output_list_dim))

    self.kernels, self.bias = [], []

    for i in range(self.n_layers):
      self.kernels.append(
          self.add_weight(
              name='weight_{}'.format(i),
              shape=(input_dim1, input_dim2),
              #shape=(input_dim1, 1),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(input_dim1,),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))
    super(SeqCrossLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: list of tensors [seq_inputs, inputs]
            seq_inputs: (batch, len, dim1)
            inputs: (batch, dim2)
        returns:
            2d tensor (batch_size, n_dim)
        """
    output_list = []

    seq_inputs, deep_inputs = inputs
    # seq_inputs: (batch, len, dim1)
    # deep_inputs: (batch, dim2)

    deep_inputs = tf.keras.backend.expand_dims(deep_inputs, axis=1)
    # deep_inputs (batch, 1, dim2)
    deep_seq_inputs = seq_inputs

    tf.logging.info('SeqCrossLayer: seq_inputs {}, deep_inputs {}'.format(
        seq_inputs, deep_inputs))
    for i in range(self.n_layers):
      dot_1 = tf.keras.backend.dot(deep_seq_inputs, self.kernels[i])
      # dot_1: (batch, len, input_dim2)
      tf.logging.info('SeqCrossLayer: dot_1 {}'.format(dot_1))

      attention_weight = tf.keras.backend.batch_dot(dot_1,
                                                    deep_inputs,
                                                    axes=[2, 2])
      # attention_weight: (batch, len, 1)
      tf.logging.info(
          'SeqCrossLayer: attention_weight {}'.format(attention_weight))
      tf.summary.histogram('attention_weight_layer_{}'.format(i),
                           tf.squeeze(attention_weight))

      attention_score = tf.keras.layers.Lambda(
          lambda x: tf.nn.softmax(x, axis=1))(attention_weight)
      # attention_score: (batch, len, 1)
      tf.summary.histogram('attention_score_layer_{}'.format(i),
                           tf.squeeze(attention_score))

      if self.remove_attention:
        scaled_seq_inputs = deep_seq_inputs
        tf.logging.info('SeqCrossLayer: attention removed !!')
      else:
        scaled_seq_inputs = tf.keras.layers.Lambda(
            lambda x: tf.multiply(x[0], x[1]))(
                [deep_seq_inputs, attention_score])
        # scaled_seq_inputs: (batch, len, dim1)
        reduced_seq_attention_score = tf.keras.backend.batch_dot(
            attention_score, deep_seq_inputs, axes=[1, 1])
        tf.logging.info('SeqCrossLayer: reduced_seq_attention_score {}'.format(
            reduced_seq_attention_score))
        reduced_seq_attention_score = tf.keras.backend.squeeze(
            reduced_seq_attention_score, axis=1)
        # reduced_seq_attention_score: (batch, dim1)
        output_list.append(reduced_seq_attention_score)
        tf.logging.info('SeqCrossLayer: reduced_seq_attention_score {}'.format(
            reduced_seq_attention_score))

      tf.logging.info(
          'SeqCrossLayer: scaled_seq_inputs {}'.format(scaled_seq_inputs))

      deep_seq_inputs = scaled_seq_inputs + deep_seq_inputs
      tf.logging.info(
          'SeqCrossLayer: deep_seq_inputs {}'.format(deep_seq_inputs))
      deep_seq_inputs = tf.keras.layers.Lambda(
          lambda x: tf.nn.bias_add(x[0], x[1]))(
              [deep_seq_inputs, self.bias[i]])
      tf.logging.info(
          'SeqCrossLayer: deep_seq_inputs {}'.format(deep_seq_inputs))

    if self.flatten_output_seq:
      deep_seq_inputs = tf.keras.layers.Flatten()(deep_seq_inputs)
      if self.keep_attention_value:
        return tf.keras.layers.Concatenate()([deep_seq_inputs] + output_list)
      return deep_seq_inputs
    return deep_seq_inputs

  def compute_output_shape(self, input_shape):
    if self.flatten_output_seq:
      if self.keep_attention_value:
        return (input_shape[0][0],
                self.flatten_output_seq_dim + self.output_list_dim)
      else:
        return (input_shape[0][0], self.flatten_output_seq_dim)
    else:
      return input_shape[0]

  def get_config(self):
    config = {
        'n_layers': self.n_layers,
        'l2_reg': self.l2_reg,
        'remove_attention': self.remove_attention,
        'keep_attention_value': self.keep_attention_value,
        'flatten_output_seq': self.flatten_output_seq,
        'seed': self.seed,
        'dropout_rate': self.dropout_rate
    }
    base_config = super(SeqCrossLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SynthesizerLayer(tf.keras.layers.Layer):
  """
    Model: dense and random Synthesizer

    Paper: Synthesizer: Rethinking Self-Attention in Transformer Models

    Link: https://arxiv.org/abs/2005.00743

    Author: Yi Tay, Dara Bahri, Donald Metzler, Da-Cheng Juan, Zhe Zhao, Che Zheng

    Developer: anbo

    Date: 2020-06-24

    inputs:  3d tensor, (batch, q_len, heads, d_k)

    return: 3d tensor, (batch, q_len, heads*d_k)

    """
  def __init__(self,
               dim_e=None,
               synthesizer_type='dense',
               l2_reg=0.0001,
               seed=1024,
               **kwargs):
    """
        :param dim_e: int
        :param synthesizer_type:  string, 'dense' or 'random'
        :param l2_reg: float
        :param seed: int
        :param kwargs:
        """
    super(SynthesizerLayer, self).__init__(**kwargs)
    self.synthesizer_type = synthesizer_type
    self.l2_reg = l2_reg
    self.seed = seed
    self.dim_e = dim_e

  def build(self, input_shape):
    self.seq_len = int(input_shape[1])
    self.heads = int(input_shape[2])
    self.d_k = int(input_shape[-1])
    hidden_unit = self.heads * self.d_k

    if self.synthesizer_type == 'dense':
      assert (self.dim_e
              is not None), ('Must specify dim_e for dense synthesizer')
      self.pro_weight_1 = self.add_weight(
          name='pro_weight_1',
          shape=(hidden_unit, self.dim_e),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)

      self.pro_bias_1 = self.add_weight(
          name='pro_bias_1',
          shape=(self.dim_e,),
          initializer=tf.keras.initializers.Zeros(),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)

      self.pro_weight_2 = self.add_weight(
          name='pro_weight_2',
          shape=(self.dim_e, self.seq_len),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)

      self.pro_bias_2 = self.add_weight(
          name='pro_bias_2',
          shape=(self.seq_len,),
          initializer=tf.keras.initializers.Zeros(),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)

    elif self.synthesizer_type == 'random':
      self.random_weight = self.add_weight(
          name='random_weight',
          shape=(self.seq_len, self.seq_len),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)

    self.value_weight = self.add_weight(
        name='value_weight',
        shape=(hidden_unit, hidden_unit),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.value_bias = self.add_weight(
        name='value_bias',
        shape=(hidden_unit,),
        initializer=tf.keras.initializers.Zeros(),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(SynthesizerLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (batch, seq_len, heads, d_k)

        Returns:
            (batch, seq_len, heads*d_k)
        """
    inputs = tf.keras.backend.reshape(
        inputs, shape=[-1, self.seq_len, self.heads * self.d_k])

    v = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.value_weight), self.value_bias)
    tf.logging.info('SynthesizerLayer: v {}'.format(v))

    if self.synthesizer_type == 'dense':
      dense_syn_pro_1 = tf.keras.backend.bias_add(
          tf.keras.backend.dot(inputs, self.pro_weight_1), self.pro_bias_1)
      dense_syn_pro_1 = tf.nn.sigmoid(dense_syn_pro_1)
      synthesizer_output = tf.keras.backend.bias_add(
          tf.keras.backend.dot(dense_syn_pro_1, self.pro_weight_2),
          self.pro_bias_2)
      # synthesizer_output: (batch, seq_len, seq_len)
      synthesizer_output = tf.nn.softmax(synthesizer_output, axis=-1)
      tf.logging.info('synthesizer_output dense {}'.format(synthesizer_output))
      output = tf.matmul(synthesizer_output, v)

    elif self.synthesizer_type == 'random':
      synthesizer_output = tf.nn.softmax(self.random_weight, axis=-1)
      tf.logging.info(
          'synthesizer_output random {}'.format(synthesizer_output))
      output = tf.tensordot(v, synthesizer_output, axes=[1, 0])
      output = tf.transpose(output, perm=[0, 2, 1])

    tf.logging.info('output {}'.format(output))

    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:2].concatenate(self.heads * self.d_k)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'dim_e': self.dim_e,
        'synthesizer_type': self.synthesizer_type
    }
    base_config = super(SynthesizerLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class LocalGlobalLayer(tf.keras.layers.Layer):
  """
    Model: gating mechanisim for local and global attention

    Paper: Leveraging Local and Global Patterns for Self-Attention Networks

    Link: https://www.aclweb.org/anthology/P19-1295

    Author: Mingzhou Xu, Derek F. Wong, Baosong Yang, Yue Zhang, Lidia S. Chao

    Developer: anbo

    Date: 2020-06-24


    inputs: list with length of 3, [query, key, value]
        query: (batch, q_len, heads, d_k)
        key: (batch, k_len, heads, d_k)
        value: (batch, k_len, heads, d_k)

    return: 3d tensor, (batch, q_len, heads*d_k), hereby heads*d_k = hidden_units

    """
  def __init__(self,
               l2_reg=0.0001,
               dropout_rate=0.1,
               inf=1e9,
               seed=1024,
               window=1,
               **kwargs):
    """
        :param l2_reg: float
        :param dropout_rate: float
        :param inf: int
        :param seed: int
        :param kwargs:
        """
    super(LocalGlobalLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.inf = inf
    self.seed = seed
    self.dropout_rate = dropout_rate
    self.window = window

  def build(self, input_shape):
    self.seq_len = int(input_shape[0][1])
    self.heads = int(input_shape[0][2])
    self.d_k = int(input_shape[0][-1])

    # gate_layer and seq_matrix_mask are required by local attention
    self.weight_gate = self.add_weight(
        name='weight_gate',
        shape=(self.d_k, 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    # self.seq_matrix_mask = 1.0 - self.inf * (1.0 - tf.matrix_band_part(tf.ones([self.seq_len, self.seq_len]), 1, 1))
    #self.seq_matrix_mask = 1.0 - self.inf * (1.0 - tf.matrix_band_part(tf.ones([self.seq_len, self.seq_len]), self.window, self.window))

    self.seq_matrix_mask = tf.matrix_band_part(
        tf.ones([self.seq_len, self.seq_len]), self.window, self.window)
    self.lower_triangle_mask = tf.matrix_band_part(
        tf.ones([self.seq_len, self.seq_len]), -1, 0)

    self.dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                           name='dropout_layer')

    super(LocalGlobalLayer, self).build(input_shape)

  def get_attention_energy_func(self, query, key, mask=None, training=None):
    scores = tf.keras.backend.batch_dot(query, key, axes=[3, 2])
    # scores (batch, heads, q_len, q_len)
    tf.logging.info('self attention batch_dot scores shape {}'.format(scores))
    scores = tf.keras.layers.Lambda(lambda x: tf.multiply(
        x, 1. / tf.sqrt(tf.cast(self.d_k, tf.float32))))(scores)
    tf.logging.info('self attention scale scores shape {}'.format(scores))
    # scores: (batch, heads, query_len, key_len)

    if mask is not None:
      scores += -1e9 * tf.cast(mask, tf.float32)

    #scores = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, -1))(scores)
    #tf.logging.info('self attention softmax scores shape {}'.format(scores))
    #scores = self.dropout(scores, training=training)
    return scores

  def call(self, inputs, mask=None, training=None, **kwargs):
    """
        Args:
            inputs: list of [query, key, value]
            query: (batch, q_len, heads, d_k)
            key: (batch, k_len, heads, d_k)
            value: (batch, k_len, heads, d_k)

        Returns:
            (batch, heads, query_len, d_k)

        """
    query, key, value = inputs

    query = tf.keras.backend.permute_dimensions(query, (0, 2, 1, 3))
    # query (batch, heads, q_len, d_k)
    key = tf.keras.backend.permute_dimensions(key, (0, 2, 3, 1))
    # key (batch, heads, d_k, q_len)
    tf.logging.info('self attention query {}, key {}'.format(query, key))

    # get gate weights
    gate_weight = tf.keras.backend.dot(query, self.weight_gate)
    gate_weight = tf.nn.sigmoid(gate_weight)
    # gate_weight: (batch, heads, query_len, 1)
    tf.logging.info('LocalGlobalLayer: gate_weight {}'.format(gate_weight))

    tf.summary.scalar('LocalGlobalLayer_all_reduced_mean_gate_weight',
                      tf.reduce_mean(gate_weight))
    for i in range(self.heads):
      tf.summary.scalar('LocalGlobalLayer_head_{}_gate_weight'.format(i),
                        tf.reduce_mean(gate_weight[:, i, :, :]))

    # get attention energy
    scores = self.get_attention_energy_func(query,
                                            key,
                                            mask=mask,
                                            training=training)
    # scores: (batch, heads, len, len)

    # local
    # local_scores = scores * self.seq_matrix_mask
    # global_scores = scores * self.upper_triangle_mask
    local_scores = scores + (
        1.0 - self.seq_matrix_mask[tf.newaxis, tf.newaxis, :, :]) * (-1.e+9)
    global_scores = scores + (1.0 - self.lower_triangle_mask[
        tf.newaxis, tf.newaxis, :, :]) * (-1.e+9)

    # local
    #local_scores = scores * self.seq_matrix_mask
    global_attn_scores = tf.nn.softmax(global_scores, axis=-1)
    local_attn_scores = tf.nn.softmax(local_scores, axis=-1)
    # *_attn_scores: (batch, heads, query_len, query_len)
    tf.logging.info(
        'LocalGlobalLayer: global_attn_scores {}'.format(global_attn_scores))

    # visualization
    vis_local_attn_score = tf.keras.backend.permute_dimensions(
        local_attn_scores, pattern=[0, 2, 3, 1])
    vis_local_attn_score = tf.reduce_mean(vis_local_attn_score,
                                          axis=[0, 3],
                                          keepdims=True)
    tf.summary.image('vis_local_attn_score',
                     tensor=vis_local_attn_score,
                     max_outputs=2,
                     collections=None,
                     family=None)

    vis_global_attn_score = tf.keras.backend.permute_dimensions(
        global_attn_scores, pattern=[0, 2, 3, 1])
    vis_global_attn_score = tf.reduce_mean(vis_global_attn_score,
                                           axis=[0, 3],
                                           keepdims=True)
    tf.summary.image('vis_global_attn_score',
                     tensor=vis_global_attn_score,
                     max_outputs=2,
                     collections=None,
                     family=None)

    global_output = tf.keras.backend.batch_dot(
        global_attn_scores,
        tf.keras.backend.permute_dimensions(value, (0, 2, 1, 3)))
    local_output = tf.keras.backend.batch_dot(
        local_attn_scores,
        tf.keras.backend.permute_dimensions(value, (0, 2, 1, 3)))
    # *_output: (batch, heads, query_len, d_k)
    tf.logging.info('LocalGlobalLayer: global_output {}'.format(global_output))

    # global_output = tf.matmul(global_attn_scores, value)
    # local_output = tf.matmul(local_attn_scores, value)
    # *_output: (batch, heads, query_len, d_k)

    output = (1.0 - gate_weight) * global_output + gate_weight * local_output
    # output = local_output
    # output: (batch, heads, query_len, d_k)
    tf.logging.info('LocalGlobalLayer: output {}'.format(output))

    output = tf.keras.backend.permute_dimensions(output, (0, 2, 1, 3))
    output = tf.keras.backend.reshape(
        output, shape=[-1, self.seq_len, self.heads * self.d_k])
    tf.logging.info('LocalGlobalLayer: output {}'.format(output))
    # attn_weight: (batch, query_len, heads*d_k)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:2].concatenate(self.heads * self.d_k)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'inf': self.inf,
        'dropout_rate': self.dropout_rate,
        'window': self.window
    }
    base_config = super(LocalGlobalLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class LinFormerAttnLayer(tf.keras.layers.Layer):
  """
    Model: Linear Self Attention in LinFormer

    Paper: Linformer: Self-Attention with Linear Complexity

    Link: https://arxiv.org/abs/2006.04768

    Author: Sinong Wang, Belinda Z. Li, Madian Khabsa, Han Fang, Hao Ma

    Developer: anbo

    Date: 2020-06-24

    inputs: list with length of 3, [query, key, value]
        query: (batch, q_len, heads, d_k)
        key: (batch, k_len, heads, d_k)
        value: (batch, k_len, heads, d_k)

    return: 3d tensor, (batch, q_len, heads*d_k), hereby heads*d_k = hidden_units

    """
  def __init__(self,
               dim_e,
               l2_reg=0.0001,
               dropout_rate=0.1,
               seed=1024,
               **kwargs):
    """
        :param dim_e: int, hidden unit for smaller linear projection, dim_e << seq_len
        :param l2_reg: float
        :param dropout_rate: float, dropout rate
        :param seed: int
        :param kwargs:
        """
    super(LinFormerAttnLayer, self).__init__(**kwargs)
    self.dropout_rate = dropout_rate
    self.dim_e = dim_e
    self.seed = seed
    self.l2_reg = l2_reg

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
    self.parse_input_shape(input_shape)

    self.dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                           name='dropout_layer')

    # weight_e and f are required by Linfromer
    self.weight_e = self.add_weight(
        name='weight_e',
        shape=(self.key_len, self.dim_e),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.bias_e = self.add_weight(name='bias_e',
                                  shape=(self.dim_e,),
                                  initializer=tf.keras.initializers.Zeros(),
                                  regularizer=tf.keras.regularizers.L1L2(
                                      0, self.l2_reg),
                                  trainable=True)

    self.weight_f = self.add_weight(
        name='weight_f',
        shape=(self.key_len, self.dim_e),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.bias_f = self.add_weight(name='bias_f',
                                  shape=(self.dim_e,),
                                  initializer=tf.keras.initializers.Zeros(),
                                  regularizer=tf.keras.regularizers.L1L2(
                                      0, self.l2_reg),
                                  trainable=True)

    super(LinFormerAttnLayer, self).build(input_shape)

  def parse_input_shape(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
    self.query_len = int(input_shape[0][1])
    self.key_len = int(input_shape[1][1])
    self.heads = int(input_shape[1][2])
    self.d_k = int(input_shape[1][3])
    tf.logging.info(
        'LinFormerAttnLayer parse_input_shape: query_len {}\n, key_len {}\n, heads {}\n, d_k {}'
        .format(self.query_len, self.key_len, self.heads, self.d_k))

  def final_projection_func(self, scores, value):
    """
        Args:
          scores: (batch, heads, query_len, key_len)
          value: (batch, key_len, heads, d_k)

        Returns:
            (batch, seq_len, heads*d_k)

        """
    attn_weight = tf.keras.backend.batch_dot(scores, value)
    attn_weight = tf.keras.backend.permute_dimensions(attn_weight,
                                                      (0, 2, 1, 3))
    # attn_weight (batch, q_len, heads, d_k)
    tf.logging.info('LinFormerAttnLayer: attn_weight {}'.format(attn_weight))

    attn_weight = tf.keras.backend.reshape(
        attn_weight, shape=[-1, self.query_len, self.heads * self.d_k])
    tf.logging.info('LinFormerAttnLayer: attn_weight {}'.format(attn_weight))
    # attn_weight: (batch, query_len, heads*d_k)

    return attn_weight

  def linformer_energy_func(self, query, key):
    """
        Args:
            query: (batch, query_len, heads, d_k)
            key: (batch, key_len, heads, d_k)
            value: (batch, key_len, heads, d_k)
        """
    query = tf.keras.backend.permute_dimensions(query, (0, 2, 1, 3))
    # query: (batch, heads, q_len, d_k)
    key = tf.keras.backend.permute_dimensions(key, (0, 2, 3, 1))
    # key: (batch, heads, d_k, q_len)
    tf.logging.info('LinFormerAttnLayer: query {},\n key {}'.format(
        query, key))
    linear_key = tf.keras.backend.bias_add(
        tf.keras.backend.dot(key, self.weight_e), self.bias_e)
    # linear_key: (batch, heads, d_k, dim_e)

    scores = tf.keras.backend.batch_dot(query, linear_key, axes=[3, 2])
    # scores (batch, heads, q_len, dim_e)

    return scores

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: list of [query, key, value]
            query: (batch, query_len, heads, d_k)
            key: (batch, key_len, heads, d_k)
            value: (batch, key_len, heads, d_k)

        Returns:
            (batch, seq_len, heads*d_k)

        """
    query, key, value = inputs

    # compute score between query and key
    scores = self.linformer_energy_func(query, key)

    scores = tf.keras.layers.Lambda(lambda x: tf.multiply(
        x, 1. / tf.sqrt(tf.cast(self.d_k, tf.float32))))(scores)
    tf.logging.info('LinFormerAttnLayer: scale scores: {}'.format(scores))
    # scores: (batch, heads, query_len, key_len)

    scores = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, -1))(scores)
    tf.logging.info('LinFormerAttnLayer: softmax scores: {}'.format(scores))
    scores = self.dropout(scores, training=training)

    linear_value = tf.keras.backend.bias_add(
        tf.keras.backend.dot(
            tf.keras.backend.permute_dimensions(value, (0, 2, 3, 1)),
            self.weight_f), self.bias_f)
    # linear_value: (batch, heads, d_k, dim_e)
    tf.logging.info(
        'LinFormerAttnLayer: linear_value: {}'.format(linear_value))
    linear_value = tf.keras.backend.permute_dimensions(linear_value,
                                                       (0, 1, 3, 2))
    # linear_value: (batch, heads, dim_e, d_k)

    attn_weight = self.final_projection_func(scores, linear_value)
    return attn_weight

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:2].concatenate(self.heads * self.d_k)

  def get_config(self):
    config = {
        'dropout_rate': self.dropout_rate,
        'dim_e': self.dim_e,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(LinFormerAttnLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class ReAttentionLayer(tf.keras.layers.Layer):
  """
    Model: Re Attention

    Paper: DeepViT: Towards Deeper Vision Transformer

    Link: https://arxiv.org/abs/2103.11886

    Author: Daquan Zhou, Bingyi Kang, Xiaojie Jin, Linjie Yang, Xiaochen Lian, Zihang Jiang, Qibin Hou, Jiashi Feng

    Developer: anbo

    Date: 2021-06-01

    inputs: list with length of 3, [query, key, value]
        query: (batch, q_len, heads, d_k)
        key: (batch, k_len, heads, d_k)
        value: (batch, k_len, heads, d_k)

    return: 3d tensor, (batch, q_len, heads*d_k), hereby heads*d_k = hidden_units

    """
  def __init__(self, l2_reg=0.0001, seed=1024, **kwargs):
    """
        Args:
            dropout_rate: float, dropout rate
            kwargs:

        """
    super(ReAttentionLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
    self.query_len = int(input_shape[0][1])
    self.heads = int(input_shape[0][2])
    self.d_k = int(input_shape[0][3])

    self.head_weight = self.add_weight(
        name='head_weight',
        shape=(self.heads, self.heads),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    from alps_biz.core.layer.sequence import LayerNorm
    self.norm_layer = LayerNorm(name='norm_layer')

    # self.dropout = tf.keras.layers.Dropout(self.dropout_rate, name='dropout_layer')
    super(ReAttentionLayer, self).build(input_shape)

  def call(self, inputs, mask=None, training=None, **kwargs):
    """
        Args:
            inputs: list of [query, key, value]
                query: (batch, query_len, heads, d_k)
                key: (batch, key_len, heads, d_k)
                value: (batch, key_len, heads, d_k)

        Returns:
            (batch, seq_len, heads*d_k)

        """
    query, key, value = inputs
    query = tf.keras.backend.permute_dimensions(query, (0, 2, 1, 3))
    # query (batch, heads, q_len, d_k)
    key = tf.keras.backend.permute_dimensions(key, (0, 2, 3, 1))
    # key (batch, heads, d_k, q_len)
    tf.logging.info('ReAttentionLayer: query {}, key {}'.format(query, key))

    scores = tf.keras.backend.batch_dot(query, key, axes=[3, 2])
    # scores (batch, heads, q_len, q_len)
    tf.logging.info(
        'ReAttentionLayer: batch_dot scores shape {}'.format(scores))

    scores = tf.keras.layers.Lambda(lambda x: tf.multiply(
        x, 1. / tf.sqrt(tf.cast(self.d_k, tf.float32))))(scores)
    #tf.logging.info('self attention scale scores shape {}'.format(scores))
    # scores: (batch, heads, query_len, key_len)

    if mask is not None:
      tf.logging.info('self: mask {}'.format(mask))
      #seq_mask = create_padding_mask(mask)
      scores += -1e9 * tf.cast(mask, tf.float32)

    scores = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, -1))(scores)
    #tf.logging.info('self attention softmax scores shape {}'.format(scores))
    #scores = self.dropout(scores, training=training)

    # re attention
    scores = tf.keras.backend.permute_dimensions(scores, (0, 2, 3, 1))
    scores = tf.tensordot(scores, self.head_weight, axes=[-1, 0])
    scores = tf.keras.backend.permute_dimensions(scores, (0, 3, 1, 2))
    tf.logging.info('ReAttentionLayer: head aggerate {}'.format(scores))
    scores = self.norm_layer(scores)

    attn_weight = tf.keras.backend.batch_dot(
        scores, tf.keras.backend.permute_dimensions(value, (0, 2, 1, 3)))
    # attn_weight (batch, heads, q_len, d_k)
    tf.logging.info(
        'ReAttentionLayer: attn_weight shape {}'.format(attn_weight))
    # attn_weight: (batch, heads, query_len, d_k)
    attn_weight = tf.keras.backend.reshape(
        attn_weight, shape=[-1, self.query_len, self.heads * self.d_k])
    tf.logging.info(
        'ReAttentionLayer: attn_weight shape {}'.format(attn_weight))
    # attn_weight: (batch, query_len, heads*d_k)
    return attn_weight

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:2].concatenate(self.heads * self.d_k)

  def get_config(self):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(ReAttentionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class GeneralSelfAttnLayer(tf.keras.layers.Layer):
    """
      Model: General Self Attention

      Developer: anbo

      Date: 2020-06-24

      inputs: list with length of 3, [query, key, value]
          query: (batch, q_len, heads, d_k)
          key: (batch, k_len, heads, d_k)
          value: (batch, k_len, heads, d_k)

      return: 3d tensor, (batch, q_len, heads*d_k), hereby heads*d_k = hidden_units

      """

    def __init__(self,
                 mha_type='vanilla',
                 dim_e=None,
                 synthesizer_type='dense',
                 l2_reg=0.0001,
                 dropout_rate=0.1,
                 seed=1024,
                 inf=1e9,
                 window=1,
                 **kwargs):
        """
            :param mha_type: string
            :param dim_e: int
            :param synthesizer_type: string
            :param l2_reg: float
            :param dropout_rate: float
            :param seed: int
            :param inf: int
            :param kwargs:
            """
        super(GeneralSelfAttnLayer, self).__init__(**kwargs)
        self.dropout_rate = dropout_rate
        self.dim_e = dim_e
        self.seed = seed
        self.l2_reg = l2_reg
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type
        self.window = window

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        self.seq_len = int(input_shape[0][1])
        self.heads = int(input_shape[0][2])
        self.d_k = int(input_shape[0][3])

        if self.mha_type == 'vanilla':
            from alps_biz.core.layer.sequence import SelfAttentionLayer
            self.mha_layer = SelfAttentionLayer(dropout_rate=self.dropout_rate)

        elif self.mha_type == 'local':
            self.mha_layer = LocalGlobalLayer(l2_reg=self.l2_reg,
                                              inf=self.inf,
                                              seed=self.seed,
                                              window=self.window)

        elif self.mha_type == 'linformer':
            self.mha_layer = LinFormerAttnLayer(dim_e=self.dim_e,
                                                l2_reg=self.l2_reg,
                                                dropout_rate=self.dropout_rate,
                                                seed=self.seed)

        elif self.mha_type == 'synthesizer':
            self.mha_layer = SynthesizerLayer(dim_e=self.dim_e,
                                              synthesizer_type=self.synthesizer_type,
                                              l2_reg=self.l2_reg,
                                              seed=self.seed)

        elif self.mha_type == 'reattention':
            self.mha_layer = ReAttentionLayer(l2_reg=self.l2_reg, seed=self.seed)

        super(GeneralSelfAttnLayer, self).build(input_shape)

    def call(self, inputs, mask=None, training=None, **kwargs):
        """
            Args:
                inputs: list of [query, key, value]
                query: (batch, query_len, heads, d_k)
                key: (batch, key_len, heads, d_k)
                value: (batch, key_len, heads, d_k)

            Returns:
                (batch, seq_len, heads*d_k)

            """
        if self.mha_type in ['vanilla', 'local', 'linformer', 'reattention']:
            output = self.mha_layer(inputs, mask=mask, training=training)
        elif self.mha_type in ['synthesizer']:
            output = self.mha_layer(inputs[0], training=training)
        else:
            raise NotImplementedError
        return output

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape[0])
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)
        return input_shape[:2].concatenate(self.heads * self.d_k)

    def get_config(self):
        config = {
            'dropout_rate': self.dropout_rate,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'l2_reg': self.l2_reg,
            'seed': self.seed,
            'mha_type': self.mha_type,
            'window': self.window
        }
        base_config = super(GeneralSelfAttnLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class PeachLayer(tf.keras.layers.Layer):
  """
    Model: Peach Layer

    Paper:

    Link:

    Author:

    Developer: anbo

    Date: 2020-11-09

    inputs: list of tensors, [a, b]
        a: (batch, len, dim1)
        b: (batch, dim2)

    outputs: 3d tensor, (batch, len, dim3)

    """
  def __init__(self, hidden_units=16, l2_reg=0, seed=1024, **kwargs):
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    super(PeachLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    dim_1, dim_2 = int(input_shape[0][-1]), int(input_shape[1][-1])
    self.kernels = []
    self.bias = []

    self.kernels.append(
        self.add_weight(
            name='kernel0',
            shape=[dim_1, dim_2],
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.l2(self.l2_reg),
            trainable=True))

    self.kernels.append(
        self.add_weight(
            name='kernel1',
            shape=[dim_2, self.hidden_units],
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.l2(self.l2_reg),
            trainable=True))

    self.bias.append(
        self.add_weight(name='bias',
                        shape=[
                            self.hidden_units,
                        ],
                        initializer=tf.keras.initializers.Zeros(),
                        trainable=True))

    super(PeachLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of tensors, [seq_input, agg_input], seq_input: (batch, len, fields, d1), agg_input: (batch, d2)
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return: 3d tensor, (batch, len, d3)
        """
    seq_input, agg_input = inputs
    seq_hidden_output = tf.tensordot(seq_input, self.kernels[0], axes=(-1, 0))
    seq_hidden_output = tf.nn.tanh(seq_hidden_output)
    # seq_hidden_output: (batch, len, dim_2)
    tf.logging.info(
        'PeachLayer: seq_hidden_output {}'.format(seq_hidden_output))

    element_output = tf.keras.layers.Multiply()([seq_hidden_output, agg_input])
    tf.logging.info('PeachLayer: element_output {}'.format(element_output))
    attention_weight = tf.tensordot(element_output,
                                    self.kernels[1],
                                    axes=(-1, 0))
    output = tf.nn.bias_add(attention_weight, self.bias[0])
    tf.logging.info('PeachLayer: output {}'.format(output))

    return output

  def compute_output_shape(self, input_shape):
    #return (input_shape[0][0], input_shape[0][1], self.hidden_units)
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:2].concatenate(self.hidden_units)

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
    }
    base_config = super(PeachLayer, self).get_config()
    config.update(base_config)
    return config


class HierarchicalAttnAggLayer(tf.keras.layers.Layer):
  """
    Model: Hierarchical Attention Aggregation layer

    Paper: Interpretable Click-Through Rate Prediction through Hierarchical Attention

    Link: https://dl.acm.org/doi/pdf/10.1145/3336191.3371785

    Author: Zeyu Li, Wei Cheng, Yang Chen, Haifeng Chen, Wei wang

    Developer: anbo

    Date: 2021-04-07

    inputs: (batch, fields, dim)

    outputs: 2d tensor, (batch, dim3)

    """
  def __init__(self,
               n_layers=4,
               hidden_size=16,
               l2_reg=0,
               seed=1024,
               **kwargs):
    self.hidden_size = hidden_size
    self.l2_reg = l2_reg
    self.seed = seed
    self.n_layers = n_layers
    super(HierarchicalAttnAggLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    dim = int(input_shape[-1])
    self.kernels = []
    self.contexts = []

    for i in range(self.n_layers):
      self.kernels.append(
          self.add_weight(
              name='kernel_layer_{}'.format(i),
              shape=[dim, self.hidden_size],
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.l2(self.l2_reg),
              trainable=True))

      self.contexts.append(
          self.add_weight(
              name='context_layer_{}'.format(i),
              shape=[self.hidden_size, 1],
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.l2(self.l2_reg),
              trainable=True))

    self.attn_kernel = self.add_weight(
        name='attn_agg_kernel',
        shape=[dim, self.hidden_size],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.attn_context = self.add_weight(
        name='attn_context_kernel',
        shape=[self.hidden_size, 1],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    super(HierarchicalAttnAggLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        :param inputs: 3d tensor, (batch, fields, dim)
        :param kwargs:
        :return: 2d tensor, (batch, d3)
        """
    attn_output_list = []
    hidden_representation_i = inputs
    for i in range(self.n_layers):
      hidden_output = tf.tensordot(inputs, self.kernels[i], axes=(-1, 0))
      hidden_output = tf.nn.relu(hidden_output)
      # hidden_output: (batch, fields, hidden_size)
      tf.logging.info(
          'HierarchicalAttnAggLayer: hidden_output {} of layer {}'.format(
              hidden_output, i))

      attn_weight = tf.tensordot(hidden_output, self.contexts[i], axes=(-1, 0))
      attn_score = tf.nn.softmax(attn_weight, axis=1)
      # attn_score: (batch, fields, 1)
      tf.logging.info(
          'HierarchicalAttnAggLayer: attn_score {} of layer {}'.format(
              attn_score, i))

      attn_score = tf.keras.backend.permute_dimensions(attn_score, (0, 2, 1))
      u_i = tf.matmul(attn_score, hidden_representation_i)
      #u_i: (batch, 1, dim)
      tf.logging.info('HierarchicalAttnAggLayer: u_i {} of layer {}'.format(
          u_i, i))
      attn_output_list.append(u_i)

      hidden_representation_i = tf.keras.layers.Multiply()(
          [u_i, inputs]) + hidden_representation_i
      tf.logging.info(
          'HierarchicalAttnAggLayer: hidden_representation_i {} of layer {}'.
          format(hidden_representation_i, i))

    attn_output = tf.keras.layers.Concatenate(axis=1)(
        attn_output_list) if len(attn_output_list) > 1 else attn_output_list[0]
    # attn_output: (batch, k, dim), k = self.n_layers

    attn_hidden_output = tf.tensordot(attn_output,
                                      self.attn_kernel,
                                      axes=(-1, 0))
    attn_hidden_output = tf.nn.relu(attn_hidden_output)
    # attn_hidden_output: (batch, k, dim)
    tf.logging.info('HierarchicalAttnAggLayer: attn_hidden_output {}'.format(
        attn_hidden_output))

    attn_final_weight = tf.tensordot(attn_hidden_output,
                                     self.attn_context,
                                     axes=(-1, 0))
    attn_final_score = tf.nn.softmax(attn_final_weight, axis=1)
    # attn_final_score: (batch, k, 1)
    tf.logging.info('HierarchicalAttnAggLayer: attn_final_score {}'.format(
        attn_final_score))

    attn_final_score = tf.keras.backend.permute_dimensions(
        attn_final_score, (0, 2, 1))
    output = tf.matmul(attn_final_score, attn_output)
    # output: (batch, 1, dim)
    output = tf.squeeze(output, axis=1)
    tf.logging.info('HierarchicalAttnAggLayer: output {}'.format(output))

    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self,):
    config = {
        'n_layers': self.n_layers,
        'hidden_size': self.hidden_size,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
    }
    base_config = super(HierarchicalAttnAggLayer, self).get_config()
    config.update(base_config)
    return config
