import itertools
import logging
import tensorflow as tf


class ESMMMetaLayer(object):
    """ESMM is a multitask meta layer which creates a layer for each task and handles task dependencies.

    For the computational logic of handling task dependencies, please refer to
    https://arxiv.org/pdf/1804.07931.pdf

    """
    def __init__(self, task_name_to_label_name, task_dependencies, layer_factory):
        """
        Args:
            task_name_to_label_name: A dict maps task name to label name.
            task_dependencies: A list of task dependencies, e.g.
                [['A', 'B', 'C'], ['B', 'D']] specifies two label dependencies,
                one is 'A'-'B'-'C', another one is 'B'-'D'.
            layer_factory: A callable function to create layer instance.

        Returns: 
            The model output dict modified by ESSM

        """
        self.task_name_to_label_name = task_name_to_label_name
        self.check_task_dependencies(task_dependencies)
        self.task_dependencies = task_dependencies

        self.layers = {}
        for task_name in task_name_to_label_name.keys():
            self.layers[task_name] = layer_factory()

    def __call__(self, inputs):
        task_output = {}
        for task_name in self.task_name_to_label_name.keys():
            with tf.variable_scope(task_name):
                layer = self.layers[task_name]
                output = layer(inputs)
                task_output[task_name] = output

        for dependency in self.task_dependencies:
            for i in range(1, len(dependency)):
                task_0 = dependency[i - 1]
                task_1 = dependency[i]
                if isinstance(task_output[task_0], list):
                    logging.warning("The output of the layers in ESMM is a list, ESMM "
                                    "calculates dependencies only on the first tensor "
                                    "of the output list.")
                    output_0 = task_output[task_0]
                    output_1 = task_output[task_1]
                    output_1[0] = output_1[0] * output_0[0]
                else:
                    task_output[task_1] = task_output[task_1] * task_output[task_0]
        return task_output

    def check_task_dependencies(self, task_dependencies):
        """Check the validity of param `task_dependencies`."""
        flatten_list = list(itertools.chain(*task_dependencies))
        if len(flatten_list) != len(set(flatten_list)):
            raise ValueError("task_dependencies has repeated item: " + str(task_dependencies))
        for dependency in task_dependencies:
            if len(dependency) < 2:
                raise ValueError("each dependency list in task_dependencies should have at least two item")
