# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape

class FMLayer(tf.keras.layers.Layer):
    """
    Model: Factorization Machine

    Paper: Factorization Machine models pairwise (order-2) feature interactions without linear term and bias.

    Link: https://www.csie.ntu.edu.tw/~b97053/paper/Rendle2010FM.pdf

    Author: Steffen Rendle

    Developer: anbo

    Date: 2019-11-29

    Input shape
        - 3D tensor with shape: ``(batch_size,field_size,embedding_size)``.

    Output shape
        - 2D tensor with shape: ``(batch_size, dim)``.

    """

    def __init__(self, **kwargs):
        super(FMLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        if len(input_shape) != 3:
            raise ValueError("Unexpected inputs dimensions % d, expect to be 3 dimensions" % (len(input_shape)))

        super(FMLayer, self).build(input_shape)  # Be sure to call this somewhere!

    def call(self, inputs, **kwargs):
        """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
        if tf.keras.backend.ndim(inputs) != 3:
            raise ValueError(
                "Unexpected inputs dimensions %d, expect to be 3 dimensions"
                % (tf.keras.backend.ndim(inputs)))

        fm_inputs = inputs
        squared_sum = tf.keras.backend.square(tf.keras.backend.sum(fm_inputs, axis=1, keepdims=True))
        # squared_sum (batch, dim)
        tf.logging.info('squared_sum shape {}'.format(squared_sum.shape))
        sum_squared = tf.keras.backend.sum(fm_inputs * fm_inputs, axis=1, keepdims=True)
        tf.logging.info('sum_squared shape {}'.format(sum_squared.shape))
        output = tf.keras.layers.Lambda(lambda x: 0.5 * tf.subtract(x[0], x[1]))([squared_sum, sum_squared])
        output = tf.keras.backend.squeeze(output, axis=1)
        tf.logging.info('output {}'.format(output))
        return output

    def compute_output_shape(self, input_shape):
        #return (input_shape[0], input_shape[-1])
        input_shape = tensor_shape.TensorShape(input_shape)
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError('The innermost dimension of input_shape must be defined, but saw: %s' % input_shape)
        return input_shape[:1].concatenate(input_shape[-1])


class CrossLayer(tf.keras.layers.Layer):
    """
    Model: DCN

    Paper: Deep & Cross Network for Ad Click Predictions

    Link: https://arxiv.org/abs/1708.05123

    Author: Ruoxi Wang, Bin Fu, Gang Fu, Mingliang Wang

    Developer: anbo

    Date: 2019-11-29

    This is the CrossLayer in DCN Model

    X_{l+1} = X_0 * X_l^T * W_l + b_l + X_l

    The shape of these tensors are X_l (batch, n_dim), W_l (batch, ), b_l (batch, ).

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

    """

    def __init__(self, n_layers=2, l2_reg=0.001, seed=1024, **kwargs):
        """
        Args:
            n_layers: int, number of cross layers
            l2_reg: float, regularization value

        """
        super(CrossLayer, self).__init__(**kwargs)
        self.n_layers = n_layers
        self.l2_reg = l2_reg
        self.seed = seed
        tf.logging.info('cross layer, n_layers {}, l2_reg {}'.format(n_layers, l2_reg))

    def build(self, input_shape):
        """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
        input_size = int(input_shape[-1])
        tf.logging.info('input_size {}'.format(input_size))
        self.kernels, self.bias = [], []
        for i in range(self.n_layers):
            self.kernels.append(
                self.add_weight(
                    name='weight_{}'.format(i),
                    shape=(input_size, 1),
                    initializer=tf.keras.initializers.he_normal(seed=self.seed),
                    regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                    trainable=True))
            self.bias.append(
                self.add_weight(name='bias_{}'.format(i), shape=(input_size,), initializer=tf.keras.initializers.Zeros(), trainable=True))
        super(CrossLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
        Args:
            inputs: 2d tensor, (batch_size, n_dim)

        Returns:
            2d tensor, (batch_size, n_dim)
            k
        """
        inputs = tf.keras.backend.expand_dims(inputs, axis=1)  # X_0
        deep_inputs = inputs
        # deep_inputs (batch, 1, d)
        tf.logging.info('Cross Layer deep_inputs {}'.format(deep_inputs))
        for i in range(self.n_layers):
            tf.logging.info('kernel size {}'.format(self.kernels[i]))
            deep_inputs = tf.keras.backend.batch_dot(tf.keras.backend.dot(deep_inputs, self.kernels[i]), inputs, axes=[1, 1]) + deep_inputs
            deep_inputs = tf.keras.backend.bias_add(deep_inputs, self.bias[i])
            tf.logging.info('Cross Layer inside deep_inputs {}'.format(deep_inputs))

        deep_inputs = tf.keras.backend.squeeze(deep_inputs, axis=1)
        return deep_inputs

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {'n_layers': self.n_layers, 'l2_reg': self.l2_reg, 'seed':self.seed}
        base_config = super(CrossLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class CINLayer(tf.keras.layers.Layer):
    """
    Model: xDeepFM

    Paper: xDeepFM: Combining Explicit and Implicit Feature Interactions for Recommender Systems

    Link: https://arxiv.org/abs/1803.05170

    Author: Jianxun Lian, Xiaohuan Zhou, Fuzheng Zhang, Zhongxia Chen, Xing Xie, Guangzhong Sun

    Developer: anbo

    Date: 2019-11-30

    This is the CIN Layer in xDeepFM

    Tensor shapes: len(hidden_units) <= 3 is better

    inputs: 3d tensor, (batch_size, field_size, embedding_dim)

    outputs: 2d tensor, (batch_size, feature_size)
    """

    def __init__(self, hidden_units=[100, 100], act_fn='relu', l2_reg=1.e-5, seed=1024, **kwargs):
        """
        Args:
            hidden_units: list of tuple,
            act_fn: string, activation function
            l2_reg: float, regularization value

        """
        super(CINLayer, self).__init__(**kwargs)
        self.hidden_units = hidden_units
        self.act_fn = act_fn
        self.l2_reg = l2_reg
        self.seed = seed

    def build(self, input_shape):
        """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
        fields = int(input_shape[1])
        dim = int(input_shape[-1])
        self.conv_kernels = []
        self.output_size = sum(self.hidden_units)

        for i in range(len(self.hidden_units)):
            self.conv_kernels.append(
                tf.keras.layers.Conv2D(
                    self.hidden_units[0],
                    kernel_size=[fields, 1],
                    strides=1,
                    padding='valid',
                    activation=self.act_fn,
                    kernel_initializer=tf.keras.initializers.he_normal(seed=self.seed),
                    kernel_regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                    bias_regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg), name='conv2d_layer_{}'.format(i)))

        super(CINLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
        Args:
            inputs: 3d tensor, (batch, fields, dim)

        Returns:
            2d tensor: (batch, sum(hidden_units))

        """
        tf.logging.info('CINLayer: inputs {}'.format(inputs))
        #dim = tf.keras.backend.int_shape(inputs)[-1]
        X_outputs = [inputs]
        output = []

        X_0 = tf.keras.backend.expand_dims(inputs, axis=1)
        # X_0: (batch, 1, fields, dim)
        tf.logging.info('CINLayer: X_0 {}'.format(X_0))

        for i, filter_size in enumerate(self.hidden_units):
            X_i = tf.keras.backend.expand_dims(X_outputs[-1], axis=2)
            # X_i: (batch, filters, 1, dim)
            tf.logging.info('CINLayer: X_i {}'.format(X_i))
            Z_i = tf.keras.layers.Lambda(lambda x: x[0] * x[1])([X_0, X_i])
            # Z_i: (batch, filters, fields, dim)
            tf.logging.info('CINLayer: Z_i shape {}'.format(Z_i))
            Z_i = tf.keras.backend.permute_dimensions(Z_i, [0, 2, 3, 1])
            # Z_i: (batch, fields, dim, filters)
            tf.logging.info('CINLayer: Z_i reshape {}'.format(Z_i))
            X_next = self.conv_kernels[i](Z_i)
            # X_next: (batch, 1, dim, filters)
            X_next = tf.keras.backend.squeeze(tf.keras.backend.permute_dimensions(X_next, [0, 1, 3, 2]), axis=1)
            # X_next: (batch, filters, dim)
            tf.logging.info('CINLayer: X_next {}'.format(X_next))
            X_outputs.append(X_next)
            p_next = tf.keras.backend.sum(X_next, axis=-1, keepdims=False)
            # p_next: (batch, filters)
            output.append(p_next)

        return tf.keras.layers.Concatenate(axis=-1)(output)

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape)
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError('The innermost dimension of input_shape must be defined, but saw: %s' % input_shape)
        return input_shape[:1].concatenate(self.output_size)

    def get_config(self):
        config = {'hidden_units': self.hidden_units, 'act_fn': self.act_fn, 'l2_reg': self.l2_reg, 'seed':self.seed}
        base_config = super(CINLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class CrossMLayer(tf.keras.layers.Layer):
    """
    Model: DCN-M layer

    Paper: DCN-M: Improved Deep & Cross Network for Feature Cross Learning in Web-scale Learning to Rank Systems

    Link: https://arxiv.org/abs/2008.13535

    Author: Ruoxi Wang, Rakesh Shivanna, Derek Z. Cheng, Sagar Jain, Dong Lin, Lichan Hong, Ed H. Chi

    Developer: anbo

    Date: 2020-10-21

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

    """

    def __init__(self, n_layers=2, l2_reg=0.001, seed=1024, **kwargs):
        """
        Args:
            n_layers: int, number of cross layers
            l2_reg: float, regularization value

        """
        super(CrossMLayer, self).__init__(**kwargs)
        self.n_layers = n_layers
        self.l2_reg = l2_reg
        self.seed = seed
        tf.logging.info('CrossMLayer, n_layers {}, l2_reg {}'.format(n_layers, l2_reg))

    def build(self, input_shape):
        """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
        input_size = int(input_shape[-1])
        tf.logging.info('input_size {}'.format(input_size))
        self.kernels, self.bias = [], []
        for i in range(self.n_layers):
            self.kernels.append(
                self.add_weight(
                    name='weight_{}'.format(i),
                    shape=(input_size, input_size),
                    initializer=tf.keras.initializers.he_normal(seed=self.seed),
                    regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                    trainable=True))
            self.bias.append(
                self.add_weight(name='bias_{}'.format(i), shape=(input_size,), initializer=tf.keras.initializers.Zeros(), trainable=True))
        super(CrossMLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
        Args:
            inputs: 2d tensor, (batch_size, n_dim)

        Returns:
            2d tensor, (batch_size, n_dim)
            k
        """
        deep_inputs = inputs
        # deep_inputs (batch, 1, d)
        tf.logging.info('CrossM Layer deep_inputs {}'.format(deep_inputs))
        for i in range(self.n_layers):
            interact_output = tf.tensordot(deep_inputs, self.kernels[i], axes=[-1, 0])
            interact_output = tf.keras.backend.bias_add(interact_output, self.bias[i])
            interact_output = tf.keras.layers.Multiply()([inputs, interact_output])
            deep_inputs += interact_output
            tf.logging.info('CrossM Layer inside deep_inputs {}'.format(deep_inputs))

        return deep_inputs

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {'n_layers': self.n_layers, 'l2_reg': self.l2_reg, 'seed':self.seed}
        base_config = super(CrossMLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))