# coding:utf-8
# @copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.
import six
import tensorflow as tf
from tensorflow.keras.layers import Dense
from tensorflow.keras.regularizers import L1L2
from tensorflow.keras import initializers


class CostOffsetLearningLayer(tf.keras.layers.Layer):
    """A cost transform layer for Cost Regression which can learns a non-zero offset
    and transforms cost to obey webull distribution.

    The rule of this layer is:

    .. code-block:: python

        cost, embedding = inputs
        cost_offset = dense_layer(embedding)
        return pow((cost + abs(cost_offset)) * wb_lambda, wb_k)

    where `wb_lambda` and `wb_k` are learnable positive number.

    author: 易山、云谏

    """

    def __init__(self, max_amount, **kwargs):
        self.max_amount = max_amount
        super(CostOffsetLearningLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        self.dense = tf.keras.layers.Dense(1, kernel_initializer=tf.random_normal_initializer(0, 0.01))
        self.wb_k = self.add_weight(name="wb_k", shape=[1], initializer=initializers.Ones(), trainable=True)
        self.wb_lambda = self.add_weight(name="wb_lambda", shape=[1], initializer=initializers.Constant(1.0 / self.max_amount), trainable=True)

    def call(self, inputs):
        cost, embedding = inputs

        cost = tf.cast(cost, tf.float32)
        cost_offset = self.dense(embedding)
        cost_offset = tf.abs(cost_offset)
        cost = cost + cost_offset

        wb_k = tf.nn.relu(self.wb_k)
        wb_lambda = tf.nn.relu(self.wb_lambda)
        wb_cdf = tf.pow(cost * wb_lambda, wb_k)
        return wb_cdf

    def compute_output_shape(self, input_shape):
        return input_shape[0]

    def get_config(self):
        config = {"max_amount": self.max_amount}
        base_config = super(CostOffsetLearningLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class DefaultCostTransformLayer(tf.keras.layers.Layer):
    """Default option for cost transformation.

    The rule of this layer is `cost / max_amount`, where max_amount is a user-defined value.

    Author: 开远、易山、云谏

    """
    def __init__(self, max_amount, **kwargs):
        self.max_amount = max_amount
        super(DefaultCostTransformLayer, self).__init__(**kwargs)

    def call(self, inputs):
        cost, _ = inputs
        cost = tf.cast(cost, tf.float32)
        return cost / self.max_amount

    def compute_output_shape(self, input_shape):
        return input_shape[0]

    def get_config(self):
        config = {"max_amount": self.max_amount}
        base_config = super(DefaultCostTransformLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class CostTransformLayerNames:
    COST_OFFSET_LEARNING_LAYER = "cost_offset_learning_layer"
    DEFAULT = "defulat"


COST_TRANSFORM_LAYERS = {
    CostTransformLayerNames.COST_OFFSET_LEARNING_LAYER: CostOffsetLearningLayer,
    CostTransformLayerNames.DEFAULT: DefaultCostTransformLayer,
}


class CoxRegressionLayer(tf.keras.layers.Layer):
    """This is a layer for calculating cox regression.

    This layer takes a embedding and cost inputs and calculates as the following rule:
    logits = f(cost, embedding) * exp(g(embedding)), where f and g is a user-defined
    function. By default, f is `DefaultCostTransformLayer` and g is a keras dense layer.

    Please refer to wikipedia for more details:
    https://en.wikipedia.org/wiki/Proportional_hazards_model

    Author: 开远、易山、云谏

    """
    def __init__(self, embedding_transform_layer=None, cost_transform_layer=None, max_amount=None, l2_reg=0.0, l1_reg=0.0, **kwargs):
        """
        Args:
            embedding_transform_layer: A string or a callable object that speficifies the layer
                for embedding transformation.
            cost_transform_layer: A string or a callable object that specifies the layer for
                cost transformation.
            max_amount: A number specifies the max value of cost.
            l2_reg: The coefficient for l2 regularization.
            l1_reg: The coefficient for l1 regularization.

        """
        self.embedding_transform_layer = embedding_transform_layer
        self.cost_transform_layer = cost_transform_layer or CostTransformLayerNames.DEFAULT
        self.max_amount = max_amount
        self.l2_reg = l2_reg
        self.l1_reg = l1_reg

        if callable(self.embedding_transform_layer):
            self.embed_trans_layer = self.embedding_transform_layer
        else:
            assert self.embedding_transform_layer is None
            self.embed_trans_layer = tf.keras.layers.Dense(1, kernel_regularizer=L1L2(l1_reg, l2_reg), bias_regularizer=L1L2(l1_reg, l2_reg))

        if callable(self.cost_transform_layer):
            self.cost_trans_layer = self.cost_transform_layer
        else:
            layer_class = COST_TRANSFORM_LAYERS[self.cost_transform_layer]
            if not max_amount:
                raise ValueError("max_amount must be non-zero number if cost_transform_layer is not set.")
            self.cost_trans_layer = layer_class(max_amount)

        super(CoxRegressionLayer, self).__init__(**kwargs)

    def call(self, inputs):
        embedding, cost = inputs
        h = self.embed_trans_layer(embedding)
        eh = tf.exp(h, 'cox_regression_exp')

        cost = tf.reshape(cost, [-1, 1])
        cost = self.cost_trans_layer([cost, embedding])
        cost = tf.cast(cost, tf.float32)

        logits = tf.multiply(cost, eh)
        return logits

    def compute_output_shape(self, input_shape):
        return (input_shape[0][0], 1)

    def get_config(self):
        config = {
            "embedding_transform_layer": self.embedding_transform_layer,
            "cost_transform_layer": self.cost_transform_layer,
            "max_amount": self.max_amount,
            "l2_reg": self.l2_reg,
            "l1_reg": self.l1_reg,
        }
        base_config = super(CoxRegressionLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))
