# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
import itertools
from tensorflow.python.framework import tensor_shape


class GatedTanhLayer(tf.keras.layers.Layer):
  """
    Model: gated tanh layer

    Paper: Bottom-Up and Top-Down Attention for Image Captioning and Visual Question Answering

    Link: https://arxiv.org/abs/1707.07998

    Author: Peter Anderson, Xiaodong He, Chris Buehler, Damien Teney,  Mark Johnson, Stephen Gould, Lei Zhang

    Developer: anbo

    Date: 2020-09-21

    inputs: tensor, (batch, *, dim)

    output: tensor, (batch, *, hidden_units)

    """
  def __init__(self,
               hidden_units=None,
               l2_reg=0,
               seed=1024,
               transform_inputs=True,
               **kwargs):
    """
        :param hidden_units: int
        :param l2_reg: float
        :param seed: int
        :param transform_inputs: bool
        :param kwargs:
        """
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    self.transform_inputs = transform_inputs
    super(GatedTanhLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    input_size = int(input_shape[-1])
    self.hidden_size = input_size if self.hidden_units is None else self.hidden_units

    if self.transform_inputs:
      self.kernels = [
          self.add_weight(
              name='kernel' + str(i),
              shape=[input_size, self.hidden_size],
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.l2(self.l2_reg),
              trainable=True) for i in range(2)
      ]
      self.bias = [
          self.add_weight(name='bias' + str(i),
                          shape=[
                              self.hidden_size,
                          ],
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True) for i in range(2)
      ]
    else:
      self.kernels = self.add_weight(
          name='kernel',
          shape=[input_size, self.hidden_size],
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.l2(self.l2_reg),
          trainable=True)
      self.bias = self.add_weight(name='bias',
                                  shape=[
                                      self.hidden_size,
                                  ],
                                  initializer=tf.keras.initializers.Zeros(),
                                  trainable=True)

    # from alps_biz.core.layer.activation_layer import Gelu
    # self.act_fn = Gelu()

    super(GatedTanhLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: tensor
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return:
        """
    if self.transform_inputs:
      dense_output = tf.nn.bias_add(
          tf.tensordot(inputs, self.kernels[0], axes=(-1, 0)), self.bias[0])
      dense_act = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(dense_output)
      # dense_act = self.act_fn(dense_output)
      tf.logging.info('GatedTanhLayer: dense_act {}'.format(dense_act))

      gate_output = tf.nn.bias_add(
          tf.tensordot(inputs, self.kernels[1], axes=(-1, 0)), self.bias[1])
      gate_act = tf.keras.layers.Lambda(lambda x: tf.nn.sigmoid(x))(
          gate_output)
      tf.logging.info('GatedTanhLayer: gate_act {}'.format(gate_act))
    else:
      dense_act = inputs

      gate_output = tf.nn.bias_add(
          tf.tensordot(inputs, self.kernels, axes=(-1, 0)), self.bias)
      gate_act = tf.keras.layers.Lambda(lambda x: tf.nn.sigmoid(x))(
          gate_output)
      tf.logging.info('GatedTanhLayer: gate_act {}'.format(gate_act))

    output = tf.keras.layers.Multiply()([dense_act, gate_act])
    tf.logging.info('GatedTanhLayer: output {}'.format(output))

    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1].concatenate(self.hidden_size)

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'transform_inputs': self.transform_inputs
    }
    base_config = super(GatedTanhLayer, self).get_config()
    config.update(base_config)
    return config


class GatedDNNLayer(tf.keras.layers.Layer):
  """
    Model: The gated Multi Layer Perceptron

    Developer: anbo

    Date: 2020-10-09

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_units[-1])``.
        - For instance, for a 2D input with shape ``(batch_size, input_dim)``,
            the output would have shape ``(batch_size, hidden_units[-1])``.
    """
  def __init__(self,
               hidden_units,
               transform_inputs=True,
               l2_reg=0,
               seed=1024,
               **kwargs):
    """
        Args:
            hidden_units: list of positive integer, the layer number and units in each layer.
            activation: Activation function to use.
            l2_reg: float between 0 and 1. L2 regularizer strength applied to the kernel weights matrix.
            dropout_rate: float in [0,1). Fraction of the units to dropout.
            use_bn: bool. Whether use BatchNormalization before activation or not.
            apply_final_act: whether to apply act in final layer
            seed: A Python integer to use as random seed.

        """
    self.hidden_units = hidden_units
    self.seed = seed
    self.l2_reg = l2_reg
    self.transform_inputs = transform_inputs
    super(GatedDNNLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    input_size = input_shape[-1]
    self.num_layers = len(self.hidden_units)
    self.gatedtanh_layers = []

    for i in range(self.num_layers):
      self.gatedtanh_layers.append(
          GatedTanhLayer(self.hidden_units[i],
                         l2_reg=self.l2_reg,
                         seed=self.seed,
                         transform_inputs=self.transform_inputs,
                         name='gatedDNNlayer_gatedtanh_{}th_layer'.format(i)))

    super(GatedDNNLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    deep_input = inputs

    for i in range(self.num_layers):
      deep_input = self.gatedtanh_layers[i](deep_input, training=training)
      tf.logging.info('GatedDNNLayer: {}th layer, deep_input {}'.format(
          i, deep_input))

    return deep_input

  def compute_output_shape(self, input_shape):
    if len(self.hidden_units) > 0:
      input_shape = tensor_shape.TensorShape(input_shape)
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      return input_shape[:-1].concatenate(self.hidden_units[-1])
    else:
      return input_shape

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'transform_inputs': self.transform_inputs
    }
    base_config = super(GatedDNNLayer, self).get_config()
    config.update(base_config)
    return config


class DANLayer(tf.keras.layers.Layer):
  """
    Model: dual attention network layer

    Paper: Dual Attention Networks for Multimodal Reasoning and Matching

    Link: http://static.naver.net/clova/service/clova_ai/research/publications/Dual.Attention.Networks.for.Multimodal.Reasoning.and.Matching.pdf

    Author: Hyeonseob Nam, Jung-Woo Ha, Jeonghee Kim

    Developer: anbo

    Date: 2020-09-21

    inputs: list of tensors, [a, b]
        a: (batch, len, dim)
        b: (batch, dim)

    outputs: 2d tensor, (batch, dim)

    """
  def __init__(self,
               hidden_units,
               l2_reg=0,
               seed=1024,
               text_attention=False,
               **kwargs):
    """
        :param hidden_units: int
        :param l2_reg: float
        :param seed: int
        :param text_attention: bool
        :param kwargs:
        """
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    self.text_attention = text_attention
    super(DANLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    input_size = [int(input_shape[0][-1]), int(input_shape[1][-1])]

    self.kernels = [
        self.add_weight(
            name='kernel' + str(i),
            shape=[input_size[i], self.hidden_units],
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.l2(self.l2_reg),
            trainable=True) for i in range(2)
    ]

    self.kernels.append(
        self.add_weight(
            name='kernel2',
            shape=[self.hidden_units, 1],
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.l2(self.l2_reg)))

    if not self.text_attention:
      self.kernels.append(
          self.add_weight(
              name='kernel3',
              shape=[input_size[0], input_size[0]],
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.l2(self.l2_reg)))

    super(DANLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of tensors, [seq_input, agg_input], seq_input: (batch, len, d), agg_input: (batch, d)
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return:
        """
    seq_input, agg_input = inputs
    seq_hidden_output = tf.tensordot(seq_input, self.kernels[0], axes=(-1, 0))
    seq_hidden_output = tf.nn.tanh(seq_hidden_output)
    tf.logging.info('DANLayer: seq_hidden_output {}'.format(seq_hidden_output))

    agg_hidden_output = tf.tensordot(agg_input, self.kernels[1], axes=(-1, 0))
    agg_hidden_output = tf.nn.tanh(agg_hidden_output)
    tf.logging.info('DANLayer: agg_hidden_output {}'.format(agg_hidden_output))

    element_output = tf.keras.layers.Multiply()(
        [seq_hidden_output, agg_hidden_output])
    attention_weight = tf.tensordot(element_output,
                                    self.kernels[2],
                                    axes=(-1, 0))
    attention_weight = tf.nn.softmax(attention_weight, axis=-1)
    tf.logging.info('DANLayer: attention_weight {}'.format(attention_weight))

    agg_output = tf.matmul(attention_weight, seq_input, transpose_a=True)
    agg_output = tf.squeeze(agg_output, axis=1)
    tf.logging.info('DANLayer: agg_output {}'.format(agg_output))

    if not self.text_attention:
      # visual attention
      agg_output = tf.tensordot(agg_output, self.kernels[3], axes=(-1, 0))
      agg_output = tf.nn.tanh(agg_output)

    return agg_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[-1])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'text_attention': self.text_attention
    }
    base_config = super(DANLayer, self).get_config()
    config.update(base_config)
    return config


class RMDANLayer(tf.keras.layers.Layer):
  """
    Model: r-DAN and m-DAN layer

    Paper: Dual Attention Networks for Multimodal Reasoning and Matching

    Link: http://static.naver.net/clova/service/clova_ai/research/publications/Dual.Attention.Networks.for.Multimodal.Reasoning.and.Matching.pdf

    Author: Hyeonseob Nam, Jung-Woo Ha, Jeonghee Kim

    Developer: anbo

    Date: 2020-09-21

    inputs: list of 3d tensors

    output: 2d tensor

    """
  def __init__(self,
               hidden_units,
               l2_reg=0,
               seed=1024,
               n_dan_layers=2,
               text_attention=True,
               vis_attention=True,
               shared_agg_attention=True,
               **kwargs):
    """
        :param hidden_units: int
        :param l2_reg: float
        :param seed: int
        :param text_attention: bool
        :param vis_attention: bool
        :param shared_agg_attention: bool
        :param n_dan_layers: int
        :param kwargs:
        """
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    self.text_attention = text_attention
    self.vis_attention = vis_attention
    self.shared_agg_attention = shared_agg_attention
    self.n_dan_layers = n_dan_layers
    if self.shared_agg_attention:
      assert (self.vis_attention == True and self.text_attention
              == True), ('Must use vis and text modality inputs together')
    super(RMDANLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    input_size = int(input_shape[0][-1])

    if self.text_attention:
      self.text_dan_layers = [
          DANLayer(hidden_units=self.hidden_units,
                   l2_reg=self.l2_reg,
                   seed=self.seed,
                   text_attention=True,
                   name='text_dan_layer_{}'.format(i))
          for i in range(self.n_dan_layers)
      ]
    if self.vis_attention:
      self.vis_dan_layers = [
          DANLayer(hidden_units=self.hidden_units,
                   l2_reg=self.l2_reg,
                   seed=self.seed,
                   text_attention=False,
                   name='vis_dan_layer_{}'.format(i))
          for i in range(self.n_dan_layers)
      ]

    self.kernels = self.add_weight(
        name='dan_kernel',
        shape=[input_size, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    super(RMDANLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of tensors from multi modality inputs,
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return:
        """
    text_input, vis_input = inputs

    if self.vis_attention:
      vis_agg_input = tf.reduce_mean(vis_input, axis=1, keepdims=False)
      vis_agg_input = tf.tensordot(vis_agg_input, self.kernels, axes=(-1, 0))
      vis_agg_input = tf.nn.tanh(vis_agg_input)
      tf.logging.info('RMDANLayer: vis_agg_input {}'.format(vis_agg_input))

    if self.text_attention:
      text_agg_input = tf.reduce_mean(text_input, axis=1, keepdims=False)
      tf.logging.info('RMDANLayer: text_agg_input {}'.format(text_agg_input))

    if self.shared_agg_attention:
      agg_input = tf.keras.layers.Multiply()([vis_agg_input, text_agg_input])
      tf.logging.info('RMDANLayer: agg_input {}'.format(agg_input))

    agg_output = []
    for i in range(self.n_dan_layers):
      if self.shared_agg_attention:
        vis_dan_output = self.vis_dan_layers[i]([vis_input, agg_input],
                                                training=training)
        text_dan_output = self.text_dan_layers[i]([text_input, agg_input],
                                                  training=training)
        tf.logging.info(
            'RMDANLayer: {}th dan layer, vis_dan_output {}, text_dan_output {} '
            .format(i, vis_dan_output, text_dan_output))

        agg_input += tf.keras.layers.Multiply()(
            [vis_dan_output, text_dan_output])
        tf.logging.info('RMDANLayer: {}th dan layer, agg_input {}'.format(
            i, agg_input))
        if i == self.n_dan_layers - 1:
          agg_output.append(agg_input)
      else:
        vis_agg_input = self.vis_dan_layers[i]([vis_input, vis_agg_input],
                                               training=training)
        text_agg_input = self.text_dan_layers[i]([text_input, text_agg_input],
                                                 training=training)
        agg_input = tf.keras.layers.Multiply()([vis_agg_input, text_agg_input])
        tf.logging.info('RMDANLayer: {}th dan layer, agg_input {}'.format(
            i, agg_input))
        agg_output.append(agg_input)

    agg_summed_output = tf.keras.layers.Add()(
        agg_output) if len(agg_output) > 1 else agg_output[0]
    tf.logging.info(
        'RMDANLayer: agg_summed_output {}'.format(agg_summed_output))
    return agg_summed_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'text_attention': self.text_attention,
        'vis_attention': self.vis_attention,
        'shared_agg_attention': self.shared_agg_attention,
        'n_dan_layers': self.n_dan_layers
    }
    base_config = super(RMDANLayer, self).get_config()
    config.update(base_config)
    return config


class ParallelCoAttentionLayer(tf.keras.layers.Layer):
  """
    Model: parallel co-attention layer

    Paper: Hierarchical Question-Image Co-Attention for Visual Question Answering

    Link: https://papers.nips.cc/paper/6202-hierarchical-question-image-co-attention-for-visual-question-answering.pdf

    Author: Jiasen Lu, Jianwei Yang, Dhruv Batra, Devi Parikh

    Developer: anbo

    Date: 2020-09-21

    inputs: list of 3d tensors, (batch, text_len, d1), (batch, vis_len, d2)

    output: 2d tensor, (batch, d1+d2)

    """
  def __init__(self, hidden_units, l2_reg=0, seed=1024, **kwargs):
    """
        :param hidden_units: int,
        :param l2_reg: float
        :param seed: int
        :param kwargs:
        """
    self.l2_reg = l2_reg
    self.seed = seed
    self.hidden_units = hidden_units
    super(ParallelCoAttentionLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    text_dim, vis_dim = int(input_shape[0][-1]), int(input_shape[1][-1])

    self.weight_b = self.add_weight(
        name='weight_b',
        shape=[text_dim, vis_dim],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.weight_vis = self.add_weight(
        name='weight_vis',
        shape=[vis_dim, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.weight_text = self.add_weight(
        name='weight_text',
        shape=[text_dim, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.weight_vis_attn = self.add_weight(
        name='weight_vis_attn',
        shape=[self.hidden_units, 1],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.weight_text_attn = self.add_weight(
        name='weight_text_attn',
        shape=[self.hidden_units, 1],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    super(ParallelCoAttentionLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of 3d tensors
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return:
        """
    text_input, vis_input = inputs
    # text_input: (batch, text_len, text_dim)
    # vis_input: (batch, vis_len, vis_dim)

    affinity_input = tf.tensordot(text_input, self.weight_b, axes=(-1, 0))
    affinity_input = tf.matmul(affinity_input, vis_input, transpose_b=True)
    affinity_input = tf.nn.tanh(affinity_input)
    # affinity_input: (batch, text_len, vis_len)
    tf.logging.info(
        'ParallelCoAttentionLayer: affinity_input {}'.format(affinity_input))

    text_hidden = tf.tensordot(text_input, self.weight_text, axes=(-1, 0))
    # text_hidden: (batch, text_len, hidden_units)
    tf.logging.info(
        'ParallelCoAttentionLayer: text_hidden {}'.format(text_hidden))
    vis_hidden = tf.tensordot(vis_input, self.weight_vis, axes=(-1, 0))
    # vis_hidden: (batch, vis_len, hidden_units)
    tf.logging.info(
        'ParallelCoAttentionLayer: vis_hidden {}'.format(vis_hidden))

    vis_supplement_hidden = tf.matmul(affinity_input,
                                      text_hidden,
                                      transpose_a=True)
    # vis_supplement_hidden: (batch, vis_len, hidden_units)
    tf.logging.info(
        'ParallelCoAttentionLayer: vis_supplement_hidden {}'.format(
            vis_supplement_hidden))
    text_supplement_hidden = tf.matmul(affinity_input, vis_hidden)
    # text_supplement_hidden: (batch, text_len, hidden_units)
    tf.logging.info(
        'ParallelCoAttentionLayer: text_supplement_hidden {}'.format(
            text_supplement_hidden))

    vis_attn_input = tf.nn.tanh(vis_hidden + vis_supplement_hidden)
    text_attn_input = tf.nn.tanh(text_hidden + text_supplement_hidden)

    vis_attn_hidden = tf.tensordot(vis_attn_input,
                                   self.weight_vis_attn,
                                   axes=(-1, 0))
    vis_attn = tf.nn.softmax(vis_attn_hidden, axis=1)
    # vis_attn_hidden: (batch, vis_len, 1)
    tf.logging.info('ParallelCoAttentionLayer: vis_attn {}'.format(vis_attn))

    text_attn_hidden = tf.tensordot(text_attn_input,
                                    self.weight_text_attn,
                                    axes=(-1, 0))
    text_attn = tf.nn.softmax(text_attn_hidden, axis=1)
    # text_attn_hidden: (batch, text_len, 1)
    tf.logging.info('ParallelCoAttentionLayer: text_attn {}'.format(text_attn))

    text_output = tf.matmul(text_input, text_attn, transpose_a=True)
    text_output = tf.squeeze(text_output, axis=-1)
    vis_output = tf.matmul(vis_input, vis_attn, transpose_a=True)
    vis_output = tf.squeeze(vis_output, axis=-1)
    tf.logging.info(
        'ParallelCoAttentionLayer: text_output {}, \n vis_output {}'.format(
            text_output, vis_output))

    # return text_output, vis_output
    output = tf.keras.layers.Concatenate()([text_output, vis_output])
    return output

  def compute_output_shape(self, input_shape):
    output_dim = input_shape[0][-1] + input_shape[1][-1]
    input_shape_0 = tensor_shape.TensorShape(input_shape[0])
    input_shape_1 = tensor_shape.TensorShape(input_shape[1])
    return input_shape_0[:1].concatenate(output_dim)

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(ParallelCoAttentionLayer, self).get_config()
    config.update(base_config)
    return config


class SpatialMemLayer(tf.keras.layers.Layer):
  """
    Model: spatial memory network layer

    Paper: Ask, Attend and Answer: Exploring Question-Guided Spatial Attention for Visual Question Answering

    Link: https://cs-people.bu.edu/hxu/CVPR2016_VQA_workshop.pdf

    Author: Huijuan Xu, Kate Saenko

    Developer: anbo

    Date: 2020-09-21

    inputs: list of 3d tensors, (batch, text_len, d1), (batch, vis_len, d2)

    output: 2d tensor, (batch, d1+d2)

    """
  def __init__(self, hidden_units, l2_reg=0, seed=1024, **kwargs):
    """
        :param hidden_units: int,
        :param l2_reg: float
        :param seed: int
        :param kwargs:
        """
    self.l2_reg = l2_reg
    self.seed = seed
    self.hidden_units = hidden_units
    super(SpatialMemLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    text_dim, vis_dim = int(input_shape[0][-1]), int(input_shape[1][-1])

    self.vis_weight_a = self.add_weight(
        name='vis_weight_a',
        shape=[vis_dim, text_dim],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.vis_bias_a = self.add_weight(
        name='vis_bias_a',
        shape=[
            text_dim,
        ],
        initializer=tf.keras.initializers.Zeros(),
        trainable=True)

    self.vis_weight_e = self.add_weight(
        name='vis_weight_e',
        shape=[text_dim, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.vis_bias_e = self.add_weight(
        name='vis_bias_e',
        shape=[
            self.hidden_units,
        ],
        initializer=tf.keras.initializers.Zeros(),
        trainable=True)

    self.text_weight_q = self.add_weight(
        name='text_weight_q',
        shape=[text_dim, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.text_bias_q = self.add_weight(
        name='text_bias_q',
        shape=[
            self.hidden_units,
        ],
        initializer=tf.keras.initializers.Zeros(),
        trainable=True)

    self.vis_weight_e2 = self.add_weight(
        name='vis_weight_e2',
        shape=[text_dim, self.hidden_units],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    self.vis_bias_e2 = self.add_weight(
        name='vis_bias_e2',
        shape=[
            self.hidden_units,
        ],
        initializer=tf.keras.initializers.Zeros(),
        trainable=True)

    super(SpatialMemLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of 3d tensors
        :param training: flag, tf.estimator.ModeKeys
        :param kwargs:
        :return:
        """
    text_input, vis_input = inputs
    # text_input: (batch, text_len, text_dim)
    # vis_input: (batch, vis_len, vis_dim)

    vis_hidden_a = tf.nn.bias_add(
        tf.tensordot(vis_input, self.vis_weight_a, axes=(-1, 0)),
        self.vis_bias_a)
    vis_text_c = tf.matmul(text_input, vis_hidden_a, transpose_b=True)
    # vis_text_c : (batch, text_len, vis_len)
    tf.logging.info('SpatialMemLayer: vis_text_c {}'.format(vis_text_c))

    attn_weight_max = tf.nn.softmax(tf.reduce_max(vis_text_c,
                                                  axis=1,
                                                  keepdims=True),
                                    axis=-1)
    # attn_weight_max: (batch, 1, vis_len)
    vis_hidden_e = tf.nn.bias_add(
        tf.tensordot(vis_input, self.vis_weight_e, axes=(-1, 0)),
        self.vis_bias_e)
    vis_attn_s = tf.matmul(attn_weight_max, vis_hidden_e)
    # vis_attn_s: (batch, 1, hidden_units)
    tf.logging.info('SpatialMemLayer: vis_attn_s {}'.format(vis_attn_s))

    text_hidden_e = tf.nn.bias_add(
        tf.tensordot(text_input, self.text_weight_q, axes=(-1, 0)),
        self.text_bias_q)
    # text_hidden_e : (batch, text_len, hidden_units)

    hop_1_output = tf.add(text_hidden_e, vis_attn_s)
    # hop_1_output: (batch, text_len, hidden_units)
    tf.logging.info('SpatialMemLayer: hop_1_output {}'.format(hop_1_output))

    hop_2_c = tf.matmul(vis_hidden_e, hop_1_output, transpose_b=True)
    # hop_2_c : (batch, vis_len, text_len)
    attn_weight_2 = tf.nn.softmax(hop_2_c, axis=1)
    tf.logging.info('SpatialMemLayer: attn_weight_2 {}'.format(attn_weight_2))

    vis_hidden_e_2 = tf.nn.bias_add(
        tf.tensordot(vis_input, self.vis_weight_e2, axes=(-1, 0)),
        self.vis_bias_e2)
    vis_attn_s_2 = tf.matmul(attn_weight_2, vis_hidden_e_2, transpose_a=True)
    # vis_attn_s_2: (batch, text_len, hidden_units)
    tf.logging.info('SpatialMemLayer: vis_attn_s_2 {}'.format(vis_attn_s_2))

    output = tf.keras.layers.Concatenate()([hop_1_output, vis_attn_s_2])
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1].concatenate(self.hidden_units * 2)

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(SpatialMemLayer, self).get_config()
    config.update(base_config)
    return config


class AttentivePoolingLayer(tf.keras.layers.Layer):
  """
    Model: attentive pooling layer

    Paper: Image Matters: Visually modeling user behaviors using Advanced Model Server

    Link: https://arxiv.org/abs/1711.06505

    Author: Tiezheng Ge, Liqin Zhao, Guorui Zhou, Keyu Chen, Shuying Liu, Huimin Yi, Zelin Hu, Bochao Liu,
            Peng Sun, Haoyu Liu, Pengtao Yi, Sui Huang, Zhiqiang Zhang, Xiaoqiang Zhu, Yu Zhang, Kun Gai

    Developer: anbo

    Date: 2020-09-27

    inputs: list of tensors [a, b]
        a: (batch, len, dim)
        b: (batch, dim)

    outputs: 2d tensor, (batch, dim)

    """
  def __init__(self,
               hidden_units=[8, 1],
               activation='relu',
               dropout_rate=0,
               l2_reg=0,
               seed=1024,
               **kwargs):
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    self.activation = activation
    self.dropout_rate = dropout_rate
    super(AttentivePoolingLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    from alps_biz.core.layer.core import DNNLayer
    self.attentive_layer = DNNLayer(hidden_units=self.hidden_units,
                                    activation=self.activation,
                                    l2_reg=self.l2_reg,
                                    dropout_rate=self.dropout_rate,
                                    use_bn=False,
                                    apply_final_act=False,
                                    seed=self.seed)

    super(AttentivePoolingLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: list of tensors, [3d, 2d]
        returns: 2d tensor
        """
    seq_input, query_input = inputs
    if tf.keras.backend.ndim(query_input) == 2:
      query_input = tf.keras.backend.expand_dims(query_input, axis=1)
      tf.logging.info(
          'AttentivePoolingLayer: query_input {}'.format(query_input))

    seq_len = seq_input.get_shape().as_list()[1]
    query_input_3d = tf.keras.backend.repeat_elements(query_input, seq_len, 1)

    attentive_input = tf.keras.layers.Concatenate(axis=-1)(
        [seq_input, query_input_3d])
    tf.logging.info(
        'AttentivePoolingLayer: attentive_input {}'.format(attentive_input))

    attentive_output = self.attentive_layer(attentive_input, training=training)
    # attentive_output: (batch, len, 1)
    tf.logging.info(
        'AttentivePoolingLayer: attentive_output {}'.format(attentive_output))

    attn_weight = tf.nn.softmax(attentive_output, axis=1)
    sum_pool_output = tf.matmul(seq_input, attn_weight, transpose_a=True)
    output = tf.squeeze(sum_pool_output, axis=-1)
    tf.logging.info('AttentivePoolingLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self,):
    config = {
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'activation': self.activation,
        'dropout_rate': self.dropout_rate
    }
    base_config = super(AttentivePoolingLayer, self).get_config()
    config.update(base_config)
    return config


class PRADOAttentionLayer(tf.keras.layers.Layer):
  """
    Model: Projected Attention Layer in PRADO

    Paper: PRADO: Projection Attention Networks for Document Classiﬁcation On-Device

    Link: https://www.aclweb.org/anthology/D19-1506/

    Author: Prabhu Kaliamoorthi, Sujith Ravi, Zornitsa Kozareva

    Developer: anbo

    Date: 2020-10-10

    inputs: 3d tensor, (batch, len, dim)

    output: 3d tensor

    """
  def __init__(self,
               projection_filters=[4, 4, 4],
               projection_kernels=[1, 3, 6],
               attn_filters=[4, 4, 4],
               attn_kernels=[1, 3, 6],
               **kwargs):
    self.projection_filters = projection_filters
    self.projection_kernels = projection_kernels
    self.attn_filters = attn_filters
    self.attn_kernels = attn_kernels
    self.projection_unit = sum(self.projection_filters)
    self.attn_unit = sum(self.attn_filters)
    super(PRADOAttentionLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    self.projection_conv_kernels = []
    self.attn_conv_kernels = []

    for i in range(len(self.projection_filters)):
      self.projection_conv_kernels.append(
          tf.keras.layers.Conv1D(
              filters=self.projection_filters[i],
              kernel_size=self.projection_kernels[i],
              strides=1,
              padding='same',
              activation='relu',
              name='prado_projection_conv1d_layer_{}'.format(i)))

    for i in range(len(self.attn_filters)):
      self.attn_conv_kernels.append(
          tf.keras.layers.Conv1D(filters=self.attn_filters[i],
                                 kernel_size=self.attn_kernels[i],
                                 strides=1,
                                 padding='same',
                                 activation='relu',
                                 name='prado_attn_conv1d_layer_{}'.format(i)))

    super(PRADOAttentionLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: 3d tensor, (batch, len, dim)
        :param training:
        :param kwargs:
        :return:
        """
    projection_conv_outputs, attn_conv_outputs = [], []

    for i in range(len(self.projection_filters)):
      projection_conv_outputs.append(self.projection_conv_kernels[i](inputs))
      # outputs[i]: (batch, len, filter[i])
      tf.logging.info(
          'PRADOAttentionLayer: projection conv outputs {} {}'.format(
              i, projection_conv_outputs[-1]))

    for i in range(len(self.attn_filters)):
      attn_conv_outputs.append(self.attn_conv_kernels[i](inputs))
      # outputs[i]: (batch, len, filter[i])
      tf.logging.info(
          'PRADOAttentionLayer: attention conv outputs {} {}'.format(
              i, attn_conv_outputs[-1]))

    F_tensor = tf.keras.layers.Concatenate(
        axis=-1)(projection_conv_outputs) if len(
            projection_conv_outputs) > 1 else projection_conv_outputs[0]
    tf.logging.info('PRADOAttentionLayer: F_tensor {}'.format(F_tensor))

    W_tensor = tf.keras.layers.Concatenate(axis=-1)(attn_conv_outputs) if len(attn_conv_outputs) > 1 else \
    attn_conv_outputs[0]
    tf.logging.info('PRADOAttentionLayer: W_tensor {}'.format(W_tensor))
    A_tensor = tf.nn.softmax(W_tensor, axis=1)

    output = tf.matmul(F_tensor, A_tensor, transpose_a=True)
    tf.logging.info('PRADOAttentionLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    output_shape_0 = input_shape[:1].concatenate(self.projection_unit)
    return output_shape_0.concatenate(self.attn_unit)

  def get_config(self):
    config = {
        'projection_filters': self.projection_filters,
        'projection_kernels': self.projection_kernels,
        'attn_filters': self.attn_filters,
        'attn_kernels': self.attn_kernels
    }
    base_config = super(PRADOAttentionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class CGCGatingNetworkLayer(tf.keras.layers.Layer):
  """
    Model: gating network in Customized Gate Control (CGC)

    Paper: Progressive Layered Extraction (PLE): A Novel Multi-Task Learning (MTL) Model for Personalized Recommendations

    Link: dl.acm.org/doi/10.1145/3383313.3412236

    Author: Hongyan Tang, Junning Liu, Ming Zhao, Xudong Gong

    Developer: anbo

    Date: 2020-10-10

    inputs:  task_expert_input: (batch, n_experts_1, dim_1)
         shared_expert_input: (batch, n_experts_2, dim_1)
         input: (batch, dim)

    output: (batch, dim_1)

    """
  def __init__(self, l2_reg=0, seed=1024, **kwargs):
    self.l2_reg = l2_reg
    self.seed = seed

    super(CGCGatingNetworkLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    dim = int(input_shape[2][-1])
    n_experts_1, n_experts_2 = int(input_shape[0][1]), int(input_shape[1][1])
    total_experts = n_experts_1 + n_experts_2

    self.weight_w = self.add_weight(
        name='weight_w',
        shape=[dim, total_experts, 1],
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.l2(self.l2_reg),
        trainable=True)

    super(CGCGatingNetworkLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        :param inputs: list of 3 tensors
        :param training:
        :param kwargs:
        :return: (batch, dim_1)
        """
    task_expert_input, shared_expert_input, input = inputs
    # task_expert_input: (batch, n_experts_1, dim_1)
    # shared_expert_input: (batch, n_experts_2, dim_1)
    # input: (batch, dim)

    combined_input = tf.keras.layers.Concatenate(axis=1)(
        [task_expert_input, shared_expert_input])
    # combined_input: (batch, total_experts, dim_1)
    tf.logging.info(
        'CGCGatingNetworkLayer: combined_input {}'.format(combined_input))

    gate_output = tf.tensordot(input, self.weight_w, axes=(-1, 0))
    gate_act = tf.nn.softmax(gate_output, axis=1)
    # gate_act: (batch, total_experts, 1)
    tf.logging.info('CGCGatingNetworkLayer: gate_act {}'.format(gate_act))

    scaled_output = tf.matmul(combined_input, gate_act, transpose_a=True)
    # scaled_output: (batch, dim_1, 1)
    scaled_output = tf.squeeze(scaled_output, axis=-1)
    tf.logging.info(
        'CGCGatingNetworkLayer: scaled_output {}'.format(scaled_output))
    return scaled_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self,):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(CGCGatingNetworkLayer, self).get_config()
    config.update(base_config)
    return config


class ParallelDNNLayer(tf.keras.layers.Layer):
  """
    Model: The Parallel Multi Layer Perceptron

    Developer: anbo

    Date: 2019-11-29

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
       3d tensor, (batch, len, dim)
    """
  def __init__(self,
               hidden_units,
               activation='relu',
               l2_reg=0,
               dropout_rate=0,
               use_bn=False,
               apply_final_act=True,
               seed=1024,
               n_experts=2,
               **kwargs):
    """
        Args:
            hidden_units: list of positive integer, the layer number and units in each layer.
            activation: Activation function to use.
            l2_reg: float between 0 and 1. L2 regularizer strength applied to the kernel weights matrix.
            dropout_rate: float in [0,1). Fraction of the units to dropout.
            use_bn: bool. Whether use BatchNormalization before activation or not.
            apply_final_act: whether to apply act in final layer
            seed: A Python integer to use as random seed.

        """
    self.hidden_units = hidden_units
    self.activation = activation
    self.dropout_rate = dropout_rate
    self.seed = seed
    self.l2_reg = l2_reg
    self.use_bn = use_bn
    self.apply_final_act = apply_final_act
    self.n_experts = n_experts
    super(ParallelDNNLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    input_size = input_shape[-1]
    hidden_units = [int(input_size)] + list(self.hidden_units)

    self.kernels = [
        self.add_weight(
            name='kernel' + str(i),
            shape=[hidden_units[i], hidden_units[i + 1], self.n_experts],
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.l2(self.l2_reg),
            trainable=True) for i in range(len(self.hidden_units))
    ]
    self.bias = [
        self.add_weight(name='bias' + str(i),
                        shape=[self.hidden_units[i], self.n_experts],
                        initializer=tf.keras.initializers.Zeros(),
                        trainable=True) for i in range(len(self.hidden_units))
    ]

    if self.use_bn:
      self.bn_layers = [
          tf.keras.layers.BatchNormalization(name='bn_layer_{}'.format(i))
          for i in range(len(self.hidden_units))
      ]

    if self.dropout_rate is not None and self.dropout_rate > 0:
      self.dropout_layers = [
          tf.keras.layers.Dropout(self.dropout_rate,
                                  seed=self.seed + i,
                                  name='dropout_layer_{}'.format(i))
          for i in range(len(self.hidden_units))
      ]

    self.activation_layers = [
        tf.keras.layers.Activation(self.activation,
                                   name='act_layer_{}'.format(i))
        for i in range(len(self.hidden_units))
    ]

    super(ParallelDNNLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    deep_input = inputs

    for i in range(len(self.hidden_units)):
      fc = tf.tensordot(deep_input, self.kernels[i], axes=(-1, 0))
      fc = fc + self.bias[i]
      # fc: (batch, dim, n_experts)
      fc = tf.keras.backend.permute_dimensions(fc, pattern=[0, 2, 1])
      tf.logging.info('ParallelDNNLayer: fc {}'.format(fc))

      if self.use_bn:
        fc = self.bn_layers[i](fc, training=training)

      if i < len(self.hidden_units) - 1 or self.apply_final_act:
        fc = self.activation_layers[i](fc)

      if self.dropout_rate is not None and self.dropout_rate > 0:
        fc = self.dropout_layers[i](fc, training=training)
      deep_input = fc

    return deep_input

  def compute_output_shape(self, input_shape):
    if len(self.hidden_units) > 0:
      input_shape = tensor_shape.TensorShape(input_shape)
      input_shape = input_shape.with_rank_at_least(2)
      if tensor_shape.dimension_value(input_shape[-1]) is None:
        raise ValueError(
            'The innermost dimension of input_shape must be defined, but saw: %s'
            % input_shape)
      output_shape_0 = input_shape[:-1].concatenate(self.n_experts)
      return output_shape_0.concatenate(self.hidden_units[-1])
    else:
      input_shape

  def get_config(self):
    config = {
        'activation': self.activation,
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'use_bn': self.use_bn,
        'dropout_rate': self.dropout_rate,
        'apply_final_act': self.apply_final_act,
        'seed': self.seed,
        'n_experts': self.n_experts
    }
    base_config = super(ParallelDNNLayer, self).get_config()
    config.update(base_config)
    return config


class BiLinearInteractionLayer(tf.keras.layers.Layer):
  """
    Model: BiLinear Interaction Layer in FiBiNet

    Paper: FiBiNET- Combining Feature Importance and Bilinear feature Interaction for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/1905.09433

    Author: Tongwen Huang, Zhiqi Zhang, Junlin Zhang

    Developer: anbo

    Date: 2020-10-12

    attn = V

    inputs: (batch, seq_len, dim)

    return: (batch, seq_len * (seq_len-1) // 2, dim)
    """
  def __init__(self,
               bilinear_type='field_all',
               l2_reg=0.001,
               seed=1024,
               **kwargs):
    self.l2_reg = l2_reg
    self.seed = seed
    self.bilinear_type = bilinear_type
    super(BiLinearInteractionLayer, self).__init__(**kwargs)

  def build(self, input_shape):

    hidden_size = int(input_shape[-1])
    self.seq_len = int(input_shape[1])

    if self.bilinear_type == 'field_all':
      self.weight = self.add_weight(
          name='weight',
          shape=(hidden_size, hidden_size),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)
    elif self.bilinear_type == 'field_each':
      self.weight = [
          self.add_weight(
              name='weight_{}'.format(i),
              shape=(hidden_size, hidden_size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True) for i in range(self.seq_len)
      ]
    elif self.bilinear_type == 'field_interaction':
      self.weight = [
          self.add_weight(
              name='weight_{}_{}'.format(i, j),
              shape=(hidden_size, hidden_size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True)
          for i, j in itertools.combinations(range(self.seq_len), 2)
      ]
    else:
      raise ValueError("Cannot find a supported bilinear_type {}".format(
          self.bilinear_type))

    super(BiLinearInteractionLayer, self).build(input_shape)

  def field_wise_func(self, field_input_1, field_input_2, n_fields):
    """
        :param field_input_1: 3d tensor, (batch, len, dim)
        :param field_input_2: 3d tensor, (batch, len, dim)
        :param n_fields: int
        :return:
        """
    left, right = [], []
    for i, j in itertools.combinations(list(range(n_fields)), 2):
      left.append(i)
      right.append(j)
    tf.logging.info(
        'BiLinearInteractionLayer: field_wise_func, left {},\n, right {}'.
        format(left, right))

    emb_left = tf.gather(params=field_input_1, indices=left, axis=1)
    tf.logging.info('BiLinearInteractionLayer: emb_left {}'.format(emb_left))
    emb_right = tf.gather(params=field_input_2, indices=right, axis=1)
    tf.logging.info('BiLinearInteractionLayer: emb_right {}'.format(emb_right))

    emb_prob = tf.multiply(emb_left, emb_right)
    tf.logging.info('BiLinearInteractionLayer: emb_prob {}'.format(emb_prob))
    return emb_prob

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (batch, seq_len, dim)
        returns: (batch, seq_len * (seq_len-1) // 2, dim)
        """
    if self.bilinear_type == 'field_all':
      attn_weight = tf.tensordot(inputs, self.weight, axes=[-1, 0])
      output = self.field_wise_func(attn_weight, inputs, self.seq_len)
    elif self.bilinear_type == 'field_each':
      #attn_weight = [tf.tensordot(inputs, self.weight[i], axes=[-1, 0]) for i in range(self.seq_len)]
      pass
    elif self.bilinear_type == 'field_interaction':
      pass
    else:
      raise NotImplementedError

    return output

  def compute_output_shape(self, input_shape):
    # return (input_shape[0], self.seq_len * (self.seq_len - 1) // 2, input_shape[-1])
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(
        tensor_shape.TensorShape(
            [self.seq_len * (self.seq_len - 1) // 2, input_shape[-1]]))

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'bilinear_type': self.bilinear_type
    }
    base_config = super(BiLinearInteractionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))
