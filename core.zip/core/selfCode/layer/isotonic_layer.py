# coding:utf-8
# @Author: yunjian
# @Date: 2019-11-26
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf
from tensorflow.keras.initializers import RandomNormal, Zeros
from tensorflow.keras.layers import Dense, Flatten, LeakyReLU, Layer
from alps_biz.core.common.isotonic_utils import create_amount_encoding


class IsotonicLayer(Layer):
    """A layer of which the output tensor monotoniclly increases with the amount input.

    More details can refer to 
    https://yuque.antfin-inc.com/docs/share/b71ea6a2-2120-457f-aa21-d5086c908338#

    author: buli, yunjian

    """
    def __init__(self, n_hidden_units, uplift_weight_prior, amount_bucket_num,
                 **kwargs):
        """
        Args:
            n_hidden_units: A integer for the hidden unit number of the first
                dense layer.
            uplift_weight_prior: A float number for the prior value of uplift
                weight.
            amount_bucket_num: The dimension of the dense layer for uplift
                weight.

        """
        self.uplift_weight_prior = uplift_weight_prior
        self.amount_bucket_num = amount_bucket_num
        self.n_hidden_units = n_hidden_units
        self.details = {}
        super(IsotonicLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        """
        Args:
            input_shape: the input shape of this layer. See tf.keras.layer.Layer.build for more details.

        """
        self.dense0 = Dense(self.n_hidden_units,
                            kernel_initializer=RandomNormal(0, 0.01),
                            bias_initializer=Zeros(),
                            activation='relu')
        self.dense1_uplift = Dense(self.amount_bucket_num,
                                   kernel_initializer=Zeros(),
                                   bias_initializer=Zeros(),
                                   activation='softplus')
        self.dense_offset = Dense(1,
                                  kernel_initializer=RandomNormal(0, 0.01),
                                  bias_initializer=RandomNormal(0, 0.01),
                                  activation=LeakyReLU(0.2))
        self.h_1_offset_centralization = self.add_weight(
            "h_1_offset_centralization", shape=(1, ), initializer=Zeros())
        self.flatten = Flatten()

    def call(self, input_list):
        """
        Args:
            input_list: input_list contains three tensors,
                non_amount_embedding: the embedding tensor of shape (batch_size, embedding_dim).
                amount_input: the numeric tensor of shape (batch_size, 1).
                amount_buckets: the numeric tensor of shape (batch_size, self.amount_bucket_num).

        """
        # should return self.buckets and self.amount_bucket_incs
        non_amount_embedding, amount_input, amount_buckets = input_list

        # Step 1.0: non-linear feature transform
        h_0 = self.dense0(non_amount_embedding)
        h_0_uplift = h_0
        with tf.name_scope('non-amount-transform'):
            h_1_uplift = self.dense1_uplift(h_0_uplift)
            h_1_base = h_1_uplift + self.uplift_weight_prior
            h_1_offset = self.dense_offset(h_0)
            bias_1_term = self.flatten(h_1_offset +
                                       self.h_1_offset_centralization)
            h_1 = h_1_base[:, 1:]
            h_1 = tf.concat([bias_1_term, h_1], axis=1)

        # Step 2.1: create amount feature embedding
        with tf.name_scope('amount-embedding'):
            amount_encoding_part, _ = create_amount_encoding(
                amount_input, amount_buckets)

        # Step 3.2: build model layer 2: learn for isotonic lr
        with tf.name_scope('isotonic-lr'):
            bias_2 = 0
            z_2 = tf.reduce_sum(tf.multiply(h_1, amount_encoding_part),
                                axis=1) + bias_2
            h_2 = tf.nn.sigmoid(z_2)

            h_1_smoothed = h_1
            h_2_smoothed = h_2

        self.details = locals()
        return [h_2_smoothed, h_1_base]

    def compute_output_shape(self, input_shape):
        """
        Args:
            input_shape: the input shape of this layer. See `tf.keras.layer.Layer.compute_output_shape`
                for more details.

        """
        return [(None, ), (None, self.amount_bucket_num)]

    def get_config(self):
        config = {
            "uplift_weight_prior": self.uplift_weight_prior,
            "amount_bucket_num": self.amount_bucket_num,
            "n_hidden_units": self.n_hidden_units,
        }
        base_config = super(IsotonicLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))
