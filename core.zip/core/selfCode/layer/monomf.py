# coding:utf-8
# @copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.
import tensorflow as tf
from tensorflow.keras.layers import Dense, Dot, Layer
from alps_biz.core.common.isotonic_utils import create_amount_buckets_and_incs, create_amount_encoding


COST_INPUT_NAME = "cost"


class MonotonicEmbedding(Layer):
    """MonotonicEmbedding is a layer which takes a one-hot input vector and returns an embedding vector which
    is monotonic with respect to the one-hot input vector.

    Note that MonotonicEmbedding uses leaky relu. Thus if monotonicity is important to your scene,
    set `leaky_relu_alpha` to a small number or zero.

    .. code-block:: python

        input = np.array([[1, 0, 0], [0, 1, 0]])
        layer = MonotonicEmbedding(8)
        embedding = layer(input)

    """
    def __init__(self, embedding_dim, leaky_relu_alpha=0.0001, **kwargs):
        """
        Args:
            embedding_dim: The dimension of output embedding vectors.
            leaky_relu_alpha: The slope of leaky relu.

        """
        super(MonotonicEmbedding, self).__init__(**kwargs)
        self.embedding_dim = embedding_dim
        self.kernel = None
        self.leaky_relu_alpha = leaky_relu_alpha

    def build(self, input_shape):
        self.kernel = self.add_weight("kernel", shape=[int(input_shape[-1]), self.embedding_dim], initializer='uniform', dtype=tf.float32)

    def call(self, inputs, **kwargs):
        inputs = tf.cast(inputs, tf.float32)
        last = self.kernel[0]
        embed_list = [last]
        for i in range(int(self.kernel.shape[0])):
            if i > 0:
                last += tf.maximum(
                    self.leaky_relu_alpha * self.kernel[i], self.kernel[i])
                embed_list.append(last)
        embed_table = tf.stack(embed_list)
        return tf.matmul(inputs, embed_table)

    def compute_output_shape(self, input_shape):
        return (input_shape[0], self.embedding_dim)

    def get_config(self):
        config = {
            "embedding_dim": self.embedding_dim,
            "leaky_relu_alpha": self.leaky_relu_alpha,
        }
        base_config = super(MonotonicEmbedding, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class MonoMFLayer(Layer):
    """MonoMF is a Keras layer which takes a user embedding and a cost scala, and calculates a logits.

    The computational logic can refer to
    https://yuque.antfin-inc.com/docs/share/e2b38683-d005-4e5f-a02f-bb31d281c058?#91966b24

    """
    def __init__(self, cost_vocabulary_list, cost_embedding_dim, monotonic_embed_alpha=0.0001, **kwargs):
        """
        Args:
            cost_vocabulary_list: A list of cost levels.
            cost_embedding_dim: The embedding dimension of cost.
            monotonic_embed_alpha: The leaky relu alpha of monotonic embedding layer.

        """
        super(MonoMFLayer, self).__init__(**kwargs)
        self.cost_vocabulary_list = cost_vocabulary_list
        self.cost_embedding_dim = cost_embedding_dim
        self.monotonic_embed_alpha = monotonic_embed_alpha

    def build(self, input_shape):
        self.dense1 = Dense(self.cost_embedding_dim, activation='sigmoid', name='user_embed')
        self.dense2 = Dense(1, name='user_cost_0')
        self.dot_layer = Dot(axes=1)
        self.mono_embedding_layer = MonotonicEmbedding(self.cost_embedding_dim, self.monotonic_embed_alpha)

    def call(self, inputs):
        user_embed, cost_input = inputs
        if cost_input.dtype == tf.string:
            cost_input = tf.string_to_number(cost_input, tf.float32)
        else:
            cost_input = tf.cast(cost_input, tf.float32)
        cost_buckets, _ = create_amount_buckets_and_incs(self.cost_vocabulary_list)
        _, cost_one_hot = create_amount_encoding(cost_input, cost_buckets)
        user_embed = self.dense1(user_embed)
        cost_embed = self.mono_embedding_layer(cost_one_hot)
        tf.summary.histogram('cost_embed', cost_embed)
        for i in range(int(self.mono_embedding_layer.kernel.shape[0])):
            tf.summary.histogram('kernel_' + str(i), self.mono_embedding_layer.kernel[i])

        logits = self.dot_layer([cost_embed, user_embed])
        user_cost_0 = self.dense2(user_embed)
        logits = logits + user_cost_0
        return logits

    def compute_output_shape(self, input_shape):
        return (input_shape[0][0], 1)

    def get_config(self):
        config = {
            "cost_vocabulary_list": self.cost_vocabulary_list,
            "cost_embedding_dim": self.cost_embedding_dim,
            "monotonic_embed_alpha": self.monotonic_embed_alpha,
        }
        base_config = super(MonoMFLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))
