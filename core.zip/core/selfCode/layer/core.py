# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape

class DNNLayer(tf.keras.layers.Layer):
    """
    Model: The Multi Layer Perceptron

    Developer: anbo

    Date: 2019-11-29

    Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``.
        - The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

    Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_units[-1])``.
        - For instance, for a 2D input with shape ``(batch_size, input_dim)``,
            the output would have shape ``(batch_size, hidden_units[-1])``.
    """

    def __init__(self, hidden_units, activation='relu', l2_reg=0, dropout_rate=0, use_bn=False, apply_final_act=True, seed=1024, **kwargs):
        """
        Args:
            hidden_units: list of positive integer, the layer number and units in each layer.
            activation: Activation function to use.
            l2_reg: float between 0 and 1. L2 regularizer strength applied to the kernel weights matrix.
            dropout_rate: float in [0,1). Fraction of the units to dropout.
            use_bn: bool. Whether use BatchNormalization before activation or not.
            apply_final_act: whether to apply act in final layer
            seed: A Python integer to use as random seed.

        """
        self.hidden_units = hidden_units
        self.activation = activation
        self.dropout_rate = dropout_rate
        self.seed = seed
        self.l2_reg = l2_reg
        self.use_bn = use_bn
        self.apply_final_act = apply_final_act
        self.hidden_outputs = []
        super(DNNLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        input_size = input_shape[-1]
        hidden_units = [int(input_size)] + list(self.hidden_units)

        self.kernels = [self.add_weight(name='kernel' + str(i),
                                        shape=[hidden_units[i], hidden_units[i + 1]],
                                        initializer=tf.keras.initializers.he_normal(seed=self.seed),
                                        regularizer=tf.keras.regularizers.l2(self.l2_reg),
                                        trainable=True)
                        for i in range(len(self.hidden_units))]
        self.bias = [self.add_weight(name='bias' + str(i),
                                     shape=[self.hidden_units[i], ],
                                     initializer=tf.keras.initializers.Zeros(),
                                     trainable=True)
                     for i in range(len(self.hidden_units))]

        if self.use_bn:
            self.bn_layers = [tf.keras.layers.BatchNormalization(name='bn_layer_{}'.format(i)) for i in range(len(self.hidden_units))]

        if self.dropout_rate is not None and self.dropout_rate > 0:
            self.dropout_layers = [tf.keras.layers.Dropout(self.dropout_rate,
                                                           seed=self.seed + i, name='dropout_layer_{}'.format(i))
                                   for i in range(len(self.hidden_units))]

        self.activation_layers = [tf.keras.layers.Activation(self.activation, name='act_layer_{}'.format(i)) for i in range(len(self.hidden_units))]

        super(DNNLayer, self).build(input_shape)

    def call(self, inputs, training=None, **kwargs):
        deep_input = inputs

        for i in range(len(self.hidden_units)):
            fc = tf.nn.bias_add(tf.tensordot(deep_input, self.kernels[i], axes=(-1, 0)), self.bias[i])
            if self.use_bn:
                fc = self.bn_layers[i](fc, training=training)

            if i < len(self.hidden_units)-1 or self.apply_final_act:
                fc = self.activation_layers[i](fc)

            if self.dropout_rate is not None and self.dropout_rate > 0:
                fc = self.dropout_layers[i](fc, training=training)
            deep_input = fc
            self.hidden_outputs.append(fc)

        return deep_input

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape)
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError('The innermost dimension of input_shape must be defined, but saw: %s' % input_shape)
        elif len(self.hidden_units) > 0:
            return input_shape[:-1].concatenate(self.hidden_units[-1])
        else:
            return input_shape

    def get_config(self, ):
        config = {
            'activation': self.activation,
            'hidden_units': self.hidden_units,
            'l2_reg': self.l2_reg,
            'use_bn': self.use_bn,
            'dropout_rate': self.dropout_rate,
            'apply_final_act': self.apply_final_act,
            'seed': self.seed
        }
        base_config = super(DNNLayer, self).get_config()
        config.update(base_config)
        return config
