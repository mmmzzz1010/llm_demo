# coding:utf-8
# @Copyright: Alipay.com Inc. Copyright (c) 2004-2019 All Rights Reserved.

import tensorflow as tf
import numpy as np
import unittest
from alps_biz.tests.utils import layer_test
from alps_biz.core.layer.cox_regression_layer import CoxRegressionLayer, DefaultCostTransformLayer, CostOffsetLearningLayer


class CoxRegressionLayerTest(unittest.TestCase):
    def test_cox_regression_layer(self):
        model_params = {
            "embedding_transform_layer": None, 
            "cost_transform_layer": None,
            "max_amount": 9900.0,
            "l2_reg": 0.001,
        }
        np.random.seed(1)
        user_embed = np.random.rand(2, 5).astype(np.float32)
        cost = np.array([[188], [288]])
        input_data = [user_embed, cost]
        expected_output = np.array([[0.03704438], [0.05619861]])
        layer_test(
            CoxRegressionLayer,
            {"CoxRegressionLayer": CoxRegressionLayer},
            model_params,
            input_data=input_data,
            expected_output=expected_output,
        )

    def test_default_cost_transform_layer(self):
        max_amount = 0.1
        model_params = {"max_amount": max_amount}
        np.random.seed(1)
        cost = np.random.rand(2, 5).astype(np.float32)
        embed = np.random.rand(2, 5).astype(np.float32)
        input_data = [cost, embed]
        expected_output = cost / max_amount
        layer_test(
            DefaultCostTransformLayer,
            {"DefaultCostTransformLayer": DefaultCostTransformLayer},
            model_params,
            input_data=input_data,
            expected_output=expected_output,
        )

    def test_cost_offset_learning_layer(self):
        max_amount = 0.1
        model_params = {"max_amount": max_amount}
        np.random.seed(1)
        cost = np.random.rand(2, 5).astype(np.float32)
        embed = np.random.rand(2, 5).astype(np.float32)
        input_data = [cost, embed]
        expected_output = np.array(
            [[4.1904373, 7.223463, 0.02136139, 3.0435433, 1.4877765],
             [0.96540636, 1.9046224, 3.4976277, 4.009695, 5.430188]]
        )
        layer_test(
            CostOffsetLearningLayer,
            {"CostOffsetLearningLayer": CostOffsetLearningLayer},
            model_params,
            input_data=input_data,
            expected_output=expected_output,
        )


if __name__ == "__main__":
    unittest.main()

