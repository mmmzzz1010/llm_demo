# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape


class AttnAggregationLayer(tf.keras.layers.Layer):
  """
    Model: Attention Agggregation Layer

    Paper: STAN: Spatio-Temporal Attention Network for Next Location Recommendation

    Link: https://arxiv.org/abs/2102.04095

    Author: Yingtao Luo, Qiang Liu, Zhaocheng Liu

    Developer: anbo

    Date: 2021-04-08

    inputs:  tuple, (hist_input, spatial_temporal_delta)
            hist_input: (batch, len, dim)
            spatial_temporal_delta: (batch, len, len)

    returns: (batch, len, hidden_size)
    """
  def __init__(self, hidden_size=16, l2_reg=0.001, seed=11, **kwargs):
    super(AttnAggregationLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.hidden_size = hidden_size
    self.seed = seed

  def build(self, input_shape):
    self.dim = int(input_shape[0][-1])
    self.seq_len = int(input_shape[0][1])

    self.kernels, self.bias = [], []

    for i in range(3):
      self.kernels.append(
          self.add_weight(
              name='weight_{}'.format(i),
              shape=(self.dim, self.hidden_size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))

      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(self.hidden_size,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    self.upper_triangle_mask = tf.matrix_band_part(
        tf.ones([self.seq_len, self.seq_len]), 0, 1)

    super(AttnAggregationLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: tuple, (hist_input, spatial_temporal_delta)
            hist_input: (batch, len, dim)
            spatial_temporal_delta: (batch, len, len)

        returns: (batch, len, hidden_size)
        """
    hist_input, spatial_temporal_delta = inputs
    query, key, value = [
        tf.keras.backend.bias_add(
            tf.keras.backend.dot(hist_input, self.kernels[i]), self.bias[i])
        for i in range(3)
    ]
    key = tf.keras.backend.permute_dimensions(key, (0, 2, 1))
    tf.logging.info('AttnAggregationLayer: key {}'.format(key))

    energy = tf.matmul(query, key)
    scaled_energy = (energy + spatial_temporal_delta) / tf.sqrt(
        tf.cast(self.dim, tf.float32))
    # scaled_energy: (batch, len, len)
    score = tf.nn.softmax(scaled_energy, axis=-1)
    tf.logging.info('AttnAggregationLayer: score {}'.format(score))
    masked_score = tf.keras.layers.Multiply()(
        [score, self.upper_triangle_mask[tf.newaxis, :, :]])

    output = tf.matmul(masked_score, value)
    # output: (batch, len, hidden_size)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1].concatenate(self.hidden_size)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'hidden_size': self.hidden_size
    }
    base_config = super(AttnAggregationLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class AttnMatchLayer(tf.keras.layers.Layer):
  """
    Model: Attention Match Layer

    Paper: STAN: Spatio-Temporal Attention Network for Next Location Recommendation

    Link: https://arxiv.org/abs/2102.04095

    Author: Yingtao Luo, Qiang Liu, Zhaocheng Liu

    Developer: anbo

    Date: 2021-04-08

    inputs: tuple, (candidate_lbs, trajectory_hidden, spatial_temporal_matrix)
            candidate_lbs: (batch, n, d)
            trajectory_hidden: (batch, l, d)
            spatial_temporal_matrix: (batch, l, n)

    return: (batch, l)
    """
  def __init__(self, l2_reg=0.001, seed=11, **kwargs):
    super(AttnMatchLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    self.seq_len = int(input_shape[0][1])
    self.dim = int(input_shape[0][-1])

    self.kernel = self.add_weight(
        name='weight',
        shape=(self.seq_len, 1),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(AttnMatchLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: tuple, (candidate_lbs, trajectory_hidden, spatial_temporal_matrix)
            candidate_lbs: (batch, n, d)
            trajectory_hidden: (batch, l, d)
            spatial_temporal_matrix: (batch, l, n)

        returns: (batch, l)
        """
    candidate_lbs, trajectory_hidden, spatial_temporal_matrix = inputs
    candidate_lbs = tf.keras.backend.permute_dimensions(
        candidate_lbs, (0, 2, 1))
    energy = tf.matmul(trajectory_hidden, candidate_lbs)
    scaled_energy = (energy + spatial_temporal_matrix) / tf.sqrt(
        tf.cast(self.dim, tf.float32))
    score = tf.nn.softmax(scaled_energy, axis=-1)
    # score: (batch, l, n)

    output = tf.tensordot(score, self.kernel, axes=(-1, 0))
    output = tf.squeeze(output, axis=-1)
    # output: (batch, l)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[-1])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1]

  def get_config(self):
    config = {'l2_reg': self.l2_reg, 'seed': self.seed}
    base_config = super(AttnMatchLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class CoActionLayer(tf.keras.layers.Layer):
  """
    Model: co-action Layer

    Paper: CAN: Revisiting Feature Co-Action for Click-Through Rate Prediction

    Link: https://arxiv.org/abs/2011.05625

    Author: Guorui Zhou, Weijie Bian, et.al

    Developer: anbo

    Date: 2021-04-08

    inputs: inputs: tuple, (input_a, input_b)
            input_a: (batch, dim1)
            input_b: (batch, dim2)

            dim2 >> dim1

    return: (batch, dim)
    """
  def __init__(self,
               hidden_units=[8, 4],
               apply_final_act=False,
               use_bias=True,
               **kwargs):
    super(CoActionLayer, self).__init__(**kwargs)
    self.hidden_units = hidden_units
    self.apply_final_act = apply_final_act
    self.use_bias = use_bias

  def build(self, input_shape):
    input_size = input_shape[0][-1]
    self.hidden_size = [int(input_size)] + list(self.hidden_units)
    self.n_layers = len(self.hidden_size) - 1
    self.total_params = sum([
        (self.hidden_size[i] + 1) *
        self.hidden_size[i + 1] if self.use_bias else self.hidden_size[i] *
        self.hidden_size[i + 1] for i in range(self.n_layers)
    ])
    tf.logging.info('CoActionLayer: self.total_params {}'.format(
        self.total_params))

    input_b_size = int(input_shape[1][-1])
    assert (input_b_size >= self.total_params), (
        'input_b last unit must be at least of {}'.format(self.total_params))

    super(CoActionLayer, self).build(input_shape)

  def reshape_weight_bias(self, input):
    self.kernels, self.bias = [], []
    index = 0
    for i in range(self.n_layers):
      prev_unit = self.hidden_size[i]
      last_unit = self.hidden_size[i + 1]
      weight = tf.reshape(input[:, index:index + prev_unit * last_unit],
                          (-1, prev_unit, last_unit))
      self.kernels.append(weight)
      index += prev_unit * last_unit

      if self.use_bias:
        bias = tf.reshape(input[:, index:index + last_unit],
                          (-1, 1, last_unit))
        self.bias.append(bias)
        index += last_unit

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: tuple, (input_a, input_b)
            input_a: (batch, dim1)
            input_b: (batch, dim2)

        returns: (batch, l)
        """
    input_a, input_b = inputs

    # split input_b to get weights and bias
    self.reshape_weight_bias(input_b)

    # perform mlp
    need_reshape_back = False
    if tf.keras.backend.ndim(input_a) <= 2:
      hidden_output = tf.expand_dims(input_a, axis=1)
      need_reshape_back = True
    else:
      hidden_output = input_a

    for i in range(len(self.kernels)):
      hidden_output = tf.matmul(hidden_output, self.kernels[i])
      if self.use_bias:
        hidden_output += self.bias[i]

      tf.logging.info('CoActionLayer: layer {}, hidden_output {}'.format(
          i, hidden_output))

      if i < len(self.kernels) - 1:
        # hidden_output = tf.nn.tanh(hidden_output)
        hidden_output = tf.nn.selu(hidden_output)
      elif self.apply_final_act:
        hidden_output = tf.nn.selu(hidden_output)

    if need_reshape_back:
      hidden_output = tf.squeeze(hidden_output, axis=1)
    return hidden_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1].concatenate(self.hidden_units[-1])

  def get_config(self):
    config = {
        'hidden_units': self.hidden_units,
        'apply_final_act': self.apply_final_act,
        'use_bias': self.use_bias
    }
    base_config = super(CoActionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class MaskBlockLayer(tf.keras.layers.Layer):
  """
    Model: Mask Block Layer

    Paper: MaskNet: Introducing Feature-Wise Multiplication to CTR Ranking Models by Instance-Guided Mask

    Link: https://arxiv.org/abs/2102.07619

    Author: Zhiqiang Wang, Qingyun She, Junlin Zhang

    Developer: anbo

    Date: 2021-04-12

    inputs: inputs: tuple, (input_a, input_b)
            input_a: (batch, dim1)
            input_b: (batch, dim2)

    return: (batch, dim)
    """
  def __init__(self,
               apply_ln_emb=True,
               hidden_size=32,
               l2_reg=0.001,
               seed=11,
               **kwargs):
    super(MaskBlockLayer, self).__init__(**kwargs)
    self.hidden_size = hidden_size
    self.l2_reg = l2_reg
    self.seed = seed
    self.apply_ln_emb = apply_ln_emb

  def build(self, input_shape):
    input_size = int(input_shape[1][-1])
    input_size_a = int(input_shape[0][-1])
    from alps_biz.core.layer.sequence import LayerNorm

    self.W_d1 = self.add_weight(
        name="W_d1",
        shape=(input_size, self.hidden_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.bias_d1 = self.add_weight(name='bias_d1',
                                   shape=(self.hidden_size,),
                                   initializer=tf.keras.initializers.Zeros(),
                                   regularizer=tf.keras.regularizers.L1L2(
                                       0, self.l2_reg),
                                   trainable=True)
    self.W_d2 = self.add_weight(
        name="W_d2",
        shape=(self.hidden_size, input_size_a),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.bias_d2 = self.add_weight(name='bias_d2',
                                   shape=(input_size_a,),
                                   initializer=tf.keras.initializers.Zeros(),
                                   regularizer=tf.keras.regularizers.L1L2(
                                       0, self.l2_reg),
                                   trainable=True)

    if self.apply_ln_emb:
      self.ln_emb_layer = LayerNorm(name='ln_emb_layer')
    self.ln_hid_layer = LayerNorm(name='ln_hidden_layer')
    self.hidden_weight = self.add_weight(
        name="hidden_weight",
        shape=(input_size_a, input_size_a),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(MaskBlockLayer, self).build(input_shape)

  def apply_instance_guide_mask(self, inputs):
    """
        :param inputs:
        :return:
        """
    output_1 = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.W_d1), self.bias_d1)
    output = tf.keras.backend.bias_add(
        tf.keras.backend.dot(output_1, self.W_d2), self.bias_d2)
    tf.logging.info('MaskBlockLayer: output {}'.format(output))
    return output

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: tuple, (input_a, input_b)
            input_a: (batch, dim1)
            input_b: (batch, dim2)

        returns: (batch, l)
        """
    input_a, input_b = inputs

    V_mask = self.apply_instance_guide_mask(input_b)
    if self.apply_ln_emb:
      input_a = self.ln_emb_layer(input_a)

    if tf.keras.backend.ndim(input_a) == 3 and tf.keras.backend.ndim(
        V_mask) == 2:
      V_mask = tf.expand_dims(V_mask, axis=1)

    V_masked = tf.multiply(V_mask, input_a)
    V_hidden = self.ln_hid_layer(
        tf.keras.backend.dot(V_masked, self.hidden_weight))
    V_output = tf.nn.relu(V_hidden)
    return V_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'apply_ln_emb': self.apply_ln_emb,
        'hidden_size': self.hidden_size,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(MaskBlockLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class ExternalAttentionLayer(tf.keras.layers.Layer):
  """
    Model: External Attention Layer

    Paper: Beyond Self-attention: External Attention using Two Linear Layers for Visual Tasks

    Link: https://arxiv.org/pdf/2105.02358.pdf

    Author: Meng-Hao Guo, Zheng-Ning Liu, Tai-Jiang Mu, Shi-Min Hu

    Developer: anbo

    Date: 2021-05-10

    inputs: tuple,  (batch, n, d)

    return: (batch, n, d)
    """
  def __init__(self, hidden_size=64, l2_reg=0.001, seed=11, **kwargs):
    super(ExternalAttentionLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.hidden_size = hidden_size

  def build(self, input_shape):
    self.dim = int(input_shape[-1])

    self.m_k = self.add_weight(
        name='m_k',
        shape=(self.dim, self.hidden_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.m_v = self.add_weight(
        name='m_v',
        shape=(self.dim, self.hidden_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(ExternalAttentionLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (batch, n, d)

        returns: (batch, n, d)
        """
    energy = tf.tensordot(inputs, self.m_k, axes=(-1, 0))
    attn_score = tf.nn.softmax(energy, axis=1)
    # attn_score = tf.norm(attn_score, ord=1, axis=2, keepdims=True, name='l1_norm')
    attn_score = attn_score / (
        tf.reduce_sum(attn_score, axis=2, keepdims=True) + 1.e-9)
    tf.logging.info('ExternalAttentionLayer: attn_score {}'.format(attn_score))

    m_v_transpose = tf.keras.backend.permute_dimensions(self.m_v, (1, 0))
    output = tf.tensordot(attn_score, m_v_transpose, axes=(-1, 0))
    # output: (batch, n, d)
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'hidden_size': self.hidden_size
    }
    base_config = super(ExternalAttentionLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class gMLPLayer(tf.keras.layers.Layer):
  """
    Model: gMLP

    Paper: Pay Attention to MLPs

    Link: https://arxiv.org/abs/2105.08050

    Author: Hanxiao Liu, Zihang Dai, David R. So, Quoc V. Le

    Developer: anbo

    Date: 2021-05-19

    inputs: (batch, n, d)

    return: (batch, n, d)
    """
  def __init__(self, n_layers=1, ff_mult=4, l2_reg=0.001, seed=11, **kwargs):
    super(gMLPLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.ff_mult = ff_mult
    self.n_layers = n_layers

  def build(self, input_shape):
    self.dim = int(input_shape[-1])
    self.dim_ff = self.dim * self.ff_mult

    from alps_biz.core.layer.activation_layer import Gelu
    from alps_biz.core.layer.sequence import LayerNorm

    self.norm_layer = LayerNorm(name='layer_norm')
    self.gelu_layer = Gelu(name='gelu_layer')

    self.weight_1 = self.add_weight(
        name='weight_1',
        shape=(self.dim, self.dim_ff * 2),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.bias_1 = self.add_weight(name='bias_1',
                                  shape=(self.dim_ff * 2,),
                                  initializer=tf.keras.initializers.Zeros(),
                                  regularizer=tf.keras.regularizers.L1L2(
                                      0, self.l2_reg),
                                  trainable=True)

    self.weight_2 = self.add_weight(
        name='weight_2',
        shape=(self.dim_ff, self.dim),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.bias_2 = self.add_weight(name='bias_2',
                                  shape=(self.dim,),
                                  initializer=tf.keras.initializers.Zeros(),
                                  regularizer=tf.keras.regularizers.L1L2(
                                      0, self.l2_reg),
                                  trainable=True)

    self.sgu_layer = SGULayer(name='sgu_layer')

    super(gMLPLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (batch, n, d)

        returns: (batch, n, d)
        """
    ln_output = self.norm_layer(inputs)
    project_output = tf.keras.backend.bias_add(
        tf.keras.backend.dot(ln_output, self.weight_1), self.bias_1)
    tf.logging.info('gMLPLayer: project_output {}'.format(project_output))
    project_output = self.gelu_layer(project_output)

    sgu_output = self.sgu_layer(project_output)
    output = tf.keras.backend.bias_add(
        tf.keras.backend.dot(sgu_output, self.weight_2), self.bias_2)
    tf.logging.info('gMLPLayer: output {}'.format(output))
    output = inputs + output
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'n_layers': self.n_layers,
        'ff_mult': self.ff_mult
    }
    base_config = super(gMLPLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class SGULayer(tf.keras.layers.Layer):
  """
    Model: Spatial Gating Unit (SGU)

    Paper: Pay Attention to MLPs

    Link: https://arxiv.org/abs/2105.08050

    Author: Hanxiao Liu, Zihang Dai, David R. So, Quoc V. Le

    Developer: anbo

    Date: 2021-05-19

    inputs: (batch, n, d)

    return: (batch, n, d)
    """
  def __init__(self, **kwargs):
    super(SGULayer, self).__init__(**kwargs)

  def build(self, input_shape):
    self.dim = int(input_shape[-1])
    self.seq_len = int(input_shape[1])

    from alps_biz.core.layer.sequence import LayerNorm

    self.norm_layer = LayerNorm(name='layer_norm')
    self.spatial_layer = tf.keras.layers.Conv1D(self.seq_len,
                                                kernel_size=1,
                                                strides=1,
                                                padding='valid',
                                                data_format='channels_last',
                                                kernel_initializer='zeros',
                                                bias_initializer='ones',
                                                name='spatial_conv_layer')

    super(SGULayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs:  (batch, n, d)

        returns: (batch, n, d)
        """
    res, gate = tf.split(inputs, num_or_size_splits=2, axis=-1)
    tf.logging.info('SGULayer: res {}, gate {}'.format(res, gate))

    gate_output = self.norm_layer(gate)

    gate_output = tf.keras.backend.permute_dimensions(gate_output, (0, 2, 1))
    gate_output = self.spatial_layer(gate_output)
    gate_output = tf.keras.backend.permute_dimensions(gate_output, (0, 2, 1))
    tf.logging.info('SGULayer: gate_output {}'.format(gate_output))

    output = tf.multiply(res, gate_output)
    tf.logging.info('SGULayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:-1].concatenate(self.dim // 2)


class AITLayer(tf.keras.layers.Layer):
  """
    Model: AIT module

    Paper: Modeling the Sequential Dependence among Audience Multi-step Conversions with Multi-task Learning in Targeted Display Advertising

    Link: https://arxiv.org/abs/2105.08489

    Author: Dongbo Xi, Zhen Chen, Peng Yan, Yinger Zhang, Yongchun Zhu, Fuzhen Zhuang, Yu Chen

    Developer: anbo

    Date: 2021-06-02

    inputs: list of 2d tensor, (input_1, input_2)
        input_1: (batch, dim)
        input_2: (batch, dim)

    return: (batch, n, d)
    """
  def __init__(self, hidden_size=16, l2_reg=0.001, seed=11, **kwargs):
    super(AITLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.hidden_size = hidden_size

  def build(self, input_shape):
    self.dim = int(input_shape[-1][-1])
    self.kernels, self.bias = [], []

    for i in range(3):
      self.kernels.append(
          self.add_weight(
              name='kernel_{}'.format(i),
              shape=(self.dim, self.hidden_size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))

      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(self.hidden_size,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    super(AITLayer, self).build(input_shape)

  def expand_dims(self, inputs):
    if tf.keras.backend.ndim(inputs) < 3:
      return tf.expand_dims(inputs, axis=1)
    return inputs

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: list of 2d tensor, (input_1, input_2)
            input_1: (batch, dim)
            input_2: (batch, dim)

        returns: (batch, dim)
        """
    input_1, input_2 = inputs
    concat_input = tf.concat(
        [self.expand_dims(input_1),
         self.expand_dims(input_2)], axis=1)
    # concat_input: (batch, 2, dim)
    tf.logging.info(
        'AITMModel: ait_module, concat_input {}'.format(concat_input))

    hidden_outputs = []
    for i in range(len(self.kernels)):
      hidden_outputs.append(
          tf.keras.backend.bias_add(
              tf.keras.backend.dot(concat_input, self.kernels[i]),
              self.bias[i]))

    wu = tf.reduce_sum(tf.multiply(hidden_outputs[1], hidden_outputs[2]),
                       axis=-1,
                       keepdims=True) / tf.sqrt(
                           tf.cast(hidden_outputs[1].shape[-1], tf.float32))
    wu = tf.nn.softmax(wu, axis=1)

    outputs = tf.multiply(wu, hidden_outputs[0])
    outputs = tf.reduce_sum(outputs, axis=1, keepdims=False)
    # outputs: (batch, dim)
    tf.logging.info('AITMModel: ait_module, outputs {}'.format(outputs))
    return outputs

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.hidden_size)

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'hidden_size': self.hidden_size
    }
    base_config = super(AITLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class FATLayer(tf.keras.layers.Layer):
  """
    Model: Feedback Interaction Layer

    Paper: FINN: Feedback Interactive Neural Network for Intent Recommendation

    Link: https://www.atatech.org/paper/1472

    Author: Yatao Yang, Biyu Ma, Jun Tan, Hongbo Deng, Haikuan Huang, Zibin Zheng

    Developer: anbo

    Date: 2021-06-02

    inputs: list of 3d tensor, (input_1, input_2)
        input_1: (batch, seq_len1, dim)
        input_2: (batch, seq_len2, dim)

    return: (batch, d)
    """
  def __init__(self, **kwargs):
    super(FATLayer, self).__init__(**kwargs)

  def build(self, input_shape):
    super(FATLayer, self).build(input_shape)

  def call(self, inputs, mask=None, **kwargs):
    """
        Args:
            inputs: list of 3d tensor, (input_1, input_2)
                input_1: (batch, seq_len1, dim)
                input_2: (batch, seq_len2, dim)

        returns: (batch, dim)
        """
    input_1, input_2 = inputs

    input_2_transposed = tf.keras.backend.permute_dimensions(
        input_2, (0, 2, 1))
    # input_2_transposed: (batch, dim, seq_len2)
    #energy = tf.keras.backend.batch_dot(input_1, input_2_transposed, axes=[-1, 1])
    energy = tf.matmul(input_1, input_2_transposed)
    # energy: (batch, seq_len1, seq_len2)
    tf.logging.info('FATLayer: energy {}'.format(energy))

    energy = tf.nn.softmax(energy, axis=-1)
    if mask is not None:
      energy = tf.multiply(energy, mask)

    # input_1_hat = tf.keras.backend.batch_dot(energy, input_2, axes=[-1, 1])
    input_1_hat = tf.matmul(energy, input_2)
    output = tf.reduce_mean(input_1 - input_1_hat, axis=1, keepdims=False)
    # output: (batch, dim)
    tf.logging.info('FATLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])


class SequenceAggLayer(tf.keras.layers.Layer):
  """
    Model: Sequence Aggregation Layer

    Developer: anbo

    Date: 2021-06-03

    inputs: 3d tensor, (batch, seq_len1, dim)

    return: (batch, d)
    """
  def __init__(self, agg_tag='mean_pooling', num_inputs=1, **kwargs):
    super(SequenceAggLayer, self).__init__(**kwargs)
    self.agg_tag = agg_tag
    self.num_inputs = num_inputs

  def build(self, input_shape):
    if self.agg_tag == 'attention':
      from alps_biz.core.layer.attention import BahdanauAttnLayer
      self.agg_layer = BahdanauAttnLayer(name='bahandau_attn_layer')

    super(SequenceAggLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: 3d tensor, input_1: (batch, seq_len1, dim)

        returns: (batch, dim)
        """
    if self.agg_tag == 'mean_pooling':
      return tf.reduce_mean(inputs, axis=1, keepdims=False)
    elif self.agg_tag == 'sum_pooling':
      return tf.reduce_sum(inputs, axis=1, keepdims=False)
    elif self.agg_tag == 'attention':
      return self.agg_layer(inputs)

  def compute_output_shape(self, input_shape):
    if self.num_inputs == 1:
      input_shape = tensor_shape.TensorShape(input_shape)
    else:
      input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {'agg_tag': self.agg_tag, 'num_inputs': self.num_inputs}
    base_config = super(SequenceAggLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class WeightedSeqAggLayer(tf.keras.layers.Layer):
  def __init__(self,
               n_inputs=2,
               temperature=1,
               l2_reg=0.001,
               seed=11,
               **kwargs):
    super(WeightedSeqAggLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.n_inputs = n_inputs
    self.temperature = temperature

  def build(self, input_shape):
    if self.n_inputs == 1:
      input_size = int(input_shape[-1])
      output_size = 1
    elif self.n_inputs == 2:
      output_size = int(input_shape[0][-1])
      input_size = int(input_shape[1][-1])

    self.weight = self.add_weight(
        name='weight',
        shape=(input_size, output_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(WeightedSeqAggLayer, self).build(input_shape)

  def get_masked_score(self, attn, mask=None):
    """
        Args:
            attn: (batch, len, 1)
            mask: (batch, len, 1), masked token is labeled with 1
        """
    if mask is not None:
      if tf.keras.backend.ndim(mask) < 3:
        mask = tf.expand_dims(mask, -1)
      tf.logging.info('self: mask {}'.format(mask))
      attn += -1e9 * tf.cast(mask, tf.float32)

    attn = tf.keras.layers.Lambda(lambda x: tf.multiply(
        x, 1. / tf.cast(self.temperature, tf.float32)))(attn)
    tf.logging.info('WeightedSeqAggLayer: temperature {}'.format(
        self.temperature))
    score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, 1))(attn)
    return score

  def call(self, inputs, mask=None, **kwargs):
    """
        Args:
            inputs: (batch, seq_len, dim)
        returns: (batch, dim)
        """
    if self.n_inputs == 1:
      sequence_input = inputs
      attn = tf.keras.backend.dot(sequence_input, self.weight)
      # attn: (batch, seq_len, 1)
      tf.logging.info('WeightedSeqAggLayer: attn {}'.format(attn))
    elif self.n_inputs == 2:
      sequence_input, hidden_state = inputs
      hidden_state = tf.keras.backend.dot(hidden_state, self.weight)
      hidden_state_3d = tf.keras.backend.expand_dims(hidden_state, axis=-1)
      # hidden_state_3d: (batch, dim, 1)
      attn = tf.keras.backend.batch_dot(sequence_input, hidden_state_3d)
      # attn: (batch, seq_len, 1)

    # score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, 1))(attn)
    score = self.get_masked_score(attn, mask)

    output = tf.keras.backend.batch_dot(sequence_input, score, axes=[1, 1])
    output = tf.keras.backend.squeeze(output, axis=-1)
    # output (batch, dim)
    tf.logging.info('WeightedSeqAggLayer: output {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    if self.n_inputs == 1:
      input_shape = tensor_shape.TensorShape(input_shape)
    elif self.n_inputs == 2:
      input_shape = tensor_shape.TensorShape(input_shape[0])

    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(input_shape[-1])

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'n_inputs': self.n_inputs,
        'temperature': self.temperature
    }
    base_config = super(WeightedSeqAggLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class PermuteMLPLayer(tf.keras.layers.Layer):
  """
    Model: Permute MLP Layer

    Paper: Vision Permutator: A Permutable MLP-Like Architecture for Visual Recognition

    Link: https://arxiv.org/abs/2106.12368

    Author: Qibin Hou, Zihang Jiang, Li Yuan, Ming-Ming Cheng, Shuicheng Yan, Jiashi Feng

    Developer: anbo

    Date: 2021-06-30

    Input shape: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)

    Output shape: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)

    """
  def __init__(self, segment_dim=4, l2_reg=0.001, seed=11, **kwargs):
    super(PermuteMLPLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.segment_dim = segment_dim

  def build(self, input_shape):
    self.seq_len, self.fields, self.last_dim = int(input_shape[1]), int(
        input_shape[2]), int(input_shape[-1])
    self.S = self.last_dim // self.segment_dim
    dim = [self.seq_len * self.S, self.fields * self.S, self.last_dim]

    self.kernels = []
    self.bias = []
    for i in range(3):
      self.kernels.append(
          self.add_weight(
              name="kernel_{}".format(i),
              shape=(dim[i], dim[i]),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(dim[i],),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    from alps_biz.core.layer.core import DNNLayer
    self.reweight_layer = DNNLayer(
        hidden_units=[self.last_dim // 4, self.last_dim * 3],
        activation='relu',
        l2_reg=self.l2_reg,
        apply_final_act=True,
        seed=self.seed,
        name="PermuteMLPLayer_reweight")

    self.kernels.append(
        self.add_weight(
            name="kernel_4",
            shape=(self.last_dim, self.last_dim),
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
            trainable=True))
    self.bias.append(
        self.add_weight(name='bias_4',
                        shape=(self.last_dim,),
                        initializer=tf.keras.initializers.Zeros(),
                        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                        trainable=True))

    super(PermuteMLPLayer, self).build(input_shape)

  def call(self, inputs, mask=None, **kwargs):
    """
        Args:
            inputs: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)
        returns: (batch, dim)
        """
    tf.logging.info('PermuteMLPLayer: inputs {}'.format(inputs))

    query = tf.keras.backend.reshape(inputs,
                                     shape=(-1, self.seq_len, self.fields,
                                            self.segment_dim, self.S))
    query = tf.keras.backend.permute_dimensions(query, (0, 2, 3, 1, 4))
    query = tf.keras.backend.reshape(query,
                                     shape=(-1, self.fields, self.segment_dim,
                                            self.seq_len * self.S))
    query = tf.keras.backend.bias_add(
        tf.keras.backend.dot(query, self.kernels[0]), self.bias[0])
    query = tf.keras.backend.reshape(query,
                                     shape=(-1, self.fields, self.segment_dim,
                                            self.seq_len, self.S))
    query = tf.keras.backend.permute_dimensions(query, (0, 3, 1, 2, 4))
    query = tf.keras.backend.reshape(query,
                                     shape=(-1, self.seq_len, self.fields,
                                            self.segment_dim * self.S))
    # query: (batch, l, f, d)
    tf.logging.info('PermuteMLPLayer: query {}'.format(query))

    key = tf.keras.backend.reshape(inputs,
                                   shape=(-1, self.seq_len, self.fields,
                                          self.segment_dim, self.S))
    key = tf.keras.backend.permute_dimensions(key, (0, 1, 3, 2, 4))
    key = tf.keras.backend.reshape(key,
                                   shape=(-1, self.seq_len, self.segment_dim,
                                          self.fields * self.S))
    key = tf.keras.backend.bias_add(tf.keras.backend.dot(key, self.kernels[1]),
                                    self.bias[1])
    key = tf.keras.backend.reshape(key,
                                   shape=(-1, self.seq_len, self.segment_dim,
                                          self.fields, self.S))
    key = tf.keras.backend.permute_dimensions(key, (0, 1, 3, 2, 4))
    key = tf.keras.backend.reshape(key,
                                   shape=(-1, self.seq_len, self.fields,
                                          self.segment_dim * self.S))
    # key: (batch, l, f, d)
    tf.logging.info('PermuteMLPLayer: key {}'.format(key))

    value = tf.keras.backend.bias_add(
        tf.keras.backend.dot(inputs, self.kernels[2]), self.bias[2])
    tf.logging.info('PermuteMLPLayer: value {}'.format(value))

    sum_val = tf.keras.backend.permute_dimensions(query + key + value,
                                                  (0, 3, 1, 2))
    sum_val = tf.keras.backend.reshape(sum_val,
                                       shape=(-1, self.last_dim,
                                              self.seq_len * self.fields))
    sum_val = tf.reduce_mean(sum_val, axis=2, keepdims=False)
    # sum_val: (batch, d)
    tf.logging.info('PermuteMLPLayer: sum_val {}'.format(sum_val))

    attn = self.reweight_layer(sum_val)
    attn = tf.keras.backend.reshape(attn, shape=(-1, self.last_dim, 3))
    attn = tf.keras.backend.permute_dimensions(attn, (2, 0, 1))
    score = tf.nn.softmax(attn, axis=0)
    score = score[:, :, tf.newaxis, tf.newaxis, :]

    scaled_weight = tf.multiply(query, score[0]) + tf.multiply(
        key, score[1]) + tf.multiply(value, score[2])
    output = tf.keras.backend.bias_add(
        tf.keras.backend.dot(scaled_weight, self.kernels[3]), self.bias[3])
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'segment_dim': self.segment_dim
    }
    base_config = super(PermuteMLPLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class PermutatorBlockLayer(tf.keras.layers.Layer):
  """
    Model: vision permutator block Layer

    Paper: Vision Permutator: A Permutable MLP-Like Architecture for Visual Recognition

    Link: https://arxiv.org/abs/2106.12368

    Author: Qibin Hou, Zihang Jiang, Li Yuan, Ming-Ming Cheng, Shuicheng Yan, Jiashi Feng

    Developer: anbo

    Date: 2021-06-30

    Input shape: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)

    Output shape: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)

    """
  def __init__(self,
               intermediate_size=32,
               segment_dim=4,
               skip_lam=1.0,
               drop_prob=0.0,
               act_fn='relu',
               l2_reg=0.001,
               seed=11,
               **kwargs):
    super(PermutatorBlockLayer, self).__init__(**kwargs)
    self.l2_reg = l2_reg
    self.seed = seed
    self.segment_dim = segment_dim
    self.act_fn = act_fn
    self.intermediate_size = intermediate_size
    self.skip_lam = skip_lam
    self.drop_prob = drop_prob

  def build(self, input_shape):
    from alps_biz.core.layer.sequence import LayerNorm
    from alps_biz.core.layer.core import DNNLayer
    last_dim = int(input_shape[-1])

    self.pre_ln = LayerNorm(name='pre_ln_layer')
    self.last_ln = LayerNorm(name='last_ln_layer')
    self.permute_mlp = PermuteMLPLayer(segment_dim=self.segment_dim,
                                       l2_reg=self.l2_reg,
                                       seed=self.seed,
                                       name='permute_mlp_layer')
    self.channel_mlp = DNNLayer(
        hidden_units=[self.intermediate_size, last_dim],
        activation=self.act_fn,
        l2_reg=self.l2_reg,
        apply_final_act=True,
        seed=self.seed,
        name="channel_mlp_layer")
    self.drop_path = DropPathLayer(drop_prob=self.drop_prob,
                                   seed=self.seed,
                                   name="drop_path_layer")

    super(PermutatorBlockLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: 4d tensor, (batch, len, heads, dim) or (batch, len, fields, dim)
        returns: (batch, dim)
        """
    tf.logging.info('PermutatorBlockLayer: inputs {}'.format(inputs))

    permute_output = inputs + self.drop_path(self.permute_mlp(
        self.pre_ln(inputs)),
                                             training=training) / self.skip_lam
    channel_output = permute_output + self.drop_path(
        self.channel_mlp(
            self.last_ln(permute_output)), training=training) / self.skip_lam
    return channel_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'intermediate_size': self.intermediate_size,
        'segment_dim': self.segment_dim,
        'act_fn': self.act_fn,
        'skip_lam': self.skip_lam,
        'drop_prob': self.drop_prob
    }
    base_config = super(PermutatorBlockLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class DropPathLayer(tf.keras.layers.Layer):
  """
    Model: DropPath Layer

    Paper: FractalNet: Ultra-Deep Neural Networks without Residuals

    Link: https://arxiv.org/abs/1605.07648

    Author: Gustav Larsson, Michael Maire, Gregory Shakhnarovich

    Developer: anbo

    Date: 2021-07-01

    """
  def __init__(self, drop_prob=0.0, seed=12, **kwargs):
    super(DropPathLayer, self).__init__(**kwargs)
    self.drop_prob = drop_prob
    self.keep_prob = 1.0 - drop_prob
    self.seed = seed

  def build(self, input_shape):
    super(DropPathLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: tensor
        """
    tf.logging.info('DropPathLayer: inputs {}'.format(inputs))

    if self.drop_prob == 0 or not training:
      return inputs

    ndim = tf.keras.backend.ndim(inputs)
    rand_tensor = self.keep_prob + tf.random.uniform(
        shape=(tf.shape(inputs)[0],) + (1,) * (ndim - 1),
        minval=0.0,
        maxval=1.0,
        dtype=tf.float32,
        seed=self.seed)
    rand_tensor = tf.floor(rand_tensor)
    output = tf.multiply(tf.math.divide(inputs, self.keep_prob), rand_tensor)
    return output

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {'drop_prob': self.drop_prob, 'seed': self.seed}
    base_config = super(DropPathLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class ContextNetBlockLayer(tf.keras.layers.Layer):
  """
    Model: Context Embedding and Context Block Layer

    Paper: ContextNet: A Click-Through Rate Prediction Framework Using Contextual information to Refine Feature Embedding

    Link: https://arxiv.org/abs/2107.12025

    Author: Zhiqiang Wang, Qingyun She, PengTao Zhang, Junlin Zhang

    Developer: anbo

    Date: 2021-08-17

    inputs: inputs: (batch, fields, dim1)

    return: (batch, fields, dim)
    """
  def __init__(self,
               hidden_size=32,
               share_aggregation_tag=True,
               point_fnn_tag=False,
               contextnet_block_layers=1,
               l2_reg=0.001,
               seed=11,
               **kwargs):
    super(ContextNetBlockLayer, self).__init__(**kwargs)
    self.hidden_size = hidden_size
    self.l2_reg = l2_reg
    self.seed = seed
    self.share_aggregation_tag = share_aggregation_tag
    self.point_fnn_tag = point_fnn_tag
    self.contextnet_block_layers = contextnet_block_layers

  def build(self, input_shape):
    self.input_size = int(input_shape[-1])
    self.fields = int(input_shape[1])

    if self.share_aggregation_tag:
      self.w1 = self.add_weight(
          name="agg_layer_weight",
          shape=(self.input_size, self.hidden_size),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)
      self.b1 = self.add_weight(name='agg_layer_bias',
                                shape=(self.hidden_size,),
                                initializer=tf.keras.initializers.Zeros(),
                                regularizer=tf.keras.regularizers.L1L2(
                                    0, self.l2_reg),
                                trainable=True)
    else:
      self.w1 = self.add_weight(
          name="agg_layer_weight",
          shape=(self.fields * self.input_size,
                 self.fields * self.hidden_size),
          initializer=tf.keras.initializers.he_normal(seed=self.seed),
          regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
          trainable=True)
      self.b1 = self.add_weight(name='agg_layer_bias',
                                shape=(self.fields * self.hidden_size,),
                                initializer=tf.keras.initializers.Zeros(),
                                regularizer=tf.keras.regularizers.L1L2(
                                    0, self.l2_reg),
                                trainable=True)

    self.w2 = self.add_weight(
        name="context_embedding_project_weight",
        shape=(self.fields * self.hidden_size, self.fields * self.input_size),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.b2 = self.add_weight(name='context_embedding_project_bias',
                              shape=(self.fields * self.input_size,),
                              initializer=tf.keras.initializers.Zeros(),
                              regularizer=tf.keras.regularizers.L1L2(
                                  0, self.l2_reg),
                              trainable=True)

    from alps_biz.core.layer.sequence import LayerNorm

    self.contextnet_block_weights = []
    self.contextnet_block_bias = []
    self.ln = []
    for i in range(self.contextnet_block_layers):
      self.contextnet_block_weights.append(
          self.add_weight(
              name="context_block_{}th_weight".format(i),
              shape=(self.input_size, self.input_size),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.contextnet_block_bias.append(
          self.add_weight(name='context_block_{}th_bias'.format(i),
                          shape=(self.input_size,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))
      self.ln.append(LayerNorm(name='{}th_layer_norm'.format(i)))

    if self.point_fnn_tag:
      self.contextnet_block_weights_w2 = []
      for i in range(self.contextnet_block_layers):
        self.contextnet_block_weights_w2.append(
            self.add_weight(
                name="context_block_{}th_weight_w2".format(i),
                shape=(self.input_size, self.input_size),
                initializer=tf.keras.initializers.he_normal(seed=self.seed),
                regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                trainable=True))

    super(ContextNetBlockLayer, self).build(input_shape)

  def context_embedding_fn(self, inputs):
    """
    :param inputs: (batch, fields, dim)
    :return:
    """
    if self.share_aggregation_tag:
      output_1 = tf.tensordot(inputs, self.w1, axes=(-1, 0))
      output_1 = tf.keras.backend.bias_add(output_1, self.b1)
      #  output_1: (batch, fields, dim1)
      output_1 = tf.reshape(output_1,
                            shape=(-1, self.fields * self.hidden_size))
    else:
      inputs_reshaped = tf.reshape(inputs,
                                   shape=(-1, self.fields * self.input_size))
      tf.logging.info(
          'not sharing params in aggregation layer of context embedding inputs_reshaped {}'
          .format(inputs_reshaped))
      output_1 = tf.keras.backend.bias_add(
          tf.keras.backend.dot(inputs_reshaped, self.w1), self.b1)

    context_embedding = tf.keras.backend.bias_add(
        tf.keras.backend.dot(output_1, self.w2), self.b2)
    context_embedding = tf.reshape(context_embedding,
                                   shape=(-1, self.fields, self.input_size))
    tf.logging.info(
        'ContextNetBlockLayer: context_embedding {}'.format(context_embedding))
    return context_embedding

  def contextnet_block_fn(self, i, inputs, context_embedding):
    """
    params:
      inputs: (batch, fields, dim)
      context_embedding: (batch, fields, dim)
    
    outputs: (batch, fields, dim)
    """
    merge_output = tf.multiply(inputs, context_embedding)
    # merge_output: (batch, fields, dim)
    tf.logging.info('merge_output: {}'.format(merge_output))

    hidden_output = tf.keras.backend.bias_add(
        tf.keras.backend.dot(merge_output, self.contextnet_block_weights[i]),
        self.contextnet_block_bias[i])

    if self.point_fnn_tag:
      hidden_output = tf.nn.relu(hidden_output)
      hidden_output = tf.keras.backend.dot(hidden_output,
                                           self.contextnet_block_weights_w2[i])
      hidden_output = hidden_output + inputs
      output = self.ln[i](hidden_output)
    else:
      output = self.ln[i](hidden_output)

    return output

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: (batch, fields, dim1)

        returns: (batch, l)
        """
    context_embedding = self.context_embedding_fn(inputs)

    contextnet_block_output = inputs
    for i in range(self.contextnet_block_layers):
      contextnet_block_output = self.contextnet_block_fn(
          i, contextnet_block_output, context_embedding)
      tf.logging.info('contextnet_block_output {} in {}th block'.format(
          contextnet_block_output, i))

    output = tf.reshape(contextnet_block_output,
                        shape=(-1, self.fields * self.input_size))
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.fields * self.input_size)

  def get_config(self):
    config = {
        'share_aggregation_tag': self.share_aggregation_tag,
        'point_fnn_tag': self.point_fnn_tag,
        'contextnet_block_layers': self.contextnet_block_layers,
        'hidden_size': self.hidden_size,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(ContextNetBlockLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))