# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape


class FineSeqLayer(tf.keras.layers.Layer):
  """
  Model: 

  Paper: 

  Link: 

  Author: anbo, yunjian, xianyu

  Developer: anbo

  Date: 2021-08-03

  inputs: list of tensors [input_1, input_2]
          input_1: (batch, seq_len, dim_1)
          input_2: (batch, dim_2)

  output: (batch, seq_len, hidden_units)
  """
  def __init__(self,
               n_layers=2,
               l2_reg=0.001,
               seed=1024,
               drop_prob=0.0,
               **kwargs):
    """
        Args:
            n_layers: int, number of layers
            l2_reg: float
        """
    super(FineSeqLayer, self).__init__(**kwargs)
    self.n_layers = n_layers
    self.l2_reg = l2_reg
    self.seed = seed
    self.drop_prob = drop_prob

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
        """
    input_dim1 = int(input_shape[0][-1])
    input_dim2 = int(input_shape[1][-1])

    from alps_biz.core.layer import LayerNorm, DropPathLayer

    self.kernels, self.bias = [], []
    self.ln_hid_layers = []

    for i in range(self.n_layers):
      self.kernels.append(
          self.add_weight(
              name='weight_{}'.format(i),
              shape=(input_dim2, input_dim1),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.bias.append(
          self.add_weight(name='bias_{}'.format(i),
                          shape=(input_dim1,),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))

      self.ln_hid_layers.append(LayerNorm(name='ln_hidden_layer_{}'.format(i)))

    self.drop_path = DropPathLayer(drop_prob=self.drop_prob,
                                   seed=self.seed,
                                   name="drop_path_layer")

    super(FineSeqLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
        Args:
            inputs: list of tensors [seq_inputs, inputs]
            seq_inputs: (batch, len, dim1)
            inputs: (batch, dim2)
        returns:
            2d tensor (batch_size, n_dim)
        """
    seq_input, item_input = inputs

    item_input_3d = tf.keras.backend.expand_dims(item_input, axis=1)
    # item_input_3d (batch, 1, dim2)
    hidden_seq_input = seq_input

    for i in range(self.n_layers):
      tf.logging.info('FineSeqLayer: {}th layer !!!'.format(i))
      seq_mask_hidden_1 = tf.keras.backend.dot(item_input_3d, self.kernels[i])
      # seq_mask_hidden_1: (batch, 1, input_dim)
      tf.logging.info(
          'FineSeqLayer: seq_mask_hidden_1 {}'.format(seq_mask_hidden_1))

      tf.summary.image('fine_seq_layer_{}_kernel'.format(i),
                       tensor=self.kernels[i][tf.newaxis, :, :, tf.newaxis],
                       max_outputs=1,
                       collections=None,
                       family=None)

      seq_mask_hidden_2 = tf.keras.backend.batch_dot(hidden_seq_input,
                                                     seq_mask_hidden_1,
                                                     axes=[2, 2])
      # seq_mask_hidden_2: (batch, len, 1)
      tf.logging.info(
          'FineSeqLayer: seq_mask_hidden_2 {}'.format(seq_mask_hidden_2))

      # seq_mask_hidden_2 = self.bn_layer(seq_mask_hidden_2, training=training)
      seq_mask_hidden_2 = tf.nn.sigmoid(seq_mask_hidden_2)

      tf.summary.histogram('attention_weight_layer_{}'.format(i),
                           tf.squeeze(seq_mask_hidden_2))

      V_masked = tf.multiply(seq_mask_hidden_2, hidden_seq_input)

      hidden_seq_input = self.drop_path(V_masked,
                                        training=training) + hidden_seq_input
      tf.logging.info(
          'FineSeqLayer: hidden_seq_input {}'.format(hidden_seq_input))

      hidden_seq_input = tf.keras.layers.Lambda(
          lambda x: tf.nn.bias_add(x[0], x[1]))(
              [hidden_seq_input, self.bias[i]])
      tf.logging.info('FineSeqLayer: add bias hidden_seq_input {}'.format(
          hidden_seq_input))

      tf.summary.histogram('fine_seq_layer_{}_bias'.format(i),
                           self.bias[i][tf.newaxis, :])

      hidden_seq_input = self.ln_hid_layers[i](hidden_seq_input)
      tf.logging.info('FineSeqLayer: late norm hidden_seq_input {}'.format(
          hidden_seq_input))

    return hidden_seq_input

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape[0])
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape

  def get_config(self):
    config = {
        'n_layers': self.n_layers,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'drop_prob': self.drop_prob
    }
    base_config = super(FineSeqLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class StarTopologyFCNLayer(tf.keras.layers.Layer):
  """
    Model: Star Topology FCN Layer 

    Paper: One Model to Serve All: Star Topology Adaptive Recommender for Multi-Domain CTR Prediction

    Link: https://arxiv.org/abs/2101.11427
  
    Author: Xiang-Rong Sheng, Liqin Zhao, Guorui Zhou, Xinyao Ding, Binding Dai, Qiang Luo, Siran Yang, Jingshan Lv, Chi Zhang, Hongbo Deng, Xiaoqiang Zhu

    Developer: anbo

    Date: 2021-08-17

    inputs: 2d tensor (batch_size, n_dim)

    outputs: list of 2d tensor [input_1, input_2, ....]
             input_x: (batch_size, 1)

  """
  def __init__(self,
               hidden_units=[16, 8],
               num_domains=2,
               l2_reg=0.001,
               seed=1024,
               apply_final_act=False,
               **kwargs):
    """
        Args:
            n_layers: int, number of layers
            l2_reg: float
        """
    super(StarTopologyFCNLayer, self).__init__(**kwargs)
    self.hidden_units = hidden_units
    self.l2_reg = l2_reg
    self.seed = seed
    self.num_domains = num_domains
    self.n_layers = len(hidden_units)
    self.apply_final_act = apply_final_act

  def build(self, input_shape):
    """
    Args:
        input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).
    """
    input_size = int(input_shape[-1])
    # input_size = int(input_shape[0][-1])
    hidden_units = [input_size] + self.hidden_units

    self.shared_fc_weights, self.shared_fc_bias = [], []
    self.domain_specific_weights, self.domain_specific_bias = [], []

    for i in range(self.n_layers):
      self.shared_fc_weights.append(
          self.add_weight(
              name='shared_fc_{}th_layer_weight'.format(i),
              shape=(hidden_units[i], hidden_units[i + 1]),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.shared_fc_bias.append(
          self.add_weight(name='shared_fc_{}th_layer_bias'.format(i),
                          shape=(hidden_units[i + 1],),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))

      domain_weights_tmp, domain_bias_tmp = [], []
      for j in range(self.num_domains):
        domain_weights_tmp.append(
            self.add_weight(
                name='{}th_domain_fc_{}th_layer_weight'.format(j, i),
                shape=(hidden_units[i], hidden_units[i + 1]),
                initializer=tf.keras.initializers.he_normal(seed=self.seed),
                regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                trainable=True))

        domain_bias_tmp.append(
            self.add_weight(name='{}th_domain_fc_{}th_layer_bias'.format(j, i),
                            shape=(hidden_units[i + 1],),
                            initializer=tf.keras.initializers.Zeros(),
                            trainable=True))
      self.domain_specific_weights.append(domain_weights_tmp)
      self.domain_specific_bias.append(domain_bias_tmp)

    super(StarTopologyFCNLayer, self).build(input_shape)

  def call(self, inputs, domain_index=0, training=None, **kwargs):
    """
    Args:
        inputs: list of 2d tensors from multiple domains, each with shape of (batch, dim2)
        # inputs: (batch, dim2)
        domain_index: deprecated
    returns:
        tensor (batch_size, n_dim)
    """
    # assert (domain_index >= 0 and domain_index < self.num_domains), (
    #     'domain_index is out of range, should be [0, {})'.format(
    #         self.num_domains))

    # domain_outputs = [inputs] * self.num_domains
    domain_outputs = inputs
    # assert (len(domain_outputs) == self.num_domains), (
    #     'must give the same number of inputs as the number of domains')
    tf.logging.info(
        'StarTopologyFCNLayer: domain_outputs {}'.format(domain_outputs))

    for i in range(self.n_layers):
      domain_w = tf.keras.layers.Lambda(lambda x: tf.multiply(x[0], x[1]))([
          self.shared_fc_weights[i],
          self.domain_specific_weights[i][domain_index]
      ])
      domain_b = tf.keras.layers.Lambda(lambda x: tf.add(x[0], x[1]))(
          [self.shared_fc_bias[i], self.domain_specific_bias[i][domain_index]])
      domain_outputs = tf.keras.layers.Lambda(
          lambda x: tf.keras.backend.bias_add(tf.keras.backend.dot(x[0], x[
              1]), x[2]))([domain_outputs, domain_w, domain_b])
      if i < self.n_layers - 1 or self.apply_final_act:
        domain_outputs = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(
            domain_outputs)

    # for i in range(self.n_layers):
    #   for j in range(self.num_domains):
    #     domain_w = tf.keras.layers.Lambda(lambda x: tf.multiply(x[0], x[1]))(
    #         [self.shared_fc_weights[i], self.domain_specific_weights[i][j]])
    #     domain_b = tf.keras.layers.Lambda(lambda x: tf.add(x[0], x[1]))(
    #         [self.shared_fc_bias[i], self.domain_specific_bias[i][j]])
    #     domain_outputs[j] = tf.keras.layers.Lambda(
    #         lambda x: tf.keras.backend.bias_add(
    #             tf.keras.backend.dot(x[0], x[1]), x[2]))(
    #                 [domain_outputs[j], domain_w, domain_b])

    # domain_w = tf.multiply(self.shared_fc_weights[i],
    #                        self.domain_specific_weights[i][j])
    # domain_b = tf.add(self.shared_fc_bias[i],
    #                   self.domain_specific_bias[i][j])
    # domain_outputs[j] = tf.keras.backend.bias_add(
    #     tf.keras.backend.dot(domain_outputs[j], domain_w), domain_b)
    # if i < self.n_layers - 1 or self.apply_final_act:
    #   domain_outputs[j] = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(
    #       domain_outputs[j])

    return domain_outputs

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.hidden_units[-1])
    # return [
    #     input_shape[:1].concatenate(self.hidden_units[-1])
    #     for _ in range(self.num_domains)
    # ]

  def get_config(self):
    config = {
        'hidden_units': self.hidden_units,
        'num_domains': self.num_domains,
        'l2_reg': self.l2_reg,
        'seed': self.seed,
        'apply_final_act': self.apply_final_act
    }
    base_config = super(StarTopologyFCNLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class PartitionedNorm(tf.keras.layers.Layer):
  """
    Model: Partitioned Normalization layer

    Paper: One Model to Serve All: Star Topology Adaptive Recommender for Multi-Domain CTR Prediction

    Link: https://arxiv.org/abs/2101.11427
  
    Author: Xiang-Rong Sheng, Liqin Zhao, Guorui Zhou, Xinyao Ding, Binding Dai, Qiang Luo, Siran Yang, Jingshan Lv, Chi Zhang, Hongbo Deng, Xiaoqiang Zhu

    Developer: anbo

    Date: 2021-08-17

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

  """
  def __init__(self,
               num_domains=2,
               momentum=0.99,
               l2_reg=0.001,
               eps=1.e-6,
               **kwargs):
    """
    Args:
        hidden_units: int, the last dim of the inputs
        l2_reg: float, regularization value
        eps: float, smooth value to avoid NAN when dividing
        kwargs:

    """
    super(PartitionedNorm, self).__init__(**kwargs)
    self.num_domains = num_domains
    self.eps = eps
    self.l2_reg = l2_reg
    self.momentum = momentum

  def build(self, input_shape):
    """
      Args:
          input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

    """
    self.hidden_units = int(input_shape[-1])
    # self.hidden_units = int(input_shape[0][-1])

    self.shared_gamma = self.add_weight(
        name='shared_gamma_weight',
        shape=(1, self.hidden_units),
        initializer=tf.keras.initializers.Ones(),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)
    self.shared_beta = self.add_weight(
        name='shared_beta_bias',
        shape=(self.hidden_units,),
        initializer=tf.keras.initializers.Zeros(),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    self.domain_gammas, self.domain_betas = [], []
    for i in range(self.num_domains):
      self.domain_gammas.append(
          self.add_weight(name='domain_gammas_weight_{}'.format(i),
                          shape=(1, self.hidden_units),
                          initializer=tf.keras.initializers.Ones(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))
      self.domain_betas.append(
          self.add_weight(name='shared_beta_bias_{}'.format(i),
                          shape=(self.hidden_units,),
                          initializer=tf.keras.initializers.Zeros(),
                          regularizer=tf.keras.regularizers.L1L2(
                              0, self.l2_reg),
                          trainable=True))

    # from tensorflow.python.ops import variables as tf_variables

    # self.domain_means, self.domain_vars = [], []
    # for i in range(self.num_domains):
    #   self.domain_means.append(
    #       self.add_weight(
    #           name='domain_moving_mean_{}'.format(i),
    #           shape=(1, self.hidden_units),
    #           initializer=tf.keras.initializers.Ones(),
    #           synchronization=tf_variables.VariableSynchronization.ON_READ,
    #           aggregation=tf_variables.VariableAggregation.MEAN,
    #           trainable=False))
    #   self.domain_vars.append(
    #       self.add_weight(
    #           name='shared_moving_varance_{}'.format(i),
    #           shape=(self.hidden_units,),
    #           initializer=tf.keras.initializers.Zeros(),
    #           synchronization=tf_variables.VariableSynchronization.ON_READ,
    #           aggregation=tf_variables.VariableAggregation.MEAN,
    #           trainable=False))

    super(PartitionedNorm, self).build(input_shape)

  def call(self, inputs, domain_index=0, training=None, **kwargs):
    """
      Args:
          inputs: 2d tensor (batch, hidden_units)

      Return:
          2d tensor (batch_size, n_dim)

    """
    mean = tf.keras.backend.mean(inputs, axis=0, keepdims=True)
    var = tf.keras.backend.mean(tf.keras.backend.square(inputs - mean),
                                axis=0,
                                keepdims=True)

    domain_w = tf.multiply(self.shared_gamma, self.domain_gammas[domain_index])
    domain_b = tf.add(self.shared_beta, self.domain_betas[domain_index])

    if training:
      # training mode
      output = tf.keras.layers.Lambda(
          lambda x: (x[0] - x[1]) / tf.sqrt(x[2] + self.eps))(
              [inputs, mean, var])

      # self.domain_means[domain_index] = tf.add(
      #     self.domain_means[domain_index] * self.momentum,
      #     mean * (1.0 - self.momentum))
      # self.domain_vars[domain_index] = tf.add(
      #     self.domain_vars[domain_index] * self.momentum,
      #     var * (1.0 - self.momentum))
    else:
      output = tf.keras.layers.Lambda(
          lambda x: (x[0] - x[1]) / tf.sqrt(x[2] + self.eps))(
              [inputs, mean, var])
      # output = tf.keras.layers.Lambda(
      #     lambda x: (x[0] - x[1]) / tf.sqrt(x[2] + self.eps))([
      #         inputs, self.domain_means[domain_index],
      #         self.domain_vars[domain_index]
      #     ])
    tf.logging.info('PartitionedNorm: output {}'.format(output))

    # for i in range(self.num_domains):
    #   tf.summary.scalar('PartitionedNorm_{}th_domain_moving_mean',
    #                     tf.reduce_mean(self.domain_means[i]))
    #   tf.summary.scalar('PartitionedNorm_{}th_domain_moving_variance',
    #                     tf.reduce_mean(self.domain_vars[i]))

    output = tf.keras.backend.bias_add(tf.multiply(output, domain_w), domain_b)
    tf.logging.info('PartitionedNorm multiply output shape {}'.format(output))
    return output

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {
        'eps': self.eps,
        'l2_reg': self.l2_reg,
        'num_domains': self.num_domains,
        'momentum': self.momentum,
    }
    base_config = super(PartitionedNorm, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class CapsuleLayer(tf.keras.layers.Layer):
  """
    Model: Capsule Layer

    Paper: Dynamic Routing Between Capsules

    Link: http://papers.neurips.cc/paper/6975-dynamic-routing-between-capsules.pdf

    Author: Sara Sabour, Nicholas Frosst, Geoffrey E. Hinton

    Developer: anbo

    Date: 2021-11-05

    inputs: 3d tensor (batch_size, n_input_capsules, n_dim)

    outputs: 3d tensor (batch_size, n_output_capsules, n_dim)

  """
  def __init__(self,
               num_capsules=2,
               hidden_units=16,
               routings=3,
               l2_reg=0.001,
               eps=1.e-6,
               seed=1024,
               **kwargs):
    """
    Args:
        hidden_units: int, the last dim of the inputs
        l2_reg: float, regularization value
        eps: float, smooth value to avoid NAN when dividing
        kwargs:

    """
    super(CapsuleLayer, self).__init__(**kwargs)
    self.num_capsules = num_capsules
    self.eps = eps
    self.l2_reg = l2_reg
    self.hidden_units = hidden_units
    assert routings > 0, 'The routings must be > 0'
    self.routings = routings
    self.seed = seed

  def build(self, input_shape):
    """
      Args:
          input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

    """
    assert len(input_shape) >= 3, 'The input shape must be at least 3d'
    self.n_input_capsules = int(input_shape[1])
    self.input_dim = int(input_shape[-1])

    self.weight = self.add_weight(
        name='capsule_transform_weight',
        shape=(self.num_capsules, self.n_input_capsules, self.hidden_units,
               self.input_dim),
        initializer=tf.keras.initializers.he_normal(seed=self.seed),
        regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
        trainable=True)

    super(CapsuleLayer, self).build(input_shape)

  def call(self, inputs, training=None, **kwargs):
    """
      Args:
          inputs: 3d tensor (batch_size, n_input_capsules, n_dim)

      Return:
          3d tensor (batch_size, n_output_capsules, n_dim)

    """
    inputs_expand = tf.expand_dims(inputs, axis=1)
    tf.logging.info('CapsuleLayer: inputs_expand {}'.format(inputs_expand))
    inputs_tile = tf.tile(inputs_expand, [1, self.num_capsules, 1, 1])
    tf.logging.info('CapsuleLayer: inputs_tile {}'.format(inputs_tile))

    inputs_hat = tf.einsum("abcd,bced->abce", inputs_tile, self.weight)
    # inputs_hat: (batch_size, num_capsules, n_input_capsules, hidden_units)
    tf.logging.info('CapsuleLayer: inputs_hat {}'.format(inputs_hat))
    b = tf.zeros(shape=(tf.shape(inputs_hat)[0], self.num_capsules,
                        self.n_input_capsules))
    # b: (batch_size, num_capsules, n_input_capsules)
    for i in range(self.routings):
      c = tf.nn.softmax(b, axis=1)

      from alps_biz.core.layer.activation_layer import Squash
      outputs = Squash()(tf.keras.backend.batch_dot(c, inputs_hat, [-1, 2]))
      # outputs: (batch, num_capsules, hidden_units)
      if i < self.routings - 1:
        b += tf.keras.backend.batch_dot(outputs, inputs_hat, [2, 3])

    return outputs

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    output_shape_1 = input_shape[:1].concatenate(self.num_capsules)
    return output_shape_1.concatenate(self.hidden_units)

  def get_config(self):
    config = {
        'eps': self.eps,
        'l2_reg': self.l2_reg,
        'num_capsules': self.num_capsules,
        'hidden_units': self.hidden_units,
        'routings': self.routings,
        'seed': self.seed
    }
    base_config = super(CapsuleLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class CapsuleNetLayer(tf.keras.layers.Layer):
  """
    Model: Capsule Net Layer

    Paper: Dynamic Routing Between Capsules

    Link: http://papers.neurips.cc/paper/6975-dynamic-routing-between-capsules.pdf

    Author: Sara Sabour, Nicholas Frosst, Geoffrey E. Hinton

    Developer: anbo

    Date: 2021-11-08

    inputs: 3d tensor (batch_size, n_input_capsules, n_dim)

    outputs: 3d tensor (batch_size, n_output_capsules, n_dim)

  """
  def __init__(self,
               num_capsules=2,
               hidden_units=16,
               routings=3,
               l2_reg=0.001,
               eps=1.e-6,
               seed=1024,
               **kwargs):
    """
    Args:
        hidden_units: int, the last dim of the inputs
        l2_reg: float, regularization value
        eps: float, smooth value to avoid NAN when dividing
        kwargs:

    """
    super(CapsuleNetLayer, self).__init__(**kwargs)
    self.num_capsules = num_capsules
    self.eps = eps
    self.l2_reg = l2_reg
    self.hidden_units = hidden_units
    assert routings > 0, 'The routings must be > 0'
    self.routings = routings
    self.seed = seed

  def build(self, input_shape):
    """
      Args:
          input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

    """
    assert len(input_shape) >= 3, 'The input shape must be at least 3d'
    self.n_input_capsules = int(input_shape[1])
    self.input_dim = int(input_shape[-1])

    self.conv1_layer = tf.keras.layers.Conv2D(filters=256,
                                              kernel_size=9,
                                              strides=1,
                                              padding='valid',
                                              activation='relu',
                                              name='conv1_layer')

    # primary capsule layer
    self.primary_cap_conv2_layer = tf.keras.layers.Conv2D(
        filters=dim_capsule * n_channels,
        kernel_size=kernel_size,
        strides=strides,
        padding=padding,
        name='primary_cap_conv2_layer')
    self.primary_cap_reshape_layer = tf.keras.layers.Reshape(
        target_shape=[-1, dim_capsule], name='primary_cap_reshape_layer')
    self.primary_cap_squash_act_layer = tf.keras.layers.Lambda(
        Squash(eps=eps), name='primary_cap_squash_act_layer')

    # digit capsule layer
    self.digit_cap_layer = CapsuleLayer(num_capsules=num_capsules,
                                        hidden_units=hidden_units,
                                        routings=routings,
                                        l2_reg=l2_reg,
                                        eps=eps,
                                        seed=seed,
                                        name="{}_digit_cap_layer".format(name))

    self.decoder_layer = DNNLayer(hidden_units=projection_hidden_units,
                                  activation=act_fn,
                                  l2_reg=l2_reg,
                                  dropout_rate=dropout_rate,
                                  use_bn=use_bn,
                                  apply_final_act=False,
                                  seed=seed,
                                  name="{}_dnn_layer".format(name))

    super(CapsuleNetLayer, self).build(input_shape)

  def call(self, inputs, mask=None, training=None, **kwargs):
    """
      Args:
          inputs: 3d tensor (batch_size, h, w, n_dim)

      Return:
          3d tensor (batch_size, n_output_capsules, n_dim)

    """
    conv1_output = self.conv1_layer(inputs)
    primary_cap_conv2_output = self.primary_cap_conv2_layer(conv1_output)
    primary_cap_reshaped_output = self.primary_cap_reshape_layer(
        primary_cap_conv2_output)
    primary_cap_act_output = self.primary_cap_squash_act_layer(
        primary_cap_reshaped_output)
    tf.logging.info('CapsuleNetLayer: primary_cap_act_output {}'.format(
        primary_cap_act_output))

    capsule_layer_output = self.digit_cap_layer(primary_cap_act_output)
    tf.logging.info('CapsuleNetLayer: capsule_layer_output {}'.format(
        capsule_layer_output))

    # pooling layer
    pooled_output = tf.sqrt(
        tf.reduce_sum(tf.square(capsule_layer_output), axis=-1) + self.eps)
    tf.logging.info('CapsuleNetLayer: pooled_output {}'.format(pooled_output))

    # decoder layer
    decoder_output = self.decoder_layer(pooled_output)
    decoder_output = tf.nn.sigmoid(decoder_output)

    return decoder_output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    output_shape_1 = input_shape[:1].concatenate(self.num_capsules)
    return output_shape_1.concatenate(self.hidden_units)

  def get_config(self):
    config = {
        'eps': self.eps,
        'l2_reg': self.l2_reg,
        'num_capsules': self.num_capsules,
        'hidden_units': self.hidden_units,
        'routings': self.routings,
        'seed': self.seed
    }
    base_config = super(CapsuleNetLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class BridgeLayer(tf.keras.layers.Layer):
  """
    Model: Bridge Module

    Paper: Enhancing Explicit and Implicit Feature Interactions via Information Sharing for Parallel Deep CTR Models

    Link: https://dl.acm.org/doi/abs/10.1145/3459637.3481915

    Author: Chen, Bo and Wang, Yichao and Liu, Zhirong and Tang, Ruiming and Guo, Wei and Zheng, Hongkun and Yao, Weiwei and Zhang, Muyu and He, Xiuqiang

    Developer: anbo

    Date: 2021-11-16

    inputs: 2d tensor (batch_size, n_dim)

    outputs: 2d tensor (batch_size, n_dim)

    """
  def __init__(self, n_layers=2, l2_reg=0.001, seed=1024, **kwargs):
    """
        Args:
            n_layers: int, number of cross layers
            l2_reg: float, regularization value

        """
    super(BridgeLayer, self).__init__(**kwargs)
    self.n_layers = n_layers
    self.l2_reg = l2_reg
    self.seed = seed

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
    input_size = int(input_shape[-1])

    self.cross_weights, self.cross_bias = [], []
    self.deep_weights, self.deep_bias = [], []

    for i in range(self.n_layers):
      # deep layer weights and bias
      self.deep_weights.append(
          self.add_weight(
              name='deep_weight_' + str(i),
              shape=[input_size, input_size],
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.l2(self.l2_reg),
              trainable=True))
      self.deep_bias.append(
          self.add_weight(name='deep_bias_' + str(i),
                          shape=[
                              input_size,
                          ],
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))

      # cross layer weights and bias
      self.cross_weights.append(
          self.add_weight(
              name='cross_weight_{}'.format(i),
              shape=(input_size, 1),
              initializer=tf.keras.initializers.he_normal(seed=self.seed),
              regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
              trainable=True))
      self.cross_bias.append(
          self.add_weight(name='cross_bias_{}'.format(i),
                          shape=(input_size,),
                          initializer=tf.keras.initializers.Zeros(),
                          trainable=True))

    super(BridgeLayer, self).build(input_shape)

  def call(self, inputs, **kwargs):
    """
        Args:
            inputs: 2d tensor, (batch_size, n_dim)

        Returns:
            2d tensor, (batch_size, n_dim)
        """
    inputs = tf.keras.backend.expand_dims(inputs, axis=1)  # X_0
    bridge_inputs = inputs
    # bridge_inputs (batch, 1, d)

    for i in range(self.n_layers):
      # cross layer
      cross_input = tf.keras.backend.batch_dot(tf.keras.backend.dot(
          bridge_inputs, self.cross_weights[i]),
                                               inputs,
                                               axes=[1, 1]) + bridge_inputs
      cross_input = tf.keras.backend.bias_add(cross_input, self.cross_bias[i])
      tf.logging.info('BridgeLayer: {}th Layer cross_input {}'.format(
          i, cross_input))

      # deep layer
      deep_input = tf.nn.bias_add(
          tf.tensordot(bridge_inputs, self.deep_weights[i], axes=(-1, 0)),
          self.deep_bias[i])
      deep_input = tf.nn.relu(deep_input)

      bridge_inputs = tf.multiply(cross_input, deep_input)
      tf.logging.info('BridgeLayer: {}th Layer bridge_inputs {}'.format(
          i, bridge_inputs))

    output = tf.keras.backend.squeeze(bridge_inputs, axis=1)
    return output

  def compute_output_shape(self, input_shape):
    return input_shape

  def get_config(self):
    config = {
        'n_layers': self.n_layers,
        'l2_reg': self.l2_reg,
        'seed': self.seed
    }
    base_config = super(BridgeLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))


class DCAPLayer(tf.keras.layers.Layer):
  """
  Model: Deep Cross Attentional Product Network

  Paper: DCAP: Deep Cross Attentional Product Network for User Response Prediction

  Link: https://arxiv.org/abs/2105.08649

  Author: Zekai Chen, Fangtian Zhong, Zhumin Chen, Xiao Zhang, Robert Pless, Xiuzhen Cheng

  Developer: anbo

  Date: 2021-11-19

  inputs: 3d tensor (batch_size, seq_len, n_dim)

  outputs: 2d tensor (batch_size, n_dim)

  """
  def __init__(self,
               hidden_units=16,
               heads=4,
               l2_reg=0.001,
               dropout_rate=0.1,
               seed=1024,
               list_tag=False,
               mha_type='origin',
               dim_e=None,
               synthesizer_type='dense',
               window=1,
               concat_heads=True,
               pool_size=2,
               strides=1,
               product_type='inner',
               n_layers=2,
               **kwargs):
    """
    Args:
        n_layers: int, number of cross layers
        l2_reg: float, regularization value
        product_type: string, inner or outer
    """
    super(DCAPLayer, self).__init__(**kwargs)
    self.hidden_units = hidden_units
    self.heads = heads
    self.l2_reg = l2_reg
    self.dropout_rate = dropout_rate
    self.seed = seed
    self.list_tag = list_tag
    self.mha_type = mha_type
    self.dim_e = dim_e
    self.synthesizer_type = synthesizer_type
    self.window = window
    self.concat_heads = concat_heads
    self.n_layers = n_layers
    self.pool_size = pool_size
    self.strides = strides
    self.product_type = product_type

  def build(self, input_shape):
    """
        Args:
            input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

        """
    input_size = int(input_shape[-1])
    self.n_fields = int(input_shape[1])
    self.output_dim = self.n_fields * (self.n_fields - 1) * self.n_layers // 2
    from alps_biz.core.layer.attention import GeneralMultiHeadAttnLayer

    self.mha_layers = []
    self.pooling_layers = []

    for i in range(self.n_layers):
      self.mha_layers.append(
          GeneralMultiHeadAttnLayer(hidden_units=self.hidden_units,
                                    heads=self.heads,
                                    l2_reg=self.l2_reg,
                                    dropout_rate=self.dropout_rate,
                                    seed=self.seed,
                                    list_tag=self.list_tag,
                                    mha_type=self.mha_type,
                                    dim_e=self.dim_e,
                                    synthesizer_type=self.synthesizer_type,
                                    window=self.window,
                                    concat_heads=self.concat_heads,
                                    name='{}th_mha_layer'.format(i)))
      self.pooling_layers.append(
          tf.keras.layers.AveragePooling1D(
              pool_size=self.pool_size,
              strides=self.strides,
              padding='valid',
              data_format='channels_last',
              name='{}th_average_pooling_layer'.format(i)))

    super(DCAPLayer, self).build(input_shape)

  def inner_product_fn(self, input_a, input_b):
    return tf.multiply(input_a, input_b)

  def outer_product_fn(self, input_a, input_b):
    input_a_sum = tf.reduce_sum(tf.expand_dims(input_a, axis=1),
                                axis=-1,
                                keepdims=False)
    input_a_sum = tf.keras.backend.permute_dimensions(input_a_sum,
                                                      pattern=[0, 2, 1])
    # input_a_sum: (batch, fields, 1)
    return tf.multiply(input_a_sum, input_b)

  def enumerate_fields_fn(self):
    import itertools

    left, right = [], []
    for i in range(self.n_fields - 1):
      for j in range(i + 1, self.n_fields):
        left.append(i)
        right.append(j)
    tf.logging.info('DCAPLayer: field_wise_func, left {},\n, right {}'.format(
        left, right))

    return left, right

  def call(self, inputs, mask=None, **kwargs):
    """
    Args:
        inputs: 2d tensor, (batch_size, n_dim)

    Returns:
        2d tensor, (batch_size, n_dim)
    """
    x = inputs
    outputs = []

    left, right = self.enumerate_fields_fn()

    for i in range(self.n_layers):
      z = self.mha_layers[i](x, mask=mask)

      z_pol = tf.gather(params=z, indices=left, axis=1)
      tf.logging.info('DCAPLayer: z_pol {}'.format(z_pol))
      x_pol = tf.gather(params=inputs, indices=right, axis=1)
      tf.logging.info('DCAPLayer: x_pol {}'.format(x_pol))

      if self.product_type == 'inner':
        p = self.inner_product_fn(z_pol, x_pol)
      elif self.product_type == 'outer':
        p = self.outer_product_fn(z_pol, x_pol)
      else:
        raise NotImplementedError

      outputs.append(tf.reduce_sum(p, axis=-1))

      x = self.pooling_layers[i](p)
      tf.logging.info('DCAPLayer: {}th Layer x {}'.format(i, x))

    output = tf.keras.layers.Concatenate(
        axis=-1)(outputs) if len(outputs) > 1 else outputs[0]
    return output

  def compute_output_shape(self, input_shape):
    input_shape = tensor_shape.TensorShape(input_shape)
    input_shape = input_shape.with_rank_at_least(2)
    if tensor_shape.dimension_value(input_shape[-1]) is None:
      raise ValueError(
          'The innermost dimension of input_shape must be defined, but saw: %s'
          % input_shape)
    return input_shape[:1].concatenate(self.output_dim)

  def get_config(self):
    config = {
        'heads': self.heads,
        'hidden_units': self.hidden_units,
        'l2_reg': self.l2_reg,
        'dropout_rate': self.dropout_rate,
        'seed': self.seed,
        'list_tag': self.list_tag,
        'synthesizer_type': self.synthesizer_type,
        'dim_e': self.dim_e,
        'mha_type': self.mha_type,
        'concat_heads': self.concat_heads,
        'window': self.window,
        'n_layers': self.n_layers,
        'pool_size': self.pool_size,
        'strides': self.strides,
        'product_type': self.product_type
    }
    base_config = super(DCAPLayer, self).get_config()
    return dict(list(base_config.items()) + list(config.items()))
