# coding: utf-8
# Copyright (c) Antfin, Inc. All rights reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.framework import tensor_shape


class MultiHeadAttentionLayer(tf.keras.layers.Layer):
    """
      Model: Multi-Head Attention

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is the multi-head self attention module in bert/transformer, depending on self attenton layer

      inputs: 3d tensor, (batch_size, fields, hidden_units)

      outputs: 3d tensor, (batch_size, fields, hidden_units)

      """

    def __init__(self,
                 hidden_units,
                 heads,
                 l2_reg=0.001,
                 dropout_rate=0.1,
                 seed=1024,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 window=1,
                 **kwargs):

        """
            Args:
                hidden_units: int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                l2_reg: float, regularization value
                dropout_rate: float, dropout rate
                seed: float, random seed
                kwargs: other arguments

            """
        super(MultiHeadAttentionLayer, self).__init__(**kwargs)
        assert (hidden_units %
                heads == 0), ('hidden_units must be dividable by heads')
        self.d_k = hidden_units // heads
        self.heads = heads
        self.hidden_units = hidden_units
        self.l2_reg = l2_reg
        self.dropout_rate = dropout_rate
        self.inputs_type = 'tensor'
        self.seed = seed

        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type
        self.window = window

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        dim = int(input_shape[-1])
        self.kernels = []
        self.bias = []
        for i in range(3):
            self.kernels.append(
                self.add_weight(
                    name="kernel_{}".format(i),
                    shape=(dim, self.hidden_units),
                    initializer=tf.keras.initializers.he_normal(seed=self.seed),
                    regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                    trainable=True))
            self.bias.append(
                self.add_weight(name='bias_{}'.format(i),
                                shape=(self.hidden_units,),
                                initializer=tf.keras.initializers.Zeros(),
                                regularizer=tf.keras.regularizers.L1L2(
                                    0, self.l2_reg),
                                trainable=True))

        self.kernels.append(
            self.add_weight(
                name="kernel_4",
                shape=(self.hidden_units, self.hidden_units),
                initializer=tf.keras.initializers.he_normal(seed=self.seed),
                regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                trainable=True))
        self.bias.append(
            self.add_weight(name='bias_4',
                            shape=(self.hidden_units,),
                            initializer=tf.keras.initializers.Zeros(),
                            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                            trainable=True))

        if self.mha_type == 'origin':
            self.attnlayer = SelfAttentionLayer(self.dropout_rate,
                                                name='mha_selfattn_layer')
        else:
            from alps_biz.core.layer.attention import GeneralSelfAttnLayer
            self.attnlayer = GeneralSelfAttnLayer(
                mha_type=self.mha_type,
                dim_e=self.dim_e,
                synthesizer_type=self.synthesizer_type,
                l2_reg=self.l2_reg,
                dropout_rate=self.dropout_rate,
                seed=self.seed,
                inf=self.inf,
                window=self.window,
                name='general_mha_selfattn_layer')

        super(MultiHeadAttentionLayer, self).build(input_shape)

    def call(self, inputs, mask=None, training=None, **kwargs):
        """
            Args:
                inputs: (batch, seq_len, dim)

            Return:
                (batch, seq_len, hidden_units)

            """
        tf.logging.info('multihead inputs {}'.format(inputs))
        seq_len = int(inputs.get_shape().as_list()[1])
        tf.logging.info('multihead seq_len {}'.format(seq_len))
        embedding_dim = int(inputs.get_shape().as_list()[-1])
        # assert (embedding_dim == self.hidden_units), ('embedding dim must equal to d_k')

        query, key, value = [
            tf.keras.backend.reshape(tf.keras.backend.bias_add(
                tf.keras.backend.dot(inputs, self.kernels[i]), self.bias[i]),
                shape=(-1, seq_len, self.heads, self.d_k))
            for i in range(len(self.kernels) - 1)
        ]

        tf.logging.info('multihead query {} '.format(query))
        tf.logging.info('multihead key {} '.format(key))
        tf.logging.info('multihead value {} '.format(value))

        # apply scaled self dot attention
        output = self.attnlayer([query, key, value], mask=mask, training=training)
        tf.logging.info('self attention output {}'.format(output))
        # ouput: (batch, query_len, heads*d_k)

        # concat and apply a final linear layer
        tf.logging.info('self.kernel_4 shape {}'.format(self.kernels[-1]))
        # output = self.kernels[-1](output)
        output = tf.keras.backend.bias_add(
            tf.keras.backend.dot(output, self.kernels[3]), self.bias[3])
        tf.logging.info('multihead output shape {}'.format(output))
        # output: (batch, seq_len, hidden_units), hidden_units = d_model= heads*d_k
        return output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'heads': self.heads,
            'hidden_units': self.hidden_units,
            'l2_reg': self.l2_reg,
            'dropout_rate': self.dropout_rate,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type,
            'window': self.window
        }
        base_config = super(MultiHeadAttentionLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


def create_padding_mask(seq):
    seq = tf.cast(tf.math.equal(seq, 0), tf.float32)

    return seq[:, tf.newaxis, tf.newaxis, :]  # (batch_size, 1, 1, seq_len)


class SelfAttentionLayer(tf.keras.layers.Layer):
    """
      Model: Self Attention

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is the scaled dot self-attention part in bert/transformer.

      inputs: list with length of 3, [query, key, value]
          query: (batch, q_len, heads, d_k)
          key: (batch, k_len, heads, d_k)
          value: (batch, k_len, heads, d_k)

      return: 3d tensor, (batch, q_len, heads*d_k), hereby heads*d_k = hidden_units

      """

    def __init__(self, dropout_rate=0.1, **kwargs):
        """
            Args:
                dropout_rate: float, dropout rate
                kwargs:

            """
        super(SelfAttentionLayer, self).__init__(**kwargs)
        self.dropout_rate = dropout_rate

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        self.dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                               name='dropout_layer')
        super(SelfAttentionLayer, self).build(input_shape)

    def call(self, inputs, mask=None, training=None, **kwargs):
        """
            Args:
                inputs: list of [query, key, value]

            Returns:
                (batch, seq_len, heads*d_k)

            """
        # query: (batch, query_len, heads, d_k)
        # key: (batch, key_len, heads, d_k)
        # value: (batch, key_len, heads, d_k)
        query, key, value = inputs
        query_len = int(query.get_shape()[1])
        key_len = int(key.get_shape()[1])
        heads = int(query.get_shape()[2])
        d_k = int(query.get_shape()[3])
        tf.logging.info('self attention layer, query {}, key {}, value {}'.format(
            query, key, value))
        self.heads = heads
        self.d_k = d_k

        query = tf.keras.backend.permute_dimensions(query, (0, 2, 1, 3))
        # query (batch, heads, q_len, d_k)
        key = tf.keras.backend.permute_dimensions(key, (0, 2, 3, 1))
        # key (batch, heads, d_k, q_len)
        tf.logging.info('self attention query {}, key {}'.format(query, key))

        scores = tf.keras.backend.batch_dot(query, key, axes=[3, 2])
        # scores (batch, heads, q_len, q_len)
        tf.logging.info('self attention batch_dot scores shape {}'.format(scores))
        scores = tf.keras.layers.Lambda(lambda x: tf.multiply(
            x, 1. / tf.sqrt(tf.cast(d_k, tf.float32))))(scores)
        # tf.logging.info('self attention scale scores shape {}'.format(scores))
        # scores: (batch, heads, query_len, key_len)

        if mask is not None:
            tf.logging.info('self: mask {}'.format(mask))
            # seq_mask = create_padding_mask(mask)
            scores += -1e9 * tf.cast(mask, tf.float32)

        scores = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, -1))(scores)
        # tf.logging.info('self attention softmax scores shape {}'.format(scores))
        scores = self.dropout(scores, training=training)

        attn_weight = tf.keras.backend.batch_dot(
            scores, tf.keras.backend.permute_dimensions(value, (0, 2, 1, 3)))
        # attn_weight (batch, heads, q_len, d_k)
        tf.logging.info(
            'self attention dot attn_weight shape {}'.format(attn_weight))
        # attn_weight: (batch, heads, query_len, d_k)
        attn_weight = tf.keras.backend.reshape(attn_weight,
                                               shape=[-1, query_len, heads * d_k])
        tf.logging.info('self attention attn_weight shape {}'.format(attn_weight))
        # attn_weight: (batch, query_len, heads*d_k)
        return attn_weight

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape[0])
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)
        return input_shape[:2].concatenate(self.heads * self.d_k)

    def get_config(self):
        config = {'dropout_rate': self.dropout_rate}
        base_config = super(SelfAttentionLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class LayerNorm(tf.keras.layers.Layer):
    """
      Model: Layer normalization

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is the LayerNorm in bert/transformer.

      inputs: 3d tensor (batch, len, hidden_units)

      output: 3d tensor (batch, len, hidden_units)

      """

    def __init__(self, hidden_units=None, l2_reg=0.001, eps=1.e-6, **kwargs):
        """
            Args:
                hidden_units: int, the last dim of the inputs
                l2_reg: float, regularization value
                eps: float, smooth value to avoid NAN when dividing
                kwargs:

            """
        super(LayerNorm, self).__init__(**kwargs)
        # self.hidden_units = hidden_units
        self.eps = eps
        self.l2_reg = l2_reg

    def build(self, input_shape):
        """
             Args:
                 input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        self.hidden_units = int(input_shape[-1])
        self.kernel = self.add_weight(name='weight_ln',
                                      shape=(self.hidden_units,),
                                      initializer=tf.keras.initializers.Ones(),
                                      regularizer=tf.keras.regularizers.L1L2(
                                          0, self.l2_reg),
                                      trainable=True)
        self.bias = self.add_weight(name='bias_ln',
                                    shape=(self.hidden_units,),
                                    initializer=tf.keras.initializers.Zeros(),
                                    regularizer=tf.keras.regularizers.L1L2(
                                        0, self.l2_reg),
                                    trainable=True)
        super(LayerNorm, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
            Args:
                inputs: 3d tensor (batch, len, hidden_units)

            Return:
                3d tensor, the same shape as inputs, (batch, len, hidden_units)

            """
        mean = tf.keras.backend.mean(inputs, axis=-1, keepdims=True)
        # tf.logging.info('LayerNorm mean shape {}'.format(mean))
        var = tf.keras.backend.mean(tf.keras.backend.square(inputs - mean),
                                    axis=-1,
                                    keepdims=True)
        # tf.logging.info('LayerNorm var shape {}'.format(var))
        output = tf.keras.layers.Lambda(lambda x:
                                        (x[0] - x[1]) / tf.sqrt(x[2] + self.eps))(
            [inputs, mean, var])
        # tf.logging.info('LayerNorm output shape {}'.format(output))
        # tf.logging.info('LayerNorm kernel shape {}, bias shape {}'.format(self.kernel, self.bias))
        output = tf.keras.layers.Lambda(lambda x: tf.multiply(x[0], x[1]))(
            [output, self.kernel])
        tf.logging.info('LayerNorm multiply output shape {}'.format(output))
        output = tf.keras.backend.bias_add(output, self.bias)
        # tf.logging.info('Layer Norm output shape {}'.format(output))
        return output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'eps': self.eps,
            'l2_reg': self.l2_reg,
            'hidden_units': self.hidden_units
        }
        base_config = super(LayerNorm, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class PositionWiseFeedForwardLayer(tf.keras.layers.Layer):
    """
      Model: Position-wise Feed Forward layer

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is position-wise feed-forward networks.

      .. code-block:: python

          F = LeakyRelu(S'*W + b)*w + b)
          #F = LayerNorm(S' + Dropout()

      inputs: (batch, seq_len, hidden_units)

      returns: (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 intermediate_size,
                 hidden_units,
                 l2_reg=0.001,
                 act_fn='relu',
                 seed=1024,
                 **kwargs):
        """
            Args:
                intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
                hidden_units: int, int, the last dim of the inputs
                l2_reg: float, regularization value
                dropout_rate: float, dropout rate
                act_fn: string, activation function
                kwargs:

            """
        super(PositionWiseFeedForwardLayer, self).__init__(**kwargs)
        self.intermediate_size = intermediate_size
        self.hidden_units = hidden_units
        self.act_fn = act_fn
        self.l2_reg = l2_reg
        self.seed = seed

    def build(self, input_shape):
        """
             Args:
                 input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        dim = int(input_shape[-1])
        self.kernels, self.bias = [], []
        self.kernels.append(
            self.add_weight(
                name="kernel_0",
                shape=(dim, self.intermediate_size),
                initializer=tf.keras.initializers.he_normal(seed=self.seed),
                regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                trainable=True))
        self.bias.append(
            self.add_weight(name='bias_0',
                            shape=(self.intermediate_size,),
                            initializer=tf.keras.initializers.Zeros(),
                            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                            trainable=True))
        self.kernels.append(
            self.add_weight(
                name="kernel_1",
                shape=(self.intermediate_size, self.hidden_units),
                initializer=tf.keras.initializers.he_normal(seed=self.seed),
                regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                trainable=True))
        self.bias.append(
            self.add_weight(name='bias_1',
                            shape=(self.hidden_units,),
                            initializer=tf.keras.initializers.Zeros(),
                            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
                            trainable=True))

    def call(self, inputs, **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Returns:
                (batch, seq_len, hidden_units)

            """
        intermediate_output = tf.keras.backend.bias_add(
            tf.keras.backend.dot(inputs, self.kernels[0]), self.bias[0])
        tf.logging.info(
            'PositionWiseFeedForwardLayer: intermediate_output {}'.format(
                intermediate_output))
        # only apply activation func in this layer
        # intermediate_output = tf.keras.layers.Lambda(lambda x: tf.nn.leaky_relu(x))(intermediate_output)
        intermediate_output = tf.keras.layers.Lambda(lambda x: tf.nn.relu(x))(
            intermediate_output)

        # tf.logging.info('PositionWiseFeedForwardLayer: intermediate_output {}'.format(intermediate_output))

        layer_output = tf.keras.backend.bias_add(
            tf.keras.backend.dot(intermediate_output, self.kernels[1]),
            self.bias[1])
        tf.logging.info(
            'PositionWiseFeedForwardLayer: layer_output {}'.format(layer_output))
        return layer_output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'act_fn': self.act_fn,
            'l2_reg': self.l2_reg,
            'intermediate_size': self.intermediate_size,
            'seed': self.seed
        }
        base_config = super(PositionWiseFeedForwardLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class TransformerLayer(tf.keras.layers.Layer):
    """
      Model: One Transformer Encoder Layer

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is one transformer encoder layer, which includes: multiheadattention, add & norm, feedforward, add & norm layer

      inputs: (batch, seq_len, hidden_units)

      output: (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 hidden_units,
                 heads,
                 intermediate_size,
                 act_fn='relu',
                 dropout_rate=0.1,
                 l2_reg=0.001,
                 seed=1024,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 window=1,
                 **kwargs):
        """
            Args:
                hidden_units: int, int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
                act_fn: string, activation function
                dropout_rate: float, dropout rate
                l2_reg: float, regularization value
                kwargs:

            """
        super(TransformerLayer, self).__init__(**kwargs)
        self.hidden_units = hidden_units
        self.heads = heads
        self.intermediate_size = intermediate_size
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.seed = seed

        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type
        self.window = window

    def build(self, input_shape):
        """
             Args:
                 input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        dim = int(input_shape[-1])
        self.pre_ln = LayerNorm(dim, name='pre_ln_layer')
        self.multiheadattention = MultiHeadAttentionLayer(
            hidden_units=self.hidden_units,
            heads=self.heads,
            l2_reg=self.l2_reg,
            dropout_rate=self.dropout_rate,
            seed=self.seed,
            mha_type=self.mha_type,
            dim_e=self.dim_e,
            synthesizer_type=self.synthesizer_type,
            inf=self.inf,
            window=self.window,
            name='mha_layer')
        self.last_ln = LayerNorm(self.hidden_units, name='last_ln_layer')
        self.pre_dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                                   name='pre_dropout_layer')
        self.last_dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                                    name='last_dropout_layer')
        self.feedlayer = PositionWiseFeedForwardLayer(self.intermediate_size,
                                                      self.hidden_units,
                                                      self.l2_reg,
                                                      self.act_fn,
                                                      self.seed,
                                                      name='pwff_layer')
        super(TransformerLayer, self).build(input_shape)

    def call(self, inputs, mask=None, training=None, lego='standard', **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Return:
                (batch, seq_len, hidden_units)

            """
        if lego == 'standard':
            attention_output = self.multiheadattention(inputs,
                                                       mask=mask,
                                                       training=training)
            tf.logging.info('muithead output {}'.format(attention_output))
            attention_output = self.pre_dropout(attention_output, training=training)
            attention_output = self.pre_ln(inputs + attention_output)
            tf.logging.info(
                'transformer sublayer output {}'.format(attention_output))

            layer_output = self.feedlayer(attention_output)
            layer_output = self.last_dropout(layer_output, training=training)
            layer_output = self.last_ln(attention_output + layer_output)
            tf.logging.info(
                'transformer feedforward layer output {}'.format(layer_output))

        elif lego == 'preln':
            pre_ln_out1 = self.pre_ln(inputs)
            attn_output = self.multiheadattention(pre_ln_out1,
                                                  mask=mask,
                                                  training=training)
            attn_output = self.pre_dropout(attn_output, training=training)
            out1 = inputs + attn_output

            pre_ln_out2 = self.last_ln(out1)
            ffn_output = self.feedlayer(
                pre_ln_out2)  # (batch_size, input_seq_len, d_model)
            ffn_output = self.last_dropout(ffn_output, training=training)
            layer_output = out1 + ffn_output  # (batch_size, input_seq_len, d_model)

        return layer_output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'heads': self.heads,
            'act_fn': self.act_fn,
            'dropout_rate': self.dropout_rate,
            'l2_reg': self.l2_reg,
            "intermediate_size": self.intermediate_size,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type,
            'window': self.window
        }
        base_config = super(TransformerLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class TransformerEncoder(tf.keras.layers.Layer):
    """
      Model: Whole Transformer Encoder Layer

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2019-11-30

      This is the whole encoder layer of bert/transformer. It may include multiple TransformerLayer

      inputs: (batch, seq_len, dim)

      return: (batch, seq_len, hidden_units) if return_all_layers is False, otherwise, return list of (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 n_layers,
                 hidden_units,
                 heads,
                 intermediate_size,
                 act_fn='relu',
                 dropout_rate=0.1,
                 l2_reg=0.001,
                 return_all_layers=False,
                 seed=1024,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 window=1,
                 **kwargs):
        """
            Args:
                n_layers: int, num of transformer encoder layers
                hidden_units: int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
                act_fn: string, activation function
                dropout_rate: float, dropout rate
                l2_reg: float, regularization value
                return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
                kwargs:

            """
        super(TransformerEncoder, self).__init__(**kwargs)
        self.n_layers = n_layers
        self.hidden_units = hidden_units
        self.heads = heads
        self.intermediate_size = intermediate_size
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.return_all_layers = return_all_layers
        self.seed = seed

        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type
        self.window = window

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        self.layers = [
            TransformerLayer(self.hidden_units,
                             self.heads,
                             self.intermediate_size,
                             self.act_fn,
                             self.dropout_rate,
                             self.l2_reg,
                             self.seed,
                             mha_type=self.mha_type,
                             dim_e=self.dim_e,
                             synthesizer_type=self.synthesizer_type,
                             inf=self.inf,
                             window=self.window,
                             name='transformer_{}_layer'.format(i))
            for i in range(self.n_layers)
        ]

        super(TransformerEncoder, self).build(input_shape)

    def call(self, inputs, mask=None, training=None, lego='standard', **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Returns:
                (batch, seq_len, hidden_units) if return_all_layers is False, otherwise,
                return list of (batch, seq_len, hidden_units)

            """
        output = []
        output_i = inputs
        for i in range(self.n_layers):
            output_i = self.layers[i](output_i,
                                      mask=mask,
                                      training=training,
                                      lego=lego)
            tf.logging.info('TransformerEncoder output layer {} shape: {}'.format(
                i, output_i))
            if self.return_all_layers:
                output.append(output_i)

        if not self.return_all_layers:
            return output_i

        return output

    def compute_output_shape(self, input_shape):
        # if self.return_all_layers:
        #     return [input_shape for _ in range(self.n_layers)]
        # else:
        #     return input_shape
        input_shape = tensor_shape.TensorShape(input_shape)
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)

        if self.return_all_layers:
            return [input_shape for _ in range(self.n_layers)]
        else:
            return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'n_layers': self.n_layers,
            'heads': self.heads,
            'act_fn': self.act_fn,
            'dropout_rate': self.dropout_rate,
            'l2_reg': self.l2_reg,
            'return_all_layers': self.return_all_layers,
            "intermediate_size": self.intermediate_size,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type,
            'window': self.window
        }
        base_config = super(TransformerEncoder, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class TransformerDecoderLayer(tf.keras.layers.Layer):
    """
      Model: One Transformer Decoder Layer

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2020-07-22

      This is one transformer decoder layer, which includes: multiheadattention, add & norm, feedforward, add & norm layer

      inputs: (batch, seq_len, hidden_units)

      output: (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 hidden_units,
                 heads,
                 intermediate_size,
                 act_fn='relu',
                 dropout_rate=0.1,
                 l2_reg=0.001,
                 seed=1024,
                 list_tag=True,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 **kwargs):
        """
            Args:
                hidden_units: int, int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
                act_fn: string, activation function
                dropout_rate: float, dropout rate
                l2_reg: float, regularization value
                kwargs:

            """
        super(TransformerDecoderLayer, self).__init__(**kwargs)
        self.hidden_units = hidden_units
        self.heads = heads
        self.intermediate_size = intermediate_size
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.seed = seed
        self.list_tag = list_tag
        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type

    def build(self, input_shape):
        """
             Args:
                 input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        dim = int(input_shape[-1])
        self.ln_1 = LayerNorm(dim, name='decoder_ln_1_layer')
        self.ln_2 = LayerNorm(dim, name='decoder_ln_2_layer')
        self.ln_3 = LayerNorm(dim, name='decoder_ln_3_layer')

        from alps_biz.core.layer.attention import GeneralMultiHeadAttnLayer
        self.mha_1 = GeneralMultiHeadAttnLayer(
            hidden_units=self.hidden_units,
            heads=self.heads,
            l2_reg=self.l2_reg,
            dropout_rate=self.dropout_rate,
            seed=self.seed,
            list_tag=self.list_tag,
            mha_type=self.mha_type,
            dim_e=self.dim_e,
            synthesizer_type=self.synthesizer_type,
            inf=self.inf,
            name='decoder_mha_1_layer')

        self.mha_2 = GeneralMultiHeadAttnLayer(
            hidden_units=self.hidden_units,
            heads=self.heads,
            l2_reg=self.l2_reg,
            dropout_rate=self.dropout_rate,
            seed=self.seed,
            list_tag=self.list_tag,
            mha_type=self.mha_type,
            dim_e=self.dim_e,
            synthesizer_type=self.synthesizer_type,
            inf=self.inf,
            name='decoder_mha_2_layer')

        self.dropout_1 = tf.keras.layers.Dropout(self.dropout_rate,
                                                 name='decoder_dropout_1_layer')
        self.dropout_2 = tf.keras.layers.Dropout(self.dropout_rate,
                                                 name='decoder_dropout_2_layer')
        self.dropout_3 = tf.keras.layers.Dropout(self.dropout_rate,
                                                 name='decoder_dropout_3_layer')

        self.feedlayer = PositionWiseFeedForwardLayer(self.intermediate_size,
                                                      self.hidden_units,
                                                      self.l2_reg,
                                                      self.act_fn,
                                                      self.seed,
                                                      name='decoder_pwff_layer')

        super(TransformerDecoderLayer, self).build(input_shape)

    def call(self,
             inputs,
             enc_output,
             look_ahead_mask=None,
             padding_mask=None,
             training=None,
             lego='standard',
             **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Return:
                (batch, seq_len, hidden_units)

            """
        attention_output = self.mha_1([inputs, inputs, inputs],
                                      mask=look_ahead_mask,
                                      training=training)
        attention_output = self.dropout_1(attention_output, training=training)
        attention_output = self.ln_1(inputs + attention_output)
        tf.logging.info('decoder attention_output {}'.format(attention_output))

        # attention_output_2 = self.mha_2([enc_output, enc_output, attention_output], mask=padding_mask, training=training)
        attention_output_2 = self.mha_2([attention_output, enc_output, enc_output],
                                        mask=padding_mask,
                                        training=training)
        attention_output_2 = self.dropout_2(attention_output_2, training=training)
        mha_output_2 = self.ln_2(attention_output + attention_output_2)
        tf.logging.info('decoder mha_output_2 {}'.format(mha_output_2))

        ffn_output = self.feedlayer(mha_output_2)
        ffn_output = self.dropout_3(ffn_output, training=training)
        output_3 = self.ln_3(ffn_output + mha_output_2)

        return output_3

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'heads': self.heads,
            'act_fn': self.act_fn,
            'dropout_rate': self.dropout_rate,
            'l2_reg': self.l2_reg,
            "intermediate_size": self.intermediate_size,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type,
            'list_tag': self.list_tag
        }
        base_config = super(TransformerDecoderLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class TransformerDecoder(tf.keras.layers.Layer):
    """
      Model: Whole Transformer Decoder Layer

      Paper: Attention Is All You Need

      Link: https://arxiv.org/abs/1706.03762

      Author: Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin

      Developer: anbo

      Date: 2020-07-22

      This is the whole encoder layer of bert/transformer. It may include multiple TransformerLayer

      inputs: (batch, seq_len, dim)

      return: (batch, seq_len, hidden_units) if return_all_layers is False, otherwise, return list of (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 n_dec_layers,
                 hidden_units,
                 heads,
                 intermediate_size,
                 act_fn='relu',
                 dropout_rate=0.1,
                 l2_reg=0.001,
                 return_all_layers=False,
                 seed=1024,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 list_tag=True,
                 **kwargs):
        """
            Args:
                n_layers: int, num of transformer encoder layers
                hidden_units: int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                intermediate_size: int, units in dense layer, normally intermediate_size=4*hidden_units
                act_fn: string, activation function
                dropout_rate: float, dropout rate
                l2_reg: float, regularization value
                return_all_layers: boolean, if True return list of (batch, seq_len, hidden_units), otherwise return (batch, seq_len, hidden_units)
                kwargs:

            """
        super(TransformerDecoder, self).__init__(**kwargs)
        self.n_dec_layers = n_dec_layers
        self.hidden_units = hidden_units
        self.heads = heads
        self.intermediate_size = intermediate_size
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.return_all_layers = return_all_layers
        self.seed = seed
        self.list_tag = list_tag

        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        self.layers = [
            TransformerDecoderLayer(self.hidden_units,
                                    self.heads,
                                    self.intermediate_size,
                                    self.act_fn,
                                    self.dropout_rate,
                                    self.l2_reg,
                                    self.seed,
                                    list_tag=self.list_tag,
                                    mha_type=self.mha_type,
                                    dim_e=self.dim_e,
                                    synthesizer_type=self.synthesizer_type,
                                    inf=self.inf,
                                    name='transformer_decoder_{}_layer'.format(i))
            for i in range(self.n_dec_layers)
        ]

        super(TransformerDecoder, self).build(input_shape)

    def call(self,
             inputs,
             enc_output,
             look_ahead_mask=None,
             padding_mask=None,
             training=None,
             lego='standard',
             **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Returns:
                (batch, seq_len, hidden_units) if return_all_layers is False, otherwise,
                return list of (batch, seq_len, hidden_units)

            """
        output = inputs
        for i in range(self.n_dec_layers):
            output = self.layers[i](output,
                                    enc_output=enc_output,
                                    look_ahead_mask=look_ahead_mask,
                                    padding_mask=padding_mask,
                                    training=training,
                                    lego=lego)
            tf.logging.info('TransformerDecoder output layer {} shape: {}'.format(
                i, output))

        return output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'n_layers': self.n_layers,
            'heads': self.heads,
            'act_fn': self.act_fn,
            'dropout_rate': self.dropout_rate,
            'l2_reg': self.l2_reg,
            'return_all_layers': self.return_all_layers,
            "intermediate_size": self.intermediate_size,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type,
            'list_tag': self.list_tag
        }
        base_config = super(TransformerDecoder, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class AutoIntLayer(tf.keras.layers.Layer):
    """
      Model: AutoInt Layer

      Paper: AutoInt: Automatic Feature Interaction Learning via Self-Attentive Neural Networks

      Link: https://arxiv.org/abs/1810.11921

      Author: Weiping Song, Chence Shi, Zhiping Xiao, Zhijian Duan, Yewen Xu, Ming Zhang, Jian Tang

      Developer: anbo

      Date: 2019-11-30

      This is the interacting layer in AutoInt, which includes: multiheadattention, add & layer norm

      inputs: (batch, seq_len, hidden_units)

      output: (batch, seq_len, hidden_units)

      """

    def __init__(self,
                 hidden_units,
                 heads,
                 act_fn='relu',
                 dropout_rate=0.1,
                 l2_reg=0.001,
                 seed=1024,
                 mha_type='origin',
                 dim_e=None,
                 synthesizer_type='dense',
                 inf=1e9,
                 **kwargs):
        """
            Args:
                hidden_units: int, the last dim of the inputs
                heads: int, num of self-attention modules, must be dividable by hidden_units
                act_fn: string, activation function
                dropout_rate: float, dropout rate
                l2_reg: float, regularization value
                kwargs:

            """
        super(AutoIntLayer, self).__init__(**kwargs)
        self.hidden_units = hidden_units
        self.heads = heads
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.seed = seed

        self.dim_e = dim_e
        self.inf = inf
        self.synthesizer_type = synthesizer_type
        self.mha_type = mha_type

    def build(self, input_shape):
        """
              Args:
                  input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        # self.multiheadattention = MultiHeadAttentionLayer(self.hidden_units, self.heads, self.l2_reg, self.dropout_rate, self.seed, name='mha_layer')
        self.multiheadattention = MultiHeadAttentionLayer(
            hidden_units=self.hidden_units,
            heads=self.heads,
            l2_reg=self.l2_reg,
            dropout_rate=self.dropout_rate,
            seed=self.seed,
            mha_type=self.mha_type,
            dim_e=self.dim_e,
            synthesizer_type=self.synthesizer_type,
            inf=self.inf,
            name='mha_layer')
        self.layernorm = LayerNorm(self.hidden_units, name='ln_layer')
        self.dropout = tf.keras.layers.Dropout(self.dropout_rate,
                                               name='dropout_layer')
        super(AutoIntLayer, self).build(input_shape)

    def call(self, inputs, training=None, lego='standard', **kwargs):
        """
            Args:
                inputs: (batch, seq_len, hidden_units)

            Return:
                (batch, seq_len, hidden_units)

            """
        multi_input = self.layernorm(inputs)
        attention_output = self.multiheadattention(multi_input,
                                                   training=training,
                                                   lego=lego)
        tf.logging.info(
            'AutoIntLayer: muithead output {}'.format(attention_output))
        attention_output = self.dropout(attention_output, training=training)
        attention_output = inputs + attention_output
        # attention_output = self.layernorm(inputs + attention_output)
        tf.logging.info(
            'AutoIntLayer: sublayer output {}'.format(attention_output))

        return attention_output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'hidden_units': self.hidden_units,
            'heads': self.heads,
            'act_fn': self.act_fn,
            'dropout_rate': self.dropout_rate,
            'l2_reg': self.l2_reg,
            'seed': self.seed,
            'inf': self.inf,
            'synthesizer_type': self.synthesizer_type,
            'dim_e': self.dim_e,
            'mha_type': self.mha_type
        }
        base_config = super(AutoIntLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class FuseLayer(tf.keras.layers.Layer):
    """
      Model: Fuse Layer in DIN Model

      Paper: Deep Interest Network for Click-Through Rate Prediction

      Link: https://arxiv.org/abs/1706.06978

      Author: Guorui Zhou, Chengru Song, Xiaoqiang Zhu, Ying Fan, Han Zhu, Xiao Ma, Yanghui Yan, Junqi Jin, Han Li, Kun Gai

      Developer: anbo

      Date: 2019-11-30

      fuse layer, aka the local activation unit: tanh(w . [p, q, p*q, p-q] + b)
      this is the local activation unit in DIN paper

      inputs: list with lenght of 2, [input_a, input_b]
          input_a : (batch, a_len, dim)
          input_b: (batch, a_len, dim) or (batch, dim)

      outputs: (batch, a_len, output_size)

      """

    def __init__(self,
                 input_length=30,
                 hidden_units=[36],
                 act_fn='sigmoid',
                 l2_reg=0.001,
                 dropout_rate=0.1,
                 use_bn=False,
                 seed=1024,
                 weight_norm=False,
                 **kwargs):
        """
            Args:
                input_length: int, sequence length of behaviour features
                hidden_units: list, units for the MLP layer
                act_fn: string, activation function
                l2_reg: float, regularization value
                dropout_rate: float, dropout rate
                use_bn: boolean, if True use BatchNormalization, otherwise not
                seed: int, random value
                weight_norm: boolean, if True scale the attention score
                kwargs:

            """
        super(FuseLayer, self).__init__(**kwargs)
        self.hidden_units = hidden_units
        self.l2_reg = l2_reg
        self.act_fn = act_fn
        self.dropout_rate = dropout_rate
        self.use_bn = use_bn
        self.seed = seed
        self.weight_norm = weight_norm
        self.input_length = input_length

    def build(self, input_shape):
        """
            Args:
                input_shape: Shape tuple (tuple of integers) or list of shape tuples (one per output tensor of the layer).

            """
        input_size = int(input_shape[0][-1]) * 4 if len(
            self.hidden_units) == 0 else self.hidden_units[-1]
        local_act_dim = int(input_shape[0][-1]) * 4

        # from alps_biz.core.layer.core import DNNLayer
        # self.dnn = DNNLayer(self.hidden_units, self.act_fn, self.l2_reg, self.dropout_rate, self.use_bn, self.seed)
        from alps_biz.core.layer.activation_layer import Dice
        self.local_act_fn = Dice(axis=-1, epsilon=1.e-9, name='dice_layer')
        self.local_weight = self.add_weight(
            name='local_weight',
            shape=(local_act_dim, self.hidden_units[-1]),
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
            trainable=True)

        self.local_bias = self.bias = self.add_weight(
            name='local_bias',
            shape=(self.hidden_units[-1],),
            initializer=tf.keras.initializers.Zeros(),
            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
            trainable=True)

        self.weight = self.add_weight(
            name='weight',
            shape=(input_size, 1),
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
            trainable=True)

        self.bias = self.add_weight(name='bias',
                                    shape=(1,),
                                    initializer=tf.keras.initializers.Zeros(),
                                    regularizer=tf.keras.regularizers.L1L2(
                                        0, self.l2_reg),
                                    trainable=True)
        super(FuseLayer, self).build(input_shape)

    def submat(self, input_a, input_b):
        """
            Args:
                input_a: 3d tensor, (batch, len, dim)
                input_b: tensor (batch, len, dim), must have the same shape as input_a

            Returns:
                3d tensor, (batch, len, 4*dim)

            """
        sub_a = tf.keras.layers.Lambda(lambda x: tf.subtract(x[0], x[1]))(
            [input_a, input_b])
        mat_a = tf.keras.layers.Lambda(lambda x: tf.multiply(x[0], x[1]))(
            [input_a, input_b])
        return tf.keras.layers.Concatenate(axis=-1)(
            [input_a, input_b, sub_a, mat_a])

    def call(self, inputs, training=None, **kwargs):
        """
            Args:
                inputs: list of tensors, (input_a, input_b)
                    input_a: (batch, a_len, dim)
                    input_b: (batch, a_len, dim) or (batch, dim)

            Returns:
                (batch, output_size)

            """
        input_a, input_b = inputs

        if tf.keras.backend.ndim(input_b) == 2:
            input_b = tf.keras.backend.expand_dims(input_b, axis=1)
            print(input_b)

        # len_a = input_a.get_shape().as_list()[1]
        len_a = self.input_length
        len_b = input_b.get_shape().as_list()[1]

        if len_a > len_b:
            input_b = tf.keras.backend.repeat_elements(input_b, len_a, 1)

        features = self.submat(input_a, input_b)
        # features: (batch, len_a, dim*4)
        tf.logging.info('FuseLayer features {}'.format(features))
        # score = self.dnn(features, training=training)
        score = tf.keras.backend.bias_add(
            tf.keras.backend.dot(features, self.local_weight), self.local_bias)
        # scores: (batch, len_a, hidden_units[-1])
        score = self.local_act_fn(score, training=training)
        score = tf.keras.backend.bias_add(tf.keras.backend.dot(score, self.weight),
                                          self.bias)
        # score (batch, len_a, 1)
        tf.logging.info('FuseLayer score {}'.format(score))
        score = tf.keras.backend.permute_dimensions(score, [0, 2, 1])
        # score: (batch, 1, len_a)
        if self.weight_norm:
            score = tf.keras.layers.Lambda(lambda x: x ** 0.5)(score)
            score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x))(score)
        output = tf.keras.backend.batch_dot(score, input_a)
        # output: (batch, 1, dim)
        tf.logging.info('FuseLayer output {}'.format(output))
        return tf.keras.backend.squeeze(output, axis=1)

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape[0])
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)
        return input_shape[:1].concatenate(input_shape[-1])

    def get_config(self):
        config = {
            'l2_reg': self.l2_reg,
            'seed': self.seed,
            'hidden_units': self.hidden_units,
            'act_fn': self.act_fn,
            'input_length': self.input_length,
            'use_bn': self.use_bn,
            'dropout_rate': self.dropout_rate,
            'weight_norm': self.weight_norm
        }
        base_config = super(FuseLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class SimpleAttnLayer(tf.keras.layers.Layer):
    """
      Model: Simple attention layer in sequence model

      Developer: anbo

      Date: 2020-02-10

      inputs: list with lenght of 2, [input_a, input_b]
          input_a: (batch, a_len, dim)
          input_b: (batch, dim)

      outputs: (batch, dim)

      """

    def __init__(self, input_length=30, l2_reg=0.001, seed=1024, **kwargs):
        """
            Args:
                input_length: int, length of the input sequence
                l2_reg: float, regularization value
                kwargs:

            """
        super(SimpleAttnLayer, self).__init__(**kwargs)
        self.l2_reg = l2_reg
        self.input_length = input_length
        self.seed = seed

    def build(self, input_shape):
        dim_a = int(input_shape[0][-1])
        dim_b = int(input_shape[1][-1])
        self.weight = self.add_weight(
            name='weight',
            shape=(dim_a + dim_b, 1),
            initializer=tf.keras.initializers.he_normal(seed=self.seed),
            regularizer=tf.keras.regularizers.L1L2(0, self.l2_reg),
            trainable=True)

        super(SimpleAttnLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
            Args:
                inputs: list of tensors, (input_a, input_b)
                    input_a: (batch, a_len, dim)
                    input_b: (batch, dim)
            Returns:
                (batch, dim)

            """
        input_a, input_b = inputs

        if tf.keras.backend.ndim(input_b) == 2:
            input_b = tf.keras.backend.expand_dims(input_b, axis=1)
            # input_b: (batch, 1, dim)
            tf.logging.info('SimpleAttnLayer: input_b {}'.format(input_b))

        input_b_tile = tf.keras.layers.Lambda(
            lambda x: tf.tile(x, [1, self.input_length, 1]))(input_b)
        tf.logging.info('SimpleAttnLayer: input_b_tile {}'.format(input_b_tile))
        concat_input = tf.keras.layers.Concatenate(axis=-1)(
            [input_a, input_b_tile])
        # concat_input: (b, len_a, dim_a+dim_b)
        tf.logging.info('SimpleAttnLayer: concat_input {}'.format(concat_input))

        attn_weights = tf.keras.backend.dot(concat_input, self.weight)
        # attn_weights: (b, len_a, 1)
        tf.logging.info('SimpleAttnLayer: attn_weights {}'.format(attn_weights))

        score = tf.keras.layers.Lambda(lambda x: tf.nn.softmax(x, axis=1))(
            attn_weights)
        output = tf.keras.backend.batch_dot(input_a, score, axes=[1, 1])
        # output: (b, dim, 1)
        tf.logging.info('SimpleAttnLayer: output {}'.format(output))
        output = tf.keras.layers.Lambda(lambda x: tf.squeeze(x, axis=-1))(output)
        return output

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape[0])
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)
        return input_shape[:1].concatenate(input_shape[-1])

    def get_config(self):
        config = {
            'l2_reg': self.l2_reg,
            'input_length': self.input_length,
            'seed': self.seed
        }
        base_config = super(SimpleAttnLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class MultiCNNLayer(tf.keras.layers.Layer):
    """
      Model: multi channel cnn layer in sequence model

      Developer: anbo

      Date: 2020-02-10

      inputs: (batch, a_len, dim)

      outputs: (batch, a_len, total_filters)

      """

    def __init__(self, filters=[4, 4, 4], kernel_size=[1, 3, 6], **kwargs):
        """
            Args:
                filters: list, number of filters in each 1d conv channel
                kernel_size: list, number of kernel filter size in each 1d conv channel
                kwargs:
            """
        super(MultiCNNLayer, self).__init__(**kwargs)
        self.filters = filters
        self.kernel_size = kernel_size
        self.total_filters = sum(filters)

    def build(self, input_shape):
        self.conv_kernels = []
        for i in range(len(self.filters)):
            self.conv_kernels.append(
                tf.keras.layers.Conv1D(filters=self.filters[i],
                                       kernel_size=self.kernel_size[i],
                                       strides=1,
                                       padding='same',
                                       activation='relu',
                                       name='conv1d_layer_{}'.format(i)))

        super(MultiCNNLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
            Args:
                input_a: (batch, a_len, dim)

            Returns:
                (batch, a_len, total_filters)

            """
        outputs = []
        for i in range(len(self.filters)):
            outputs.append(self.conv_kernels[i](inputs))
            # outputs[i]: (batch, len, filter[i])
            tf.logging.info('MultiCNNLayer: outputs {} {}'.format(i, outputs[-1]))

        output = tf.keras.layers.Concatenate(axis=-1)(outputs)
        return output

    def compute_output_shape(self, input_shape):
        input_shape = tensor_shape.TensorShape(input_shape)
        input_shape = input_shape.with_rank_at_least(2)
        if tensor_shape.dimension_value(input_shape[-1]) is None:
            raise ValueError(
                'The innermost dimension of input_shape must be defined, but saw: %s'
                % input_shape)
        return input_shape[:2].concatenate(self.total_filters)

    def get_config(self):
        config = {'filters': self.filters, 'kernel_size': self.kernel_size}
        base_config = super(MultiCNNLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class NextItNetLayer(tf.keras.layers.Layer):
    """
      Model: 2d dialted CNN as NextItNet

      Paper: A Simple but Hard-to-Beat Baseline for Session-based Recommendations

      Link: https://arxiv.org/abs/1706.03762

      Author: Fajie Yuan, Alexandros Karatzoglou, Ioannis Arapakis, Joemon M Jose, Xiangnan He

      Developer: anbo

      Date: 2020-07-02

      inputs: (batch, a_len, dim)

      outputs: (batch, a_len, total_filters)

      """

    def __init__(self, kernel_size=[1, 3, 1], dilation_rate=[1, 2, 4], **kwargs):
        """
            Args:
                kernel_size: list, number of kernel filter size in each 1d conv channel
                dilation_rate: list
                kwargs:
            """
        super(NextItNetLayer, self).__init__(**kwargs)
        self.kernel_size = kernel_size
        self.dilation_rate = dilation_rate

    def build(self, input_shape):
        dim = int(input_shape[-1])
        self.conv_kernels = []
        self.filters = [dim, int(0.5 * dim), dim]

        self.pre_ln = LayerNorm(name='pre_ln_layer')
        self.mid_ln = LayerNorm(name='mid_ln_layer')
        self.last_ln = LayerNorm(name='last_ln_layer')

        for i in range(len(self.kernel_size)):
            self.conv_kernels.append(
                tf.keras.layers.Conv2D(filters=self.filters[i],
                                       kernel_size=(1, self.kernel_size[i]),
                                       strides=(1, 1),
                                       padding='same',
                                       data_format='channels_last',
                                       dilation_rate=(1, self.dilation_rate[i]),
                                       activation='relu',
                                       name='dilated_2d_layer_{}'.format(i)))

        super(NextItNetLayer, self).build(input_shape)

    def call(self, inputs, **kwargs):
        """
            Args:
                input_a: (batch, a_len, dim)

            Returns:
                (batch, a_len, total_filters)

            """
        assert (tf.keras.backend.ndim(inputs) == 3), (
            'NextItNetLayer must receive a 3d shape as input')

        # reshape to 4d to apply 2D CNN
        inputs_4d = tf.expand_dims(inputs, axis=1)
        # inputs_4d: (batch, 1, len, dim)
        tf.logging.info('NextItNetLayer: inputs_4d {}'.format(inputs_4d))

        # pre layer
        pre_ln_output = self.pre_ln(inputs_4d)
        pre_ln_output = tf.nn.sigmoid(pre_ln_output)
        pre_cnn_output = self.conv_kernels[0](pre_ln_output)
        tf.logging.info('NextItNetLayer: pre_cnn_output {}'.format(pre_cnn_output))

        # middle layer
        mid_ln_output = self.mid_ln(pre_cnn_output)
        mid_ln_output = tf.nn.sigmoid(mid_ln_output)
        mid_cnn_output = self.conv_kernels[1](mid_ln_output)
        tf.logging.info('NextItNetLayer: mid_cnn_output {}'.format(mid_cnn_output))

        # last layer
        last_ln_output = self.last_ln(mid_cnn_output)
        last_ln_output = tf.nn.sigmoid(last_ln_output)
        last_cnn_output = self.conv_kernels[2](last_ln_output)
        tf.logging.info(
            'NextItNetLayer: last_cnn_output {}'.format(last_cnn_output))

        # reshape back to 3d
        output = tf.squeeze(last_cnn_output, axis=1)
        # output: (batch, len, dim)
        tf.logging.info('NextItNetLayer: output {}'.format(output))

        return output

    def compute_output_shape(self, input_shape):
        return input_shape

    def get_config(self):
        config = {
            'kernel_size': self.kernel_size,
            'dilation_rate': self.dilation_rate
        }
        base_config = super(NextItNetLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))
